<?php
class HelloWorldMgr extends SGL_Manager
{
    function display(&$output)
    {
        $output->template = 'helloWorld.html';
        $output->testVariable = 'Hello World!';
    }
}
?>