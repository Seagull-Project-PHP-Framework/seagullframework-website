--
-- Dumping data for table block
--

INSERT INTO block VALUES (1, 'SiteNews', 'Site News', '', '', 2, 1, 1);
INSERT INTO block VALUES (2, 'DirectoryNav', 'Navigation', '', 'navWidget', 1, 1, 1);
INSERT INTO block VALUES (3, 'SampleBlock1', 'Sample Block 1', '', '', 3, 1, 1);
INSERT INTO block VALUES (4, 'SampleBlock2', 'Sample Block 2', '', '', 4, 1, 1);
INSERT INTO block VALUES (10, 'SampleRightBlock1', 'Sample Right Block', '', '', 1, 0, 1);

--
-- Dumping data for table section
--

--INSERT INTO section VALUES (0,'none','','0',0,0,1,2,0,1,0,0);
--INSERT INTO section VALUES (1,'Home','','1,2,0',0,1,1,2,1,1,1,0);
--INSERT INTO section VALUES (2,'Articles','publisher/articleview','1,2,0',0,2,1,2,6,1,1,0);
--INSERT INTO section VALUES (3,'FAQ','faq','1,2,0',0,3,1,2,7,1,1,0);
--INSERT INTO section VALUES (4,'My Account','user/account','1,2',0,4,1,2,9,1,1,0);
--INSERT INTO section VALUES (5,'Messages','messaging/imessage','1,2',0,5,1,2,5,1,1,0);
--INSERT INTO section VALUES (6,'Sample','publisher/articleview/frmArticleID/1','0',0,6,1,2,4,1,1,1);
--INSERT INTO section VALUES (7,'Contact Us','contactus','1,2,0',0,7,1,8,2,1,1,0);
--INSERT INTO section VALUES (8,'Register Now','user/register','0',0,8,1,2,8,1,1,0);
--INSERT INTO section VALUES (9,'Publisher','publisher/article','2',0,9,1,2,3,1,1,0);
--INSERT INTO section VALUES (11,'testSection','faq','0',15,7,5,6,1,3,1,0);
--INSERT INTO section VALUES (12,'Modules','default/module','1',0,12,1,4,11,1,1,0);
--INSERT INTO section VALUES (13,'Configuration','default/config','1',0,13,1,2,10,1,1,0);
--INSERT INTO section VALUES (14,'Get a quote','contactus/contactus/action/list/enquiry_type/Get a quote','1,2,0',7,7,2,3,1,2,1,0);
--INSERT INTO section VALUES (15,'Hosting info','contactus/contactus/action/list/enquiry_type/Hosting info','1,2,0',7,7,4,7,2,2,1,0);
--INSERT INTO section VALUES (16,'Manage','default/module/action/list','1',12,12,2,3,1,2,1,0);
--INSERT INTO section VALUES (17,'PubCategories','navigation/category','1',0,17,1,2,12,1,0,0);
--INSERT INTO section VALUES (18,'PubDocuments','publisher/document','1',0,18,1,2,13,1,0,0);
--INSERT INTO section VALUES (19,'PubArticles','publisher/article','1',0,19,1,2,14,1,0,0);

INSERT INTO section VALUES (0,'none','','0',0,0,1,2,0,1,0,0);
INSERT INTO section VALUES (1,'Home','index.php','1,2,0',0,1,1,2,1,1,1,0);
INSERT INTO section VALUES (2,'Articles','articles.php','1,2,0',0,2,1,2,6,1,1,0);
INSERT INTO section VALUES (3,'FAQ','faq.php','1,2,0',0,3,1,2,7,1,1,0);
INSERT INTO section VALUES (4,'My Account','myAccount.php','1,2',0,4,1,2,9,1,1,0);
INSERT INTO section VALUES (5,'Messages','imMgr.php','1,2',0,5,1,2,5,1,1,0);
INSERT INTO section VALUES (6,'Sample','articles.php?frmArticleID=1','0',0,6,1,2,4,1,1,1);
INSERT INTO section VALUES (7,'Contact Us','contactUs.php','1,2,0',0,7,1,8,2,1,1,0);
INSERT INTO section VALUES (8,'Register Now','register.php','0',0,8,1,2,8,1,1,0);
INSERT INTO section VALUES (9,'Publisher','publisher.php','2',0,9,1,2,3,1,1,0);
INSERT INTO section VALUES (11,'testSection','faq.php','0',15,7,5,6,1,3,1,0);
INSERT INTO section VALUES (12,'Modules','moduleMgr.php','1',0,12,1,4,11,1,1,0);
INSERT INTO section VALUES (13,'Configuration','configMgr.php','1',0,13,1,2,10,1,1,0);
INSERT INTO section VALUES (14,'Get a quote','contactUs.php?enquiry_type=Get a quote','1,2,0',7,7,2,3,1,2,1,0);
INSERT INTO section VALUES (15,'Hosting info','contactUs.php?enquiry_type=Hosting info','1,2,0',7,7,4,7,2,2,1,0);
INSERT INTO section VALUES (16,'Manage','moduleMgr.php?action=list','1',12,12,2,3,1,2,1,0);
INSERT INTO section VALUES (17,'PubCategories','categoryMgr.php','1',0,17,1,2,12,1,0,0);
INSERT INTO section VALUES (18,'PubDocuments','documentMgr.php','1',0,18,1,2,13,1,0,0);
INSERT INTO section VALUES (19,'PubArticles','articleMgr.php','1',0,19,1,2,14,1,0,0);

--
-- Dumping data for table block_assignment
--

INSERT INTO block_assignment VALUES (1, 0);
INSERT INTO block_assignment VALUES (2, 2);
INSERT INTO block_assignment VALUES (3, 0);
INSERT INTO block_assignment VALUES (4, 0);
INSERT INTO block_assignment VALUES (10, 0);

--
-- Dumping data for table category
--

INSERT INTO category VALUES (1, NULL, 'example', NULL);

--
-- Dumping data for table contact_us
--

--
-- Dumping data for table document
--

--
-- Dumping data for table document_type
--

INSERT INTO document_type VALUES (1, 'MS Word');
INSERT INTO document_type VALUES (2, 'MS Excel');
INSERT INTO document_type VALUES (3, 'MS Powerpoint');
INSERT INTO document_type VALUES (4, 'URL');
INSERT INTO document_type VALUES (5, 'Image');
INSERT INTO document_type VALUES (6, 'PDF');
INSERT INTO document_type VALUES (7, 'unknown');

--
-- Dumping data for table faq
--

--
-- Dumping data for table usr
--

INSERT INTO usr (usr_id, organisation_id, role_id, username, passwd, first_name, last_name, telephone, mobile, email, addr_1, addr_2, addr_3, city, region, country, post_code, is_email_public, is_acct_active, security_question, security_answer, date_created, created_by, last_updated, updated_by) VALUES (0, 1, 1, 'nobody', '21232f297a57a5a743894a0e4a801fc3', 'Nobody', 'Nobody', '', '', 'none@none.com', 'none', '', '', 'None', '', 'NN', '55555', 0, 0, 1, 'rover', '2003-12-09 18:02:44', 1, '2004-06-10 11:07:27', 1);
INSERT INTO usr (usr_id, organisation_id, role_id, username, passwd, first_name, last_name, telephone, mobile, email, addr_1, addr_2, addr_3, city, region, country, post_code, is_email_public, is_acct_active, security_question, security_answer, date_created, created_by, last_updated, updated_by) VALUES (1, 1, 1, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'Admin', 'User', '', '', 'webmaster@phpkitchen.com', '1 Seagull Drive', '', '', 'London', '', 'GB', '55555', 0, 1, 1, 'rover', '2003-12-09 18:02:44', 1, '2004-06-10 11:07:27', 1);
INSERT INTO usr (usr_id, organisation_id, role_id, username, passwd, first_name, last_name, telephone, mobile, email, addr_1, addr_2, addr_3, city, region, country, post_code, is_email_public, is_acct_active, security_question, security_answer, date_created, created_by, last_updated, updated_by) VALUES (2, 1, 2, 'seagull', '21232f297a57a5a743894a0e4a801fc3', 'Test', 'User', '', '', 'demian@phpkitchen.com', '17 Daver Court', 'Mount Avenue', '', 'Ealing', '', 'GB', '55555', 0, 1, 1, 'rover', '2004-06-10 18:04:06', 1, '2004-06-10 18:04:06', 1);

--
-- Dumping data for table instant_message
--

INSERT INTO instant_message VALUES (1, 1, 2, '2003-08-14 00:14:41', 'Welcome to Seagull', 'This is an example message.  Once you add users to the system, they can contact eachother via this instant message interface.', 3, 3);

--
-- Dumping data for table item_type
--

INSERT INTO item_type VALUES (1, 'All');
INSERT INTO item_type VALUES (2, 'Html Article');
INSERT INTO item_type VALUES (3, 'Text Article');
INSERT INTO item_type VALUES (4, 'News Item');
INSERT INTO item_type VALUES (5, 'Static Html Article');

--
-- Dumping data for table item
--

INSERT INTO item VALUES (1, 1, 5, 1, 1, '2004-01-03 18:21:25', '2004-03-16 22:38:38', '2004-01-03 18:21:07', '2009-01-03 00:00:00', 4);

--
-- Dumping data for table item_type_mapping
--

INSERT INTO item_type_mapping VALUES (1, 3, 'title', 0);
INSERT INTO item_type_mapping VALUES (2, 3, 'bodyText', 1);
INSERT INTO item_type_mapping VALUES (3, 2, 'title', 0);
INSERT INTO item_type_mapping VALUES (4, 2, 'bodyHtml', 2);
INSERT INTO item_type_mapping VALUES (5, 4, 'title', 0);
INSERT INTO item_type_mapping VALUES (6, 4, 'newsHtml', 2);
INSERT INTO item_type_mapping VALUES (7, 5, 'title', 0);
INSERT INTO item_type_mapping VALUES (8, 5, 'bodyHtml', 2);

--
-- Dumping data for table item_addition
--

INSERT INTO item_addition VALUES (1, 1, 7, 'Content Reshuffle');
INSERT INTO item_addition VALUES (2, 1, 8, '<P>Test out dynamic language switching here:</P>\r\n<TABLE cellPadding=5 width="75%" align=center border=1>\r\n<TBODY>\r\n<TR bgColor=#cccccc>\r\n<TD>\r\n<P align=center>&nbsp;<A href="articles.php?frmArticleID=1&amp;staticId=6&amp;lang=de-iso-8859-1"><IMG height=20 alt=germany.gif hspace=0 src="themes/default/images/uploads/germany.gif" width=30 align=baseline border=0></A></P></TD>\r\n<TD>\r\n<P align=center>&nbsp;<A href="articles.php?frmArticleID=1&amp;staticId=6&amp;lang=zh"><IMG height=20 alt=china.gif hspace=0 src="themes/default/images/uploads/china.gif" width=30 align=baseline border=0></A></P></TD>\r\n<TD>\r\n<P align=center>&nbsp;<A href="articles.php?frmArticleID=1&amp;staticId=6&amp;lang=zh-tw"><IMG style="WIDTH: 30px; HEIGHT: 20px" height=20 alt=taiwan.gif hspace=0 src="themes/default/images/uploads/taiwan.gif" width=30 align=baseline border=0></A></P></TD>\r\n<TD>\r\n<P align=center><A href="articles.php?frmArticleID=1&amp;staticId=6&amp;lang=ru-win1251"><IMG height=20 alt=russia.gif hspace=0 src="themes/default/images/uploads/russia.gif" width=30 align=baseline border=0></A>&nbsp;</P></TD>\r\n<TD>\r\n<P align=center><A href="articles.php?frmArticleID=1&staticId=6&lang=en-iso-8859-15"><IMG height=15 alt=uk.gif hspace=0 src="themes/default/images/uploads/uk.gif" width=30 align=baseline border=0></A>&nbsp;</P></TD></TR>\r\n<TR>\r\n<TD>\r\n<P align=center><A href="articles.php?frmArticleID=1&amp;staticId=6&amp;lang=de-iso-8859-1">German</A></P></TD>\r\n<TD>\r\n<P align=center><A href="articles.php?frmArticleID=1&amp;staticId=6&amp;lang=zh">Chinese(GB2312)</A></P></TD>\r\n<TD>\r\n<P align=center><A href="articles.php?frmArticleID=1&amp;staticId=6&amp;lang=zh-tw">Chinese(Big5)</A></P></TD>\r\n<TD>\r\n<P align=center><A href="articles.php?frmArticleID=1&amp;staticId=6&amp;lang=ru-win1251">Russian</A></P></TD>\r\n<TD>\r\n<P align=center><A href="articles.php?frmArticleID=1&staticId=6&lang=en-iso-8859-1">English</A></P></TD></TR></TBODY></TABLE>\r\n<P><STRONG>nb</STRONG>: to see the Chinese translation rendered properly english Windows users running Internet Explorer will need to install the Asian language pack - see <A href="http:--marc.theaimsgroup.com/?l=seagull-general&amp;m=107814024805423&amp;w=2">this page</A> for more detail.</P>\r\n<P>Thanks to <A href="http:--www.stargeek.com/">Dan''s</A> excellent <A href="http:--www.stargeek.com/crawler_sim.php">web crawler simulation</A> tool that gives you a search engine view of your site, I''ve shuffled around PHPkitchen''s content in an attempt to put the more relevant stuff at the top.</P>\r\n<P>Please also checkout the new <STRONG>Thinking Outside of the Box</STRONG> block in the left column, this is a collection of links to some of the more interesting applications of PHP that have surfaced recently.</P>\r\n<P>Dan''s other tool, the <A href="http:--www.stargeek.com/code_to_text.php">code to text analyser</A>, reveals PHPkitchen suffers from a high html bloat, this is being addressed in latest version of <A href="http:--www.phpkitchen.com/seagull/">Seagull</A> project where John Dell is&nbsp;almost finished his&nbsp;XHTML theme.</P>');

--
-- Dumping data for table login
--

--
-- Dumping data for table module
--

INSERT INTO module (module_id, is_configurable, name, title, description, admin_uri, icon) VALUES (1, 1, 'block', 'Blocks', 'Use the ''Blocks'' module to configure the contents of the blocks in the left and right hand columns.', 'blockMgr.php', 'blocks.png');
INSERT INTO module (module_id, is_configurable, name, title, description, admin_uri, icon) VALUES (2, 0, 'contactus', 'Contact Us', 'The ''Contact Us'' module can be used to present a form to your users allowing them to contact the site administrators.', NULL, 'contactus.png');
INSERT INTO module (module_id, is_configurable, name, title, description, admin_uri, icon) VALUES (3, 0, 'default', 'Default', 'The ''Default'' module includes functionality that is needed in every install, for example, configuration and interface language manangement, and module management.', NULL, 'default.png');
INSERT INTO module (module_id, is_configurable, name, title, description, admin_uri, icon) VALUES (4, 0, 'documentor', 'Documentor', '''Documentor'' is a module that lets you quickly and easily create documentation in html format based on articles you submit in the ''Publisher'' module.', NULL, 'documentor.png');
INSERT INTO module (module_id, is_configurable, name, title, description, admin_uri, icon) VALUES (5, 1, 'faq', 'FAQs', 'Use the ''FAQ'' module to easily create a list of Frequently Asked Questions with corresponding answers for your site.', 'faq.php', 'faqs.png');
INSERT INTO module (module_id, is_configurable, name, title, description, admin_uri, icon) VALUES (6, 0, 'guestbook', 'Guestbook', 'Use the ''FAQ'' to allow users to leave comments about your site.', 'guestbook.php', 'core.png');
INSERT INTO module (module_id, is_configurable, name, title, description, admin_uri, icon) VALUES (7, 1, 'maintenance', 'Maintenance', 'The ''Maintenance'' module lets you take care of several application maintenance tasks, like cleaning up temporary files, managing interface language translations, rebuilding DataObjects files, etc.', 'maintenanceMgr.php', 'maintenance.png');
INSERT INTO module (module_id, is_configurable, name, title, description, admin_uri, icon) VALUES (8, 0, 'messaging', 'Messaging', 'The ''Messaging'' module contains classes for sending internal Instant Messages, managing external email sending, and managing your contacts.', NULL, 'messaging.png');
INSERT INTO module (module_id, is_configurable, name, title, description, admin_uri, icon) VALUES (9, 1, 'navigation', 'Navigation', 'The ''Navigation'' module is what you use to build your site navigation, it creates menus that you can customise in terms of look and feel, and allows you to link to any site resource.', 'pageMgr.php', 'navigation.png');
INSERT INTO module (module_id, is_configurable, name, title, description, admin_uri, icon) VALUES (10, 1, 'newsletter', 'Newsletter', 'The ''Newsletter'' module is a simple mass mailer module that allows you to create an HTML formatted message or newsletter, and send it to all your registered users, or on a group by group basis, in a single click.', 'newsletter.php', 'newsletter.png');
INSERT INTO module (module_id, is_configurable, name, title, description, admin_uri, icon) VALUES (11, 1, 'publisher', 'Publisher', 'The ''Publisher'' module allows you to create content and publish it to your site.  Currently you can create various types of articles and upload and categorise any filetype, matching the two together in a browsable archive format.', 'publisherFrames.php', 'publisher.png');
INSERT INTO module (module_id, is_configurable, name, title, description, admin_uri, icon) VALUES (12, 1, 'user', 'Users and Security', 'The ''Users and Security'' module allows you to manage all your users, administer the roles they belong to, change their passwords, setup permissions and alter the global default preferences.', 'userMgr.php', 'users.png');
INSERT INTO module (module_id, is_configurable, name, title, description, admin_uri, icon) VALUES (13, 1, 'randommsg', 'Random Messages', 'Allows you to create a list of messages and display them randomly (fortune).', 'rndmsgMgr.php', 'rndmsg.png');

--
-- Dumping data for table preference
--

INSERT INTO preference VALUES (1, 'sessionTimeout', '1800');
INSERT INTO preference VALUES (2, 'locale', 'Europe/London');
INSERT INTO preference VALUES (3, 'theme', 'default');
INSERT INTO preference VALUES (4, 'dateFormat', 'UK');
INSERT INTO preference VALUES (5, 'language', 'en-iso-8859-1');
INSERT INTO preference VALUES (6, 'resPerPage', '10');
INSERT INTO preference VALUES (7, 'showExecutionTimes', '1');

--
-- Dumping data for table user_preference
--

INSERT INTO user_preference VALUES (1, 0, 1, '1800');
INSERT INTO user_preference VALUES (2, 0, 2, 'Europe/London');
INSERT INTO user_preference VALUES (3, 0, 3, 'default');
INSERT INTO user_preference VALUES (4, 0, 4, 'UK');
INSERT INTO user_preference VALUES (5, 0, 5, 'en-iso-8859-1');
INSERT INTO user_preference VALUES (6, 0, 6, '10');
INSERT INTO user_preference VALUES (7, 0, 7, '1');

--
-- Role table
--

INSERT INTO role (role_id, name, description) VALUES (0, 'guest', 'public user');
INSERT INTO role (role_id, name, description) VALUES (1, 'root', 'super user');
INSERT INTO role (role_id, name, description) VALUES (2, 'member', 'has a limited set of privileges');

--INSERT INTO role (role_id, name, description) VALUES (3, 'block admin', 'Has full admin privileges on blocks');
--INSERT INTO role (role_id, name, description) VALUES (4, 'faq admin', 'Has full admin privileges on FAQs');
--INSERT INTO role (role_id, name, description) VALUES (5, 'maintenance admin', 'Has full admin privileges on maintenance');
--INSERT INTO role (role_id, name, description) VALUES (6, 'navigation admin', 'Has full admin privileges on navigation');

-- 
-- Organisation table
--

INSERT INTO organisation (organisation_id, parent_id, root_id, left_id, right_id, order_id, level_id, role_id, organisation_type_id, name, description, addr_1, addr_2, addr_3, city, region, country, post_code, telephone, website, email, date_created, created_by, last_updated, updated_by) VALUES (1, 0, 1, 1, 2, 1, 1, 2, 0, 'default org', 'test', 'aasdfasdf', '', '', 'asdfadf', 'AL', 'BJ', '55555', '325 652 5645', 'http:--example.com', 'test@test.com', '2004-01-12 16:13:21', NULL, '2004-06-23 10:44:52', 1);
INSERT INTO organisation (organisation_id, parent_id, root_id, left_id, right_id, order_id, level_id, role_id, organisation_type_id, name, description, addr_1, addr_2, addr_3, city, region, country, post_code, telephone, website, email, date_created, created_by, last_updated, updated_by) VALUES (2, 0, 2, 1, 2, 2, 1, 2, 0, 'sainsburys', 'test', 'aasdfasdf', '', '', 'asdfadf', 'AL', 'BJ', 'asdfasdf', '325 652 5645', 'http:--sainsburys.com', 'info@sainsburys.com', '2004-01-12 16:13:21', NULL, '2004-06-23 10:44:56', 1);

--
-- Permission table
--

INSERT INTO permission VALUES (1, 'blockmgr_add', '', 1);
INSERT INTO permission VALUES (2, 'blockmgr_edit', '', 1);
INSERT INTO permission VALUES (3, 'blockmgr_delete', '', 1);
INSERT INTO permission VALUES (4, 'blockmgr_reorder', '', 1);
INSERT INTO permission VALUES (5, 'blockmgr_list', '', 1);
INSERT INTO permission VALUES (6, 'contactusmgr_send', '', 2);
INSERT INTO permission VALUES (7, 'contactusmgr_list', '', 2);
INSERT INTO permission VALUES (8, 'configmgr_edit', '', 3);
INSERT INTO permission VALUES (9, 'configmgr_insert', '', 3);
INSERT INTO permission VALUES (10, 'defaultmgr_list', '', 3);
INSERT INTO permission VALUES (11, 'defaultmgr_showNews', '', 3);
INSERT INTO permission VALUES (12, 'modulemgr_add', '', 3);
INSERT INTO permission VALUES (13, 'modulemgr_insert', '', 3);
INSERT INTO permission VALUES (14, 'modulemgr_delete', '', 3);
INSERT INTO permission VALUES (15, 'modulemgr_list', '', 3);
INSERT INTO permission VALUES (16, 'modulemgr_overview', '', 3);
INSERT INTO permission VALUES (17, 'documentormgr_list', '', 4);
INSERT INTO permission VALUES (18, 'faqmgr_add', '', 5);
INSERT INTO permission VALUES (19, 'faqmgr_insert', '', 5);
INSERT INTO permission VALUES (20, 'faqmgr_edit', '', 5);
INSERT INTO permission VALUES (21, 'faqmgr_update', '', 5);
INSERT INTO permission VALUES (22, 'faqmgr_delete', '', 5);
INSERT INTO permission VALUES (23, 'faqmgr_list', '', 5);
INSERT INTO permission VALUES (24, 'faqmgr_reorder', '', 5);
INSERT INTO permission VALUES (25, 'faqmgr_reorderUpdate', '', 5);
INSERT INTO permission VALUES (26, 'guestbookmgr_list', '', 6);
INSERT INTO permission VALUES (27, 'guestbookmgr_add', '', 6);
INSERT INTO permission VALUES (28, 'guestbookmgr_insert', '', 6);
INSERT INTO permission VALUES (30, 'maintenancemgr_edit', '', 7);
INSERT INTO permission VALUES (31, 'maintenancemgr_update', '', 7);
INSERT INTO permission VALUES (32, 'maintenancemgr_append', '', 7);
INSERT INTO permission VALUES (33, 'maintenancemgr_dbgen', '', 7);
INSERT INTO permission VALUES (34, 'maintenancemgr_clearCache', '', 7);
INSERT INTO permission VALUES (35, 'maintenancemgr_list', '', 7);
INSERT INTO permission VALUES (36, 'contactmgr_insert', '', 8);
INSERT INTO permission VALUES (37, 'contactmgr_delete', '', 8);
INSERT INTO permission VALUES (38, 'contactmgr_list', '', 8);
INSERT INTO permission VALUES (39, 'imessagemgr_read', '', 8);
INSERT INTO permission VALUES (40, 'imessagemgr_delete', '', 8);
INSERT INTO permission VALUES (41, 'imessagemgr_compose', '', 8);
INSERT INTO permission VALUES (42, 'imessagemgr_reply', '', 8);
INSERT INTO permission VALUES (43, 'imessagemgr_insert', '', 8);
INSERT INTO permission VALUES (45, 'imessagemgr_outbox', '', 8);
INSERT INTO permission VALUES (46, 'imessagemgr_inbox', '', 8);
INSERT INTO permission VALUES (47, 'navstylemgr_changeStyle', '', 9);
INSERT INTO permission VALUES (48, 'navstylemgr_list', '', 9);
INSERT INTO permission VALUES (49, 'pagemgr_add', '', 9);
INSERT INTO permission VALUES (50, 'pagemgr_insert', '', 9);
INSERT INTO permission VALUES (51, 'pagemgr_edit', '', 9);
INSERT INTO permission VALUES (52, 'pagemgr_update', '', 9);
INSERT INTO permission VALUES (53, 'pagemgr_delete', '', 9);
INSERT INTO permission VALUES (54, 'pagemgr_reorder', '', 9);
INSERT INTO permission VALUES (55, 'pagemgr_list', '', 9);
INSERT INTO permission VALUES (56, 'newslettermgr_send', '', 10);
INSERT INTO permission VALUES (57, 'newslettermgr_addressBook', '', 10);
INSERT INTO permission VALUES (58, 'articleviewmgr_view', '', 11);
INSERT INTO permission VALUES (59, 'articleviewmgr_summary', '', 11);
INSERT INTO permission VALUES (60, 'articlemgr_add', '', 11);
INSERT INTO permission VALUES (61, 'articlemgr_insert', '', 11);
INSERT INTO permission VALUES (62, 'articlemgr_edit', '', 11);
INSERT INTO permission VALUES (63, 'articlemgr_update', '', 11);
INSERT INTO permission VALUES (64, 'articlemgr_changeStatus', '', 11);
INSERT INTO permission VALUES (65, 'articlemgr_delete', '', 11);
INSERT INTO permission VALUES (66, 'articlemgr_view', '', 11);
INSERT INTO permission VALUES (67, 'articlemgr_list', '', 11);
INSERT INTO permission VALUES (68, 'categorymgr_add', '', 11);
INSERT INTO permission VALUES (69, 'categorymgr_insert', '', 11);
INSERT INTO permission VALUES (70, 'categorymgr_edit', '', 11);
INSERT INTO permission VALUES (71, 'categorymgr_update', '', 11);
INSERT INTO permission VALUES (73, 'rolemgr_duplicate', '', 12);
INSERT INTO permission VALUES (75, 'categorymgr_list', '', 11);
INSERT INTO permission VALUES (76, 'documentmgr_add', '', 11);
INSERT INTO permission VALUES (77, 'documentmgr_insert', '', 11);
INSERT INTO permission VALUES (78, 'documentmgr_edit', '', 11);
INSERT INTO permission VALUES (79, 'documentmgr_update', '', 11);
INSERT INTO permission VALUES (80, 'documentmgr_setDownload', '', 11);
INSERT INTO permission VALUES (81, 'documentmgr_view', '', 11);
INSERT INTO permission VALUES (82, 'documentmgr_delete', '', 11);
INSERT INTO permission VALUES (83, 'documentmgr_list', '', 11);
INSERT INTO permission VALUES (84, 'filemgr_download', '', 11);
INSERT INTO permission VALUES (85, 'filemgr_downloadZipped', '', 11);
INSERT INTO permission VALUES (86, 'filemgr_view', '', 11);
INSERT INTO permission VALUES (89, 'rndmsgmgr_add', '', 13);
INSERT INTO permission VALUES (90, 'rndmsgmgr_insert', '', 13);
INSERT INTO permission VALUES (91, 'rndmsgmgr_delete', '', 13);
INSERT INTO permission VALUES (92, 'rndmsgmgr_list', '', 13);
INSERT INTO permission VALUES (93, 'accountmgr_edit', '', 12);
INSERT INTO permission VALUES (94, 'accountmgr_update', '', 12);
INSERT INTO permission VALUES (95, 'accountmgr_viewProfile', '', 12);
INSERT INTO permission VALUES (96, 'accountmgr_summary', '', 12);
INSERT INTO permission VALUES (97, 'loginmgr_login', '', 12);
INSERT INTO permission VALUES (98, 'loginmgr_list', '', 12);
INSERT INTO permission VALUES (99, 'orgmgr_add', '', 12);
INSERT INTO permission VALUES (100, 'orgmgr_insert', '', 12);
INSERT INTO permission VALUES (101, 'orgmgr_edit', '', 12);
INSERT INTO permission VALUES (102, 'orgmgr_update', '', 12);
INSERT INTO permission VALUES (103, 'orgmgr_delete', '', 12);
INSERT INTO permission VALUES (104, 'orgmgr_list', '', 12);
INSERT INTO permission VALUES (105, 'passwordmgr_edit', '', 12);
INSERT INTO permission VALUES (106, 'passwordmgr_update', '', 12);
INSERT INTO permission VALUES (107, 'passwordmgr_retrieve', '', 12);
INSERT INTO permission VALUES (108, 'passwordmgr_forgot', '', 12);
INSERT INTO permission VALUES (109, 'permissionmgr_add', '', 12);
INSERT INTO permission VALUES (110, 'permissionmgr_insert', '', 12);
INSERT INTO permission VALUES (111, 'permissionmgr_edit', '', 12);
INSERT INTO permission VALUES (112, 'permissionmgr_update', '', 12);
INSERT INTO permission VALUES (113, 'permissionmgr_delete', '', 12);
INSERT INTO permission VALUES (114, 'permissionmgr_list', '', 12);
INSERT INTO permission VALUES (115, 'preferencemgr_add', '', 12);
INSERT INTO permission VALUES (116, 'preferencemgr_insert', '', 12);
INSERT INTO permission VALUES (117, 'preferencemgr_edit', '', 12);
INSERT INTO permission VALUES (118, 'preferencemgr_update', '', 12);
INSERT INTO permission VALUES (119, 'preferencemgr_delete', '', 12);
INSERT INTO permission VALUES (120, 'preferencemgr_list', '', 12);
INSERT INTO permission VALUES (121, 'profilemgr_view', '', 12);
INSERT INTO permission VALUES (122, 'registermgr_add', '', 12);
INSERT INTO permission VALUES (123, 'registermgr_insert', '', 12);
INSERT INTO permission VALUES (124, 'rolemgr_add', '', 12);
INSERT INTO permission VALUES (125, 'rolemgr_insert', '', 12);
INSERT INTO permission VALUES (126, 'rolemgr_edit', '', 12);
INSERT INTO permission VALUES (127, 'rolemgr_update', '', 12);
INSERT INTO permission VALUES (128, 'rolemgr_delete', '', 12);
INSERT INTO permission VALUES (129, 'rolemgr_list', '', 12);
INSERT INTO permission VALUES (130, 'rolemgr_editPerms', '', 12);
INSERT INTO permission VALUES (131, 'rolemgr_updatePerms', '', 12);
INSERT INTO permission VALUES (132, 'usermgr_add', '', 12);
INSERT INTO permission VALUES (133, 'usermgr_insert', '', 12);
INSERT INTO permission VALUES (134, 'usermgr_edit', '', 12);
INSERT INTO permission VALUES (135, 'usermgr_update', '', 12);
INSERT INTO permission VALUES (136, 'usermgr_delete', '', 12);
INSERT INTO permission VALUES (137, 'usermgr_list', '', 12);
INSERT INTO permission VALUES (138, 'usermgr_requestPasswordReset', '', 12);
INSERT INTO permission VALUES (139, 'usermgr_resetPassword', '', 12);
INSERT INTO permission VALUES (140, 'usermgr_editPerms', '', 12);
INSERT INTO permission VALUES (141, 'usermgr_updatePerms', '', 12);
INSERT INTO permission VALUES (142, 'userpreferencemgr_editAll', '', 12);
INSERT INTO permission VALUES (143, 'userpreferencemgr_updateAll', '', 12);
INSERT INTO permission VALUES (145, 'newslettermgr_list', '', 10);
INSERT INTO permission VALUES (146, 'orgpreferencemgr_redirectToDefault', '', 12);
INSERT INTO permission VALUES (147, 'accountmgr', '', 12);
INSERT INTO permission VALUES (148, 'accountmgr_redirectToDefault', '', 12);
INSERT INTO permission VALUES (149, 'loginmgr', '', 12);
INSERT INTO permission VALUES (150, 'loginmgr_logout', '', 12);
INSERT INTO permission VALUES (151, 'orgmgr', '', 12);
INSERT INTO permission VALUES (152, 'orgmgr_redirectToDefault', '', 12);
INSERT INTO permission VALUES (153, 'orgpreferencemgr', '', 12);
INSERT INTO permission VALUES (154, 'orgpreferencemgr_editAll', '', 12);
INSERT INTO permission VALUES (155, 'orgpreferencemgr_updateAll', '', 12);
INSERT INTO permission VALUES (156, 'passwordmgr', '', 12);
INSERT INTO permission VALUES (157, 'passwordmgr_redirectToDefault', '', 12);
INSERT INTO permission VALUES (158, 'permissionmgr', '', 12);
INSERT INTO permission VALUES (159, 'permissionmgr_redirectToDefault', '', 12);
INSERT INTO permission VALUES (160, 'permissionmgr_scanNew', '', 12);
INSERT INTO permission VALUES (161, 'permissionmgr_insertNew', '', 12);
INSERT INTO permission VALUES (162, 'permissionmgr_scanOrphaned', '', 12);
INSERT INTO permission VALUES (163, 'permissionmgr_deleteOrphaned', '', 12);
INSERT INTO permission VALUES (164, 'preferencemgr', '', 12);
INSERT INTO permission VALUES (165, 'preferencemgr_redirectToDefault', '', 12);
INSERT INTO permission VALUES (166, 'profilemgr', '', 12);
INSERT INTO permission VALUES (167, 'registermgr', '', 12);
INSERT INTO permission VALUES (168, 'registermgr_redirectToDefault', '', 12);
INSERT INTO permission VALUES (169, 'rolemgr', '', 12);
INSERT INTO permission VALUES (170, 'rolemgr_redirectToDefault', '', 12);
INSERT INTO permission VALUES (171, 'userimportmgr', '', 12);
INSERT INTO permission VALUES (172, 'userimportmgr_list', '', 12);
INSERT INTO permission VALUES (173, 'userimportmgr_insertImportedUsers', '', 12);
INSERT INTO permission VALUES (174, 'userimportmgr_redirectToDefault', '', 12);
INSERT INTO permission VALUES (175, 'usermgr', '', 12);
INSERT INTO permission VALUES (176, 'usermgr_redirectToDefault', '', 12);
INSERT INTO permission VALUES (177, 'usermgr_search', '', 12);
INSERT INTO permission VALUES (178, 'usermgr_syncToRole', '', 12);
INSERT INTO permission VALUES (179, 'userpreferencemgr', '', 12);
INSERT INTO permission VALUES (180, 'userpreferencemgr_redirectToDefault', '', 12);
INSERT INTO permission VALUES (181, 'rndmsgmgr', '', 13);
INSERT INTO permission VALUES (182, 'rndmsgmgr_redirectToDefault', '', 13);
INSERT INTO permission VALUES (183, 'articlemgr', '', 11);
INSERT INTO permission VALUES (184, 'articlemgr_redirectToDefault', '', 11);
INSERT INTO permission VALUES (185, 'articleviewmgr', '', 11);
INSERT INTO permission VALUES (186, 'documentmgr', '', 11);
INSERT INTO permission VALUES (187, 'documentmgr_redirectToDefault', '', 11);
INSERT INTO permission VALUES (188, 'filemgr', '', 11);
INSERT INTO permission VALUES (189, 'newslettermgr', '', 10);
INSERT INTO permission VALUES (190, 'newslettermgr_redirectToDefault', '', 10);
INSERT INTO permission VALUES (191, 'categorymgr', '', 9);
INSERT INTO permission VALUES (192, 'categorymgr_redirectToDefault', '', 9);
INSERT INTO permission VALUES (193, 'categorymgr_delete', '', 9);
INSERT INTO permission VALUES (194, 'navstylemgr', '', 9);
INSERT INTO permission VALUES (195, 'navstylemgr_redirectToDefault', '', 9);
INSERT INTO permission VALUES (196, 'pagemgr', '', 9);
INSERT INTO permission VALUES (197, 'pagemgr_redirectToDefault', '', 9);
INSERT INTO permission VALUES (198, 'contactmgr', '', 8);
INSERT INTO permission VALUES (199, 'contactmgr_redirectToDefault', '', 8);
INSERT INTO permission VALUES (200, 'imessagemgr', '', 8);
INSERT INTO permission VALUES (201, 'imessagemgr_redirectToDefault', '', 8);
INSERT INTO permission VALUES (202, 'imessagemgr_sendAlert', '', 8);
INSERT INTO permission VALUES (203, 'maintenancemgr', '', 7);
INSERT INTO permission VALUES (204, 'maintenancemgr_verify', '', 7);
INSERT INTO permission VALUES (205, 'maintenancemgr_redirectToDefault', '', 7);
INSERT INTO permission VALUES (206, 'maintenancemgr_checkAllModules', '', 7);
INSERT INTO permission VALUES (207, 'maintenancemgr_rebuildSequences', '', 7);
INSERT INTO permission VALUES (208, 'maintenancemgr_createModule', '', 7);
INSERT INTO permission VALUES (209, 'guestbookmgr', '', 6);
INSERT INTO permission VALUES (210, 'guestbookmgr_redirectToDefault', '', 6);
INSERT INTO permission VALUES (211, 'faqmgr', '', 5);
INSERT INTO permission VALUES (212, 'faqmgr_redirectToDefault', '', 5);
INSERT INTO permission VALUES (213, 'documentormgr', '', 4);
INSERT INTO permission VALUES (214, 'configmgr', '', 3);
INSERT INTO permission VALUES (215, 'configmgr_redirectToDefault', '', 3);
INSERT INTO permission VALUES (216, 'defaultmgr', '', 3);
INSERT INTO permission VALUES (217, 'modulemgr', '', 3);
INSERT INTO permission VALUES (218, 'modulemgr_redirectToDefault', '', 3);
INSERT INTO permission VALUES (219, 'modulemgr_edit', '', 3);
INSERT INTO permission VALUES (220, 'modulemgr_update', '', 3);
INSERT INTO permission VALUES (221, 'contactusmgr', '', 2);
INSERT INTO permission VALUES (222, 'contactusmgr_redirectToDefault', '', 2);
INSERT INTO permission VALUES (223, 'blockmgr', '', 1);
INSERT INTO permission VALUES (224, 'blockmgr_redirectToDefault', '', 1);

--
-- Dumping data for table user_permission
--

INSERT INTO user_permission VALUES (1, 2, 11);
INSERT INTO user_permission VALUES (2, 2, 10);
INSERT INTO user_permission VALUES (3, 2, 7);
INSERT INTO user_permission VALUES (4, 2, 6);
INSERT INTO user_permission VALUES (5, 2, 59);
INSERT INTO user_permission VALUES (6, 2, 58);
INSERT INTO user_permission VALUES (7, 2, 23);
INSERT INTO user_permission VALUES (8, 2, 122);
INSERT INTO user_permission VALUES (9, 2, 123);
INSERT INTO user_permission VALUES (10, 2, 98);
INSERT INTO user_permission VALUES (11, 2, 97);
INSERT INTO user_permission VALUES (12, 2, 93);
INSERT INTO user_permission VALUES (13, 2, 96);
INSERT INTO user_permission VALUES (14, 2, 94);
INSERT INTO user_permission VALUES (15, 2, 95);
INSERT INTO user_permission VALUES (16, 2, 37);
INSERT INTO user_permission VALUES (17, 2, 36);
INSERT INTO user_permission VALUES (18, 2, 38);
INSERT INTO user_permission VALUES (19, 2, 84);
INSERT INTO user_permission VALUES (20, 2, 85);
INSERT INTO user_permission VALUES (21, 2, 86);
INSERT INTO user_permission VALUES (22, 2, 41);
INSERT INTO user_permission VALUES (23, 2, 40);
INSERT INTO user_permission VALUES (24, 2, 46);
INSERT INTO user_permission VALUES (25, 2, 43);
INSERT INTO user_permission VALUES (26, 2, 39);
INSERT INTO user_permission VALUES (27, 2, 42);
INSERT INTO user_permission VALUES (28, 2, 45);
INSERT INTO user_permission VALUES (29, 2, 117);
INSERT INTO user_permission VALUES (30, 2, 118);
INSERT INTO user_permission VALUES (31, 2, 121);
INSERT INTO user_permission VALUES (32, 2, 105);
INSERT INTO user_permission VALUES (33, 2, 106);
INSERT INTO user_permission VALUES (34, 2, 142);
INSERT INTO user_permission VALUES (35, 2, 143);
INSERT INTO user_permission VALUES (36, 2, 67);
INSERT INTO user_permission VALUES (37, 2, 60);
INSERT INTO user_permission VALUES (38, 2, 62);
INSERT INTO user_permission VALUES (39, 2, 61);
INSERT INTO user_permission VALUES (40, 2, 63);
INSERT INTO user_permission VALUES (41, 2, 66);
INSERT INTO user_permission VALUES (42, 2, 147);
INSERT INTO user_permission VALUES (43, 2, 199);
INSERT INTO user_permission VALUES (44, 2, 222);
INSERT INTO user_permission VALUES (45, 2, 201);
INSERT INTO user_permission VALUES (46, 2, 149);
INSERT INTO user_permission VALUES (47, 2, 157);
INSERT INTO user_permission VALUES (48, 2, 165);
INSERT INTO user_permission VALUES (49, 2, 180);

--
-- Dumping data for table role_permission
--

INSERT INTO role_permission VALUES (1, 0, 11);
INSERT INTO role_permission VALUES (2, 0, 10);
INSERT INTO role_permission VALUES (3, 0, 7);
INSERT INTO role_permission VALUES (4, 0, 6);
INSERT INTO role_permission VALUES (5, 0, 59);
INSERT INTO role_permission VALUES (6, 0, 58);
INSERT INTO role_permission VALUES (7, 0, 23);
INSERT INTO role_permission VALUES (8, 0, 122);
INSERT INTO role_permission VALUES (9, 0, 123);
INSERT INTO role_permission VALUES (10, 0, 98);
INSERT INTO role_permission VALUES (11, 0, 97);
INSERT INTO role_permission VALUES (12, 0, 108);
INSERT INTO role_permission VALUES (13, 0, 107);
INSERT INTO role_permission VALUES (14, 2, 11);
INSERT INTO role_permission VALUES (15, 2, 10);
INSERT INTO role_permission VALUES (16, 2, 7);
INSERT INTO role_permission VALUES (17, 2, 6);
INSERT INTO role_permission VALUES (18, 2, 59);
INSERT INTO role_permission VALUES (19, 2, 58);
INSERT INTO role_permission VALUES (20, 2, 23);
INSERT INTO role_permission VALUES (21, 2, 122);
INSERT INTO role_permission VALUES (22, 2, 123);
INSERT INTO role_permission VALUES (23, 2, 98);
INSERT INTO role_permission VALUES (24, 2, 97);
INSERT INTO role_permission VALUES (25, 2, 93);
INSERT INTO role_permission VALUES (26, 2, 96);
INSERT INTO role_permission VALUES (27, 2, 94);
INSERT INTO role_permission VALUES (28, 2, 95);
INSERT INTO role_permission VALUES (29, 2, 37);
INSERT INTO role_permission VALUES (30, 2, 36);
INSERT INTO role_permission VALUES (31, 2, 38);
INSERT INTO role_permission VALUES (32, 2, 84);
INSERT INTO role_permission VALUES (33, 2, 85);
INSERT INTO role_permission VALUES (34, 2, 86);
INSERT INTO role_permission VALUES (36, 2, 41);
INSERT INTO role_permission VALUES (37, 2, 40);
INSERT INTO role_permission VALUES (38, 2, 46);
INSERT INTO role_permission VALUES (39, 2, 43);
INSERT INTO role_permission VALUES (40, 2, 39);
INSERT INTO role_permission VALUES (41, 2, 42);
INSERT INTO role_permission VALUES (42, 2, 45);
INSERT INTO role_permission VALUES (43, 2, 117);
INSERT INTO role_permission VALUES (44, 2, 118);
INSERT INTO role_permission VALUES (45, 2, 121);
INSERT INTO role_permission VALUES (46, 2, 105);
INSERT INTO role_permission VALUES (47, 2, 106);
INSERT INTO role_permission VALUES (48, 2, 142);
INSERT INTO role_permission VALUES (49, 2, 143);
INSERT INTO role_permission VALUES (50, 2, 67);
INSERT INTO role_permission VALUES (51, 2, 60);
INSERT INTO role_permission VALUES (52, 2, 62);
INSERT INTO role_permission VALUES (53, 2, 61);
INSERT INTO role_permission VALUES (54, 2, 63);
INSERT INTO role_permission VALUES (55, 2, 66);
INSERT INTO role_permission VALUES (56, 0, 84);
INSERT INTO role_permission VALUES (57, 0, 85);
INSERT INTO role_permission VALUES (58, 0, 86);
INSERT INTO role_permission VALUES (59, 2, 147);
INSERT INTO role_permission VALUES (60, 2, 199);
INSERT INTO role_permission VALUES (61, 2, 222);
INSERT INTO role_permission VALUES (62, 2, 201);
INSERT INTO role_permission VALUES (63, 2, 149);
INSERT INTO role_permission VALUES (64, 2, 157);
INSERT INTO role_permission VALUES (65, 2, 165);
INSERT INTO role_permission VALUES (66, 2, 180);
INSERT INTO role_permission VALUES (67, 0, 222);

--
-- Dumping data for sequence tables
--

INSERT INTO block_seq VALUES (10);
INSERT INTO block_assignment_seq VALUES (10);
INSERT INTO category_seq VALUES (1);
INSERT INTO document_type_seq VALUES (7);
INSERT INTO instant_message_seq VALUES (1);
INSERT INTO item_seq VALUES (1);
INSERT INTO item_addition_seq VALUES (2);
INSERT INTO item_type_seq VALUES (5);
INSERT INTO item_type_mapping_seq VALUES (8);
INSERT INTO module_seq VALUES (13);
INSERT INTO organisation_seq VALUES (2);
INSERT INTO permission_seq VALUES (225);
INSERT INTO preference_seq VALUES (8);
INSERT INTO role_seq VALUES (2);
INSERT INTO role_permission_seq VALUES (68);
INSERT INTO section_seq VALUES (15);
INSERT INTO user_permission_seq VALUES (50);
INSERT INTO user_preference_seq VALUES (7);
INSERT INTO usr_seq VALUES (2);
