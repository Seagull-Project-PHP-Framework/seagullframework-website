-- ==============================================================
--  DBMS name:      MaxDB 7.5                              
--  Created on:     2004-10-25 10:54:00
--  Changes:  org_preference.value -> org_preference.pref_value
--            user_preference.value -> user_preference.pref_value
-- ==============================================================


-- ==============================================================
--  Table: block                                                 
-- ==============================================================
create table block (
block_id             FIXED(10)                 not null,
name                 VARCHAR(64)          null,
title                VARCHAR(32)          null,
title_class          VARCHAR(32)          null,
body_class           VARCHAR(32)          null,
blk_order            FIXED(5)                 null,
is_onleft            FIXED(5)                 null,
is_enabled           FIXED(5)                 null,
constraint PK_BLOCK primary key (block_id)
);

-- ==============================================================
--  Table: block_assignment                                      
-- ==============================================================
create table block_assignment (
block_id             FIXED(10)                 not null,
section_id           FIXED(10)                 not null,
constraint PK_BLOCK_ASSIGNMENT primary key (block_id, section_id)
);

-- ==============================================================
--  Index: block_assignment_fk                                   
-- ==============================================================
create  index block_assignment_fk on block_assignment (
block_id
);

-- ==============================================================
--  Index: block_assignment_fk2                                  
-- ==============================================================
create  index block_assignment_fk2 on block_assignment (
section_id
);

-- ==============================================================
--  Table: category                                              
-- ==============================================================
create table category (
category_id          FIXED(10)                 not null,
parent               FIXED(10)                 null,
label                VARCHAR(255)         null,
perms                VARCHAR(255)         null,
constraint PK_CATEGORY primary key (category_id)
);

-- ==============================================================
--  Index: parent_fk                                             
-- ==============================================================
create  index parent_fk on category (
parent
);

-- ==============================================================
--  Table: contact                                               
-- ==============================================================
create table contact (
contact_id           FIXED(10)                 not null,
usr_id               FIXED(10)                 not null,
originator_id        FIXED(10)                 null,
date_created         TIMESTAMP            not null,
constraint PK_CONTACT primary key (contact_id)
);

-- ==============================================================
--  Index: usr_contact_fk                                        
-- ==============================================================
create  index usr_contact_fk on contact (
usr_id
);

-- ==============================================================
--  Table: contact_us                                            
-- ==============================================================
create table contact_us (
contact_us_id        FIXED(10)                 not null,
first_name           VARCHAR(64)          null,
last_name            VARCHAR(32)          null,
email                VARCHAR(128)         null,
enquiry_type         VARCHAR(32)          null,
enquiry_comment      LONG                 null,
constraint PK_CONTACT_US primary key (contact_us_id)
);

-- ==============================================================
--  Table: document                                              
-- ==============================================================
create table document (
document_id          FIXED(10)                 not null,
category_id          FIXED(10)                 null,
document_type_id     FIXED(10)                 not null,
name                 VARCHAR(128)         null,
size                 FIXED(10)                 null,
mime_type            VARCHAR(32)          null,
date_created         TIMESTAMP            null,
added_by             FIXED(10)                 null,
description          LONG                 null,
num_times_downloaded FIXED(10)                 null,
constraint PK_DOCUMENT primary key (document_id)
);

-- ==============================================================
--  Index: document_document_type_fk                             
-- ==============================================================
create  index document_document_type_fk on document (
document_type_id
);

-- ==============================================================
--  Index: category_document_fk                                  
-- ==============================================================
create  index category_document_fk on document (
category_id
);

-- ==============================================================
--  Table: document_type                                         
-- ==============================================================
create table document_type (
document_type_id     FIXED(10)                 not null,
name                 VARCHAR(32)          null,
constraint PK_DOCUMENT_TYPE primary key (document_type_id)
);

-- ==============================================================
--  Table: faq                                                   
-- ==============================================================
create table faq (
faq_id               FIXED(10)                 not null,
date_created         TIMESTAMP            null,
last_updated         TIMESTAMP            null,
question             VARCHAR(255)         null,
answer               LONG                 null,
item_order           FIXED(10)                 null,
constraint PK_FAQ primary key (faq_id)
);

-- ==============================================================
--  Table: instant_message                                       
-- ==============================================================
create table instant_message (
instant_message_id   FIXED(10)                 not null,
user_id_from         FIXED(10)                 not null,
user_id_to           FIXED(10)                 not null,
msg_time             TIMESTAMP            null,
subject              VARCHAR(128)         null,
body                 LONG                 null,
delete_status        FIXED(5)                 null,
read_status          FIXED(5)                 null,
constraint PK_INSTANT_MESSAGE primary key (instant_message_id)
);

-- ==============================================================
--  Index: usr_instant_from_fk                                   
-- ==============================================================
create  index usr_instant_from_fk on instant_message (
user_id_to
);

-- ==============================================================
--  Index: ust_instant_to_fk                                     
-- ==============================================================
create  index ust_instant_to_fk on instant_message (
user_id_from
);

-- ==============================================================
--  Table: item                                                  
-- ==============================================================
create table item (
item_id              FIXED(10)                 not null,
category_id          FIXED(10)                 null,
item_type_id         FIXED(10)                 not null,
created_by_id        FIXED(10)                 null,
updated_by_id        FIXED(10)                 null,
date_created         TIMESTAMP            null,
last_updated         TIMESTAMP            null,
start_date           TIMESTAMP            null,
expiry_date          TIMESTAMP            null,
status               FIXED(5)                 null,
constraint PK_ITEM primary key (item_id)
);

-- ==============================================================
--  Index: item_item_type_fk                                     
-- ==============================================================
create  index item_item_type_fk on item (
item_type_id
);

-- ==============================================================
--  Index: category_item_fk                                      
-- ==============================================================
create  index category_item_fk on item (
category_id
);

-- ==============================================================
--  Table: item_addition                                         
-- ==============================================================
create table item_addition (
item_addition_id     FIXED(10)                 not null,
item_id              FIXED(10)                 not null,
item_type_mapping_id FIXED(10)                 not null,
addition             LONG                 null,
constraint PK_ITEM_ADDITION primary key (item_addition_id)
);

-- ==============================================================
--  Index: item_item_addition_fk                                 
-- ==============================================================
create  index item_item_addition_fk on item_addition (
item_id
);

-- ==============================================================
--  Index: item_type_mapping_item_addition                       
-- ==============================================================
create  index item_type_mapping_item_addition on item_addition (
item_type_mapping_id
);

-- ==============================================================
--  Table: item_type                                             
-- ==============================================================
create table item_type (
item_type_id         FIXED(10)                 not null,
item_type_name       VARCHAR(64)          null,
constraint PK_ITEM_TYPE primary key (item_type_id)
);

-- ==============================================================
--  Table: item_type_mapping                                     
-- ==============================================================
create table item_type_mapping (
item_type_mapping_id FIXED(10)                 not null,
item_type_id         FIXED(10)                 not null,
field_name           VARCHAR(64)          null,
field_type           FIXED(5)                 null,
constraint PK_ITEM_TYPE_MAPPING primary key (item_type_mapping_id)
);

-- ==============================================================
--  Index: item_type_item_type_mapping_fk                        
-- ==============================================================
create  index item_type_item_type_mapping_fk on item_type_mapping (
item_type_id
);

-- ==============================================================
--  Table: log_table                                             
-- ==============================================================
create table log_table (
id                   FIXED(10)                 not null,
logtime              TIMESTAMP            not null,
ident                CHAR(16)             not null,
priority             FIXED(10)                 not null,
message              VARCHAR(200)         null,
constraint PK_LOG_TABLE primary key (id)
);

-- ==============================================================
--  Table: login                                                 
-- ==============================================================
create table login (
login_id             FIXED(10)                 not null,
usr_id               FIXED(10)                 null,
date_time            TIMESTAMP            null,
remote_ip            VARCHAR(16)          null,
constraint PK_LOGIN primary key (login_id)
);

-- ==============================================================
--  Table: module                                                 
-- ==============================================================

create table module (
module_id         FIXED(10) not null,
is_configurable   FIXED(5) null,
name              VARCHAR(255) null,
title             VARCHAR(255) null,
description       LONG         null,
admin_uri         VARCHAR(255) null,
icon              VARCHAR(255) null,
constraint PK_MODULE primary key (module_id)
);

-- ==============================================================
--  Index: usr_login_fk                                          
-- ==============================================================
create  index usr_login_fk on login (
usr_id
);

-- ==============================================================
--  Table: preference                                            
-- ==============================================================
create table preference (
preference_id        FIXED(10)                 not null,
name                 VARCHAR(128)         null,
default_value        VARCHAR(64)          null,
constraint PK_PREFERENCE primary key (preference_id)
);

-- ==============================================================
--  Table: section                                               
-- ==============================================================
create table section (
section_id           FIXED(10)                 not null,
title                VARCHAR(32)          null,
resource_uri         VARCHAR(128)         null,
perms                VARCHAR(16)          null,
parent_id            FIXED(10)                 null,
root_id              FIXED(10)                 null,
left_id              FIXED(10)                 null,
right_id             FIXED(10)                 null,
order_id             FIXED(10)                 null,
level_id             FIXED(10)                 null,
is_enabled           FIXED(5)                 null,
is_static            FIXED(5)                 null,
constraint PK_SECTION primary key (section_id)
);

-- ==============================================================
--  Index: root_id                                               
-- ==============================================================
create  index AK_key_root_id on section (
root_id
);

-- ==============================================================
--  Index: left_id                                               
-- ==============================================================
create  index AK_key_left_id on section (
left_id
);

-- ==============================================================
--  Index: ritgh_id                                              
-- ==============================================================
create  index AK_key_ritgh_id on section (
right_id
);

-- ==============================================================
--  Index: order_id                                              
-- ==============================================================
create  index AK_key_order_id on section (
order_id
);

-- ==============================================================
--  Index: level_id                                              
-- ==============================================================
create  index AK_key_level_id on section (
level_id
);

-- ==============================================================
--  Index: id_root_l_r                                           
-- ==============================================================
create  index AK_id_root_l_r on section (
section_id,
root_id,
left_id,
right_id
);

-- ==============================================================
--  Table: table_lock                                            
-- ==============================================================
create table table_lock (
lockID               CHAR(32)             not null,
lockTable            CHAR(32)             not null,
lockStamp            FIXED(10)                 null,
constraint PK_TABLE_LOCK primary key (lockID, lockTable)
);

-- ==============================================================
--  Table: org_preference                                       
-- ==============================================================
create table org_preference (
org_preference_id   FIXED(10)                 not null,
organisation_id      FIXED(10)                 not null default 0,
preference_id        FIXED(10)                 not null,
pref_value           VARCHAR(128)         null,
constraint PK_ORG_PREFERENCE primary key (org_preference_id)
);

-- ==============================================================
--  Index: organisation_org_preference_fk                               
-- ==============================================================
create  index organisation_org_preference_fk on org_preference (
organisation_id
);

-- ==============================================================
--  Index: preference_org_preference_fk                          
-- ==============================================================
create  index preference_org_preference_fk on org_preference (
preference_id
);

-- ==============================================================
--  Table: organization                                          
-- ==============================================================
CREATE TABLE organisation (
organisation_id fixed(10) NOT NULL,
parent_id fixed(10) NOT NULL default 0,
root_id fixed(10) NOT NULL default 0,
left_id fixed(10) NOT NULL default 0,
right_id fixed(10) NOT NULL default 0,
order_id fixed(10) NOT NULL default 0,
level_id fixed(10) NOT NULL default 0,
role_id fixed(10) NOT NULL default 0,
organisation_type_id fixed(10) NOT NULL default 0,
name varchar(128) default NULL,
description long,
addr_1 varchar(128) NOT NULL default '',
addr_2 varchar(128) default NULL,
addr_3 varchar(128) default NULL,
city varchar(32) NOT NULL default '',
region varchar(32) default NULL,
country varchar(32) default NULL,
post_code varchar(16) default NULL,
telephone varchar(32) default NULL,
website varchar(128) default NULL,
email varchar(128) default NULL,
date_created timestamp default NULL,
created_by fixed(10) default NULL,
last_updated timestamp default NULL,
updated_by fixed(10) default NULL,
constraint PK_ORGANISATION_ID primary key (organisation_id)
);

-- ==============================================================
--  Table: organisation_type                                     
-- ==============================================================
CREATE TABLE organisation_type (
organisation_type_id fixed(10) NOT NULL default 0,
name varchar(64) default NULL,
primary key (organisation_type_id)
);

-- ==============================================================
--  Table: permission                                            
-- ==============================================================
CREATE TABLE permission (
permission_id fixed(10) NOT NULL,
name varchar(255) default NULL,
description long,
module_id fixed(10) NOT NULL default 0,
CONSTRAINT PK_PERMISSION_ID PRIMARY KEY  (permission_id)
);

-- ==============================================================
--  Table: role                                                  
-- ==============================================================
CREATE TABLE role (
role_id fixed(10) NOT NULL,
name varchar(255) default NULL,
description long,
date_created timestamp default NULL,
created_by fixed(10) default NULL,
last_updated timestamp default NULL,
updated_by fixed(10) default NULL,	  
CONSTRAINT PK_ROLE_ID PRIMARY KEY (role_id)
);

-- ==============================================================
--  Table: role_permission                                       
-- ==============================================================
CREATE TABLE role_permission (
role_permission_id fixed(10) NOT NULL,
role_id fixed(10) NOT NULL default 0,
permission_id fixed(10) NOT NULL default 0,
CONSTRAINT PK_ROLE_PERMISSION_ID PRIMARY KEY (role_permission_id)
);

-- ==============================================================
--  Index: permission_id                                         
-- ==============================================================
create  index permission_id on role_permission (
permission_id
);

-- ==============================================================
--  Index: role_id                                               
-- ==============================================================
create  index role_id on role_permission (
role_id
);


-- ==============================================================
--  Table: user_preference                                       
-- ==============================================================
create table user_preference (
user_preference_id   FIXED(10)                 not null,
usr_id               FIXED(10)                 not null default 0,
preference_id        FIXED(10)                 not null,
pref_value            VARCHAR(128)         null,
constraint PK_USER_PREFERENCE primary key (user_preference_id)
);

-- ==============================================================
--  Index: usr_user_preferences_fk                               
-- ==============================================================
create  index usr_user_preferences_fk on user_preference (
usr_id
);

-- ==============================================================
--  Index: preference_user_preference_fk                          
-- ==============================================================
create  index preference_user_preference_fk on user_preference (
preference_id
);

-- ==============================================================
--  Table: usr                                                   
-- ==============================================================
create table usr (
usr_id               FIXED(10)                 not null,
organisation_id      FIXED(10)                 not null,
role_id              FIXED(10)                 not null,
username             VARCHAR(64)          null,
passwd               VARCHAR(32)          null,
first_name           VARCHAR(128)         null,
last_name            VARCHAR(128)         null,
telephone            VARCHAR(16)          null,
mobile               VARCHAR(16)          null,
email                VARCHAR(128)         null,
addr_1               VARCHAR(128)         null,
addr_2               VARCHAR(128)         null,
addr_3               VARCHAR(128)         null,
city                 VARCHAR(64)          null,
region               VARCHAR(32)          null,
country              VARCHAR(64)          null,
post_code            VARCHAR(16)          null,
is_email_public      FIXED(5)                 null,
is_acct_active       FIXED(5)                 null,
security_question    FIXED(5)                 null,
security_answer      VARCHAR(128)         null,
date_created         TIMESTAMP            null,
created_by           FIXED(10)                 null,
last_updated         TIMESTAMP            null,
updated_by           FIXED(10)                 null,
constraint PK_USR primary key (usr_id)
);

-- ==============================================================
--  Table: user_permission
-- ==============================================================
CREATE TABLE user_permission (
user_permission_id fixed(10) NOT NULL,
usr_id fixed(10) NOT NULL default 0,
permission_id fixed(10) NOT NULL default 0,
CONSTRAINT PK_USER_PERMISSION_ID PRIMARY KEY (user_permission_id)
);

-- ==============================================================
--  Index: usr_id
-- ==============================================================
create index usr_id on user_permission (
usr_id
);

-- ==============================================================
--  Index: usr_permission_id
-- ==============================================================
create index user_permission_id on user_permission (
permission_id
);

-- ==============================================================
--  Table: user_session
-- ==============================================================
create table user_session 
(
session_id                    VARCHAR(255)    not null,
last_updated                  TIMESTAMP       null,
data_value                    LONG            null,
constraint PK_SESSION primary key (session_id)
);

-- ==============================================================
--  Table: rndmsg_message
-- ==============================================================
create table rndmsg_message (
rndmsg_message_id             FIXED(10)            not null,
msg                           LONG            null,
constraint PK_RNDMSG_MESSAGE primary key (rndmsg_message_id)
);

-- ==============================================================
--  Table: guestbook
-- ==============================================================
create table guestbook (
guestbook_id    FIXED(10)                 not null,
date_created    TIMESTAMP            null,
name            VARCHAR(255)         null,
email           VARCHAR(255)         null,
message         LONG                 null,
constraint PK_GUESTBOOK primary key (guestbook_id)
);

-- ==============================================================
--  create sequence tables
-- ==============================================================
create table block_seq (ID FIXED(10) PRIMARY KEY not null);
create table block_assignment_seq (ID FIXED(10) PRIMARY KEY not null);
create table category_seq (ID FIXED(10) PRIMARY KEY not null);
create table document_type_seq (ID FIXED(10) PRIMARY KEY not null);
create table instant_message_seq (ID FIXED(10) PRIMARY KEY not null);
create table item_seq (ID FIXED(10) PRIMARY KEY not null);
create table item_addition_seq (ID FIXED(10) PRIMARY KEY not null);
create table item_type_seq (ID FIXED(10) PRIMARY KEY not null);
create table item_type_mapping_seq (ID FIXED(10) PRIMARY KEY not null);
create table module_seq (ID FIXED(10) PRIMARY KEY not null);
create table organisation_seq (ID FIXED(10) PRIMARY KEY not null);
create table permission_seq (ID FIXED(10) PRIMARY KEY not null);
create table preference_seq (ID FIXED(10) PRIMARY KEY not null);
create table role_seq (ID FIXED(10) PRIMARY KEY not null);
create table role_permission_seq (ID FIXED(10) PRIMARY KEY not null);
create table section_seq (ID FIXED(10) PRIMARY KEY not null);
create table user_permission_seq (ID FIXED(10) PRIMARY KEY not null);
create table user_preference_seq (ID FIXED(10) PRIMARY KEY not null);
create table usr_seq (ID FIXED(10) PRIMARY KEY not null);


-- ==============================================================
--  create foreign keys
-- ==============================================================
alter table role_permission add foreign key (role_id) references Role (role_id) on delete cascade;
alter table role_permission add foreign key (permission_id) references Permission (permission_id) on delete cascade;
alter table user_permission add foreign key (permission_id) references permission (permission_id) on delete cascade;
alter table user_permission add foreign key (usr_id) references usr (usr_id) on delete cascade;
alter table user_preference add foreign key (usr_id) references usr (usr_id) on delete cascade;
alter table user_preference add foreign key (preference_id) references preference (preference_id) on delete cascade;
alter table org_preference add foreign key (organisation_id) references organisation (organisation_id) on delete cascade;
alter table org_preference add foreign key (preference_id) references preference (preference_id) on delete cascade;
alter table block_assignment add constraint FK_block_assignment_block foreign key (block_id) references block (block_id) on delete restrict ;
alter table block_assignment add constraint FK_block_assignment_section foreign key (section_id) references section (section_id) on delete restrict;
--alter table category add constraint FK_parent foreign key (parent) references category (category_id) on delete restrict;
alter table document add constraint FK_category_document foreign key (category_id) references category (category_id) on delete restrict;
alter table document add constraint FK_document_document_type foreign key (document_type_id)  references document_type (document_type_id) on delete restrict;
alter table instant_message add constraint FK_usr_instant_from foreign key (user_id_to) references usr (usr_id) on delete restrict;
alter table instant_message add constraint FK_ust_instant_to foreign key (user_id_from) references usr (usr_id) on delete restrict;
alter table item add constraint FK_category_item foreign key (category_id) references category (category_id) on delete restrict;
alter table item add constraint FK_item_item_type foreign key (item_type_id) references item_type (item_type_id) on delete restrict;
alter table item_addition add constraint FK_item_item_addition foreign key (item_id) references item (item_id) on delete restrict;
alter table item_addition add constraint FK_item_type_mapping_item_additi foreign key (item_type_mapping_id) references item_type_mapping (item_type_mapping_id) on delete restrict;
alter table item_type_mapping add constraint FK_item_type_item_type_mapping foreign key (item_type_id) references item_type (item_type_id) on delete restrict;
alter table login add constraint FK_usr_login foreign key (usr_id) references usr (usr_id) on delete restrict;

-- FKs already defined with rule cascade
-- alter table user_preference add constraint FK_preferene_user_preference foreign key (preference_id)
--       references preference (preference_id) on delete restrict
-- on update restrict (deactivated because MaxDB doesn't support update rules)
--
-- alter table user_preference add constraint FK_usr_user_preferences foreign key (usr_id)
--       references usr (usr_id) on delete restrict
-- on update restrict (deactivated because MaxDB doesn't support update rules)
