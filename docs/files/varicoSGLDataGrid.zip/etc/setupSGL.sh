#!/bin/sh
# +---------------------------------------------------------------------------+
# | Seagull 0.3                                                               |
# +---------------------------------------------------------------------------+
# | setupSGL.sh                                                               |
# +---------------------------------------------------------------------------+
# | Copyright (c) 2004 Demian Turner                                          |
# |                                                                           |
# | Authors: Demian Turner <demian@phpkitchen.com>                            |
# |          Thomas Moulard <thomas.moulard@wanadoo.fr>                       |
# +---------------------------------------------------------------------------+
# |                                                                           |
# | This library is free software; you can redistribute it and/or             |
# | modify it under the terms of the GNU Library General Public               |
# | License as published by the Free Software Foundation; either              |
# | version 2 of the License, or (at your option) any later version.          |
# |                                                                           |
# | This library is distributed in the hope that it will be useful,           |
# | but WITHOUT ANY WARRANTY; without even the implied warranty of            |
# | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU         |
# | Library General Public License for more details.                          |
# |                                                                           |
# | You should have received a copy of the GNU Library General Public         |
# | License along with this library; if not, write to the Free                |
# | Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA |
# |                                                                           |
# | $Id: setupSGL.sh,v 1.1.1.1 2005/03/07 12:14:06 grzegorzdb Exp $                  |
# +---------------------------------------------------------------------------+

# +---------------------------------------------------------------------------+
# | Script to setup and install Seagull Framework                             |
# |                                                                           |
# | Note:   To setup the Seagull tarball, run this script as root in the      |
# |         directory where you want it to be installed, ie, /var/www/html.   |
# |         Please keep in mind an empty database named 'seagull' must exist  |
# |         for the script to execute correctly.                              |
# +---------------------------------------------------------------------------+

# +---------------------------------------------------------------------------+
# | setup vars, adjust to your requirements                                   |
# +---------------------------------------------------------------------------+
# +++ GENERAL OPTIONS +++
    # target directory where Seagull will be located once decompressed
    SGL_INSTALL_DIR=/var/www/html/seagull       
    
# +++ MYSQL +++
    # type of the DB
        # Possible values:
        # my: mysql
        # pg: postgres
        # mx: maxdb odbc
        # oci: oracle oci8
    DB_TYPE=my

    # name of the database (MUST EXIST)
    DB_NAME=seagull

    # name of database server (only for maxdb)
    DB_HOST=localhost

    # command line interface for SQL command (only for maxdb and oracle)
    DB_CLI=/raid/oracle/product/8.1.7/bin/sqlplus

    # valid SQL account to setup DB
    DB_USER=username
    DB_PASSWD=passwd

    # sql dump of tables that will be used to setup the DB
    SQL_SCHEMA_FILE=$SGL_INSTALL_DIR/etc/schema.$DB_TYPE.sql
        # replace 'default' by 'sample' for a demo application
    SQL_DATA_FILE=$SGL_INSTALL_DIR/etc/data.default.$DB_TYPE.sql
    
# +++ FILE SYSTEM +++
    # user and group used by apache (often apache or nobody)
    APACHE_USER=nobody
    APACHE_GROUP=nogroup
    
    # account of the webmaster
    ACCOUNT_USER=username
    
# +++ SEAGULL OPTIONS +++
    # url of your site
    INSTALL_URL=http://www.example.com


# +---------------------------------------------------------------------------+
# | user is root ?                                                            |
# +---------------------------------------------------------------------------+
if [ `whoami` != 'root' ]
then
   echo "You must be root to run this script!"
   exit 0
fi


# +---------------------------------------------------------------------------+
# | catch null input, script must be run with zip archive as argument         |
# +---------------------------------------------------------------------------+
if [ $# == 0 ]
then
    echo "Usage: setupSGL.sh <archive_name>"
    echo ""
    echo "Example: ./setupSGL.sh seagull.0.3.7-bet3.tar.gz"
    echo ""
    exit 65
fi


if [ ! -f "$1" ]
then
    echo "The specified zip archive doesn't exist. Can't run installer."
    exit 75
fi

if [ $DB_TYPE != 'my' ] && [ $DB_TYPE != 'pg' ] && [ $DB_TYPE != 'mx' ] && [ $DB_TYPE != 'oci' ]
then
    echo "Unknown DB type: '$DB_TYPE'. Can't run installer."
    echo "Valid values are:"
    echo "* pg -> postgres"
    echo "* my -> mysql"
    echo "* mx -> maxdb"
    echo "* oci -> oracle"
    exit 75
fi

echo "Welcome to the Seagull setup script."
sleep 2


# +---------------------------------------------------------------------------+
# | delete old backup, if exists                                              |
# +---------------------------------------------------------------------------+
echo "... removing old backup if exists"
sleep 2
if [ -d "$SGL_INSTALL_DIR.orig" ]
then
    rm -rf $SGL_INSTALL_DIR.orig
fi


# +---------------------------------------------------------------------------+
# | rename existing install to backup                                         |
# +---------------------------------------------------------------------------+
echo "... backing up existing install if exists"
sleep 2
if [ -d "$SGL_INSTALL_DIR" ]
then
    mv  $SGL_INSTALL_DIR $SGL_INSTALL_DIR.orig -f
fi

# +---------------------------------------------------------------------------+
# | unzip current zipped archive                                              |
# +---------------------------------------------------------------------------+ 
echo "... decompressing archive"
sleep 2
/bin/tar xzf $1


# +---------------------------------------------------------------------------+
# | assign required permissions                                               |
# +---------------------------------------------------------------------------+ 
echo "... assigning permissions"
sleep 2
chown -R $ACCOUNT_USER:$APACHE_GROUP $SGL_INSTALL_DIR
chown -R $APACHE_USER $SGL_INSTALL_DIR/var
chown -R $APACHE_USER $SGL_INSTALL_DIR/www/themes/default/images/uploads
ls $SGL_INSTALL_DIR/modules/*/lang/*php | xargs chown $APACHE_USER
cp $SGL_INSTALL_DIR/etc/htaccess.dist $SGL_INSTALL_DIR/www/.htaccess


# +---------------------------------------------------------------------------+
# | update DB                                                                 |
# +---------------------------------------------------------------------------+ 
echo "Do you want to setup/update the DB (y/n)?"

printf "\a"
read setupDB

if [ $setupDB != 'y' ]
then
    echo "db will not be setup"
else
    echo "... db is being setup/updated"
    
    if [ $DB_TYPE == 'my' ]
    then
        mysql -u$DB_USER -pDB_PASSWD $DB_NAME < $SQL_SCHEMA_FILE
        mysql -u$DB_USER -pDB_PASSWD $DB_NAME < $SQL_DATA_FILE
    fi
    
    if [ $DB_TYPE == 'pg' ]
    then
        # TODO: change for postgres...
        mysql -u$DB_USER -pDB_PASSWD $DB_NAME < $SQL_SCHEMA_FILE
        mysql -u$DB_USER -pDB_PASSWD $DB_NAME < $SQL_DATA_FILE
    fi

    if [ $DB_TYPE == 'mx' ]
    then
        $DB_CLI -n $DB_HOST -d $DB_NAME -u $DB_USER,$DB_PASSWD -c '--' -i $SQL_SCHEMA_FILE
        $DB_CLI -n $DB_HOST -d $DB_NAME -u $DB_USER,$DB_PASSWD -c '--' -i $SQL_DATA_FILE
    fi

    if [ $DB_TYPE == 'oci' ]
    then
        $DB_CLI $DB_USER/$DB_PASSWD@$DB_NAME @$SQL_SCHEMA_FILE
        $DB_CLI $DB_USER/$DB_PASSWD@$DB_NAME @$SQL_DATA_FILE
    fi
fi



echo ""
echo "To finish the installation, you must modify the following file:"
echo ""
echo "*********************************************************"
echo "*  $SGL_INSTALL_DIR/var/<SERVER_NAME>.default.conf.php"
echo "*-------------------------------------------------------"
echo "* [line 2] type = $DB_TYPE"
echo "* [line 3] host = $DB_HOST"
echo "* [line 5] user = $DB_USER"
echo "* [line 6] pass = /* type your pass here */"
echo "* [line 7] name = $DB_NAME"
echo "*********************************************************"
echo ""
echo "*********************************************************"
echo ""
echo ""
echo "Install and setup finished, thanks for using Seagull!"
