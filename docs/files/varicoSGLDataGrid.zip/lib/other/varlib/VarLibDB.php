<?php
/* Reminder: always indent with 4 spaces (no tabs). */
// +---------------------------------------------------------------------------+
// | SYSTEM LACINSKI 2.0                                                       |
// +---------------------------------------------------------------------------+
// |VarLibDB.php                                                               |
// +---------------------------------------------------------------------------+
// | Copyright (c) 2005 Varico.com                                             |
// |                                                                           |
// | Author: Varico <varico@varico.com>                                        |
// +---------------------------------------------------------------------------+
// |                                                                           |
// |Varico Lincence                                                            |
// |                                                                           |
// +---------------------------------------------------------------------------+

/* VarLibDB 
 * This class contains all DB methods necessary in S�2.0 
 *
 */
 
 class VarLibDB {
    
    function varLibDB() {
        
    }
    
    /** 
     * autoExecuteInsert
     * @param string $tableName 
     * @param string $primaryKey
     * @param string $tableData 
     * @param string $msg
     * @return integer $nextId id number added record
     */
    function autoExecuteInsert($tableName, $primaryKey, $tableData, $msg='') {
        $dbh = & SGL_DB::singleton();
        $nextId = $dbh->nextId($tableName);
        $tableData['date_add'] = SGL::getTime(true);
        $tableData['user_add'] = SGL_HTTP_Session::getUserType();
        $tableData[$primaryKey] = $nextId;
            
        $sth = $dbh->autoExecute($tableName, $tableData, DB_AUTOQUERY_INSERT);
        if($sth == 1) {
            SGL::raiseMsg($msg);
        }
        else {
            SGL::raiseMsg('There was a problem to insert record');
            SGL::raiseError('There was a problem to insert record', SGL_ERROR_NOAFFECTEDROWS);
        }   
        return $nextId;
    }   
    
     /** 
     * autoExecuteUpdate
     * @param string $tableName 
     * @param string $primaryKey
     * @param string $tableData 
     * @param integer $id
     * @param string $msg
     */
    function autoExecuteUpdate($tableName, $primaryKey, $tableData, $id, $msg='') {
        $dbh = & SGL_DB::singleton();
        $tableData['date_modify'] = SGL::getTime(true);
        $tableData['user_modify'] = SGL_HTTP_Session::getUserType();
            
        $sth = $dbh->autoExecute($tableName, $tableData, DB_AUTOQUERY_UPDATE, 
                                $primaryKey . '=' . $id);
        if($sth == 1) {
            SGL::raiseMsg($msg);
        }
        else {
            SGL::raiseMsg('There was a problem to update record');
            SGL::raiseError('update record failed', SGL_ERROR_NOAFFECTEDROWS);
        }      
    }   
 }

?>