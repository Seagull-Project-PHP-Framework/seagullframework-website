<?php
class Common {

    function common() {

    }
/**
 * This function return array accept dataGrid lang
 * @return array
 */
 function getAcceptDataGridLang() {
    $acceptLangDataGrid = explode(',', $GLOBALS['HTTP_ACCEPT_LANGUAGE']);
    $acceptLangDataBase = array('pl', 'en');
    foreach($acceptLangDataGrid as $langType) {
        $acceptArray = explode(';', $langType);
        $acceptLangList[] = $acceptArray[0];
    }

    foreach($acceptLangList as $acceptLang) {
            if (in_array($acceptLang, $acceptLangDataBase)) {
                $language[] = $acceptLang;
            }
    }

    if (isset($language)) {
        return $language;
    }
 }


 /**
  * Function quickFormFlexyCompile
  * @param Object $form references to form object
  * @param String $templateFileName
  * @return Object variable to template
  */
 function quickFormFlexyCompile(& $form, $templateFileName) {
    // setup a template object
        $options = &PEAR::getStaticProperty('HTML_Template_Flexy','options');
        $module = $GLOBALS['_SGL']['REQUEST']['moduleName'];
        $theme = $GLOBALS['HTTP_SESSION_VARS']['aPrefs']['theme'];
        $options = array(
            'templateDir'       =>  SGL_THEME_DIR . '/' . $theme . '/' . $module . PATH_SEPARATOR .
                                    SGL_THEME_DIR . '/default/' . $module . PATH_SEPARATOR .
                                    SGL_THEME_DIR . '/' . $theme . '/default'. PATH_SEPARATOR .
                                    SGL_THEME_DIR . '/default/default',
            'templateDirOrder'  => 'reverse',
            'multiSource'       => true,
            'compileDir'        => SGL_CACHE_DIR . '/tmpl/' . $theme,
            'forceCompile'      => SGL_FLEXY_FORCE_COMPILE,
            'debug'             => SGL_FLEXY_DEBUG,
            'allowPHP'          => SGL_FLEXY_ALLOW_PHP,
            'filters'           => SGL_FLEXY_FILTERS,
            'locale'            => SGL_FLEXY_LOCALE,
            'compiler'          => SGL_FLEXY_COMPILER,
            'valid_functions'   => SGL_FLEXY_VALID_FNS,
            'flexyIgnore'       => SGL_FLEXY_IGNORE,
            'globals'           => true,
            'globalfunctions'   => SGL_FLEXY_GLOBAL_FNS,
        );
        $template = new HTML_Template_Flexy($options);
        $renderer =& new HTML_QuickForm_Renderer_ObjectFlexy($template);
        $form->accept($renderer);

        $view = new StdClass;
        $view->form = $renderer->toObject();

        $template->compile($templateFileName);
        return $renderer->toObject();
 }

 function generateMultiLanguageField(& $form, $type, $preName = '', $name,
                                     $title, $options = array(), $value = array(),
                                     $ruleMsg = '', $ruleType = '') {
         $acceptLanguage = Common::getAcceptDataGridLang();
         foreach($acceptLanguage as $lang) {
            $shortFieldName = $name . $lang;
            $fieldTitle = $title . "[$lang]";
            if (isset($preName)) {
                $fullFieldName = $preName . '[' . $name . $lang . ']';
            }
            else {
                $fullFieldName = $name . $lang;
            }
            $fieldValue = $value->$shortFieldName;
            $options['value'] = $fieldValue;
            $form->addElement($type, $fullFieldName, $fieldTitle, $options);
            if (isset($ruleMsg) && isset($ruleType)) {
                $form->addRule($fullFieldName, $ruleMsg, $ruleType);
            }
        }

 }
}
?>
