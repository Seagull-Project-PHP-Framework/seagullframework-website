<?php
# This file is generated!
$funcs = array (
  'swf_ortho' => 
  array (
    'init' => '4.0.1',
  ),
  'swf_ortho2' => 
  array (
    'init' => '4.0.0',
  ),
  'swf_perspective' => 
  array (
    'init' => '4.0.0',
  ),
  'swf_openfile' => 
  array (
    'init' => '4.0.0',
  ),
  'swf_oncondition' => 
  array (
    'init' => '4.0.0',
  ),
  'swf_modifyobject' => 
  array (
    'init' => '4.0.0',
  ),
  'swf_mulcolor' => 
  array (
    'init' => '4.0.0',
  ),
  'swf_nextid' => 
  array (
    'init' => '4.0.0',
  ),
  'swf_placeobject' => 
  array (
    'init' => '4.0.0',
  ),
  'swf_polarview' => 
  array (
    'init' => '4.0.0',
  ),
  'swf_scale' => 
  array (
    'init' => '4.0.0',
  ),
  'swf_setfont' => 
  array (
    'init' => '4.0.0',
  ),
  'swf_setframe' => 
  array (
    'init' => '4.0.0',
  ),
  'swf_rotate' => 
  array (
    'init' => '4.0.0',
  ),
  'swf_removeobject' => 
  array (
    'init' => '4.0.0',
  ),
  'swf_popmatrix' => 
  array (
    'init' => '4.0.0',
  ),
  'swf_posround' => 
  array (
    'init' => '4.0.0',
  ),
  'swf_pushmatrix' => 
  array (
    'init' => '4.0.0',
  ),
  'swf_lookat' => 
  array (
    'init' => '4.0.0',
  ),
  'swf_labelframe' => 
  array (
    'init' => '4.0.0',
  ),
  'swf_definepoly' => 
  array (
    'init' => '4.0.0',
  ),
  'swf_definerect' => 
  array (
    'init' => '4.0.0',
  ),
  'swf_definetext' => 
  array (
    'init' => '4.0.0',
  ),
  'swf_defineline' => 
  array (
    'init' => '4.0.0',
  ),
  'swf_definefont' => 
  array (
    'init' => '4.0.0',
  ),
  'swf_addcolor' => 
  array (
    'init' => '4.0.0',
  ),
  'swf_closefile' => 
  array (
    'init' => '4.0.0',
  ),
  'swf_definebitmap' => 
  array (
    'init' => '4.0.0',
  ),
  'swf_endbutton' => 
  array (
    'init' => '4.0.0',
  ),
  'swf_enddoaction' => 
  array (
    'init' => '4.0.0',
  ),
  'swf_getbitmapinfo' => 
  array (
    'init' => '4.0.0',
  ),
  'swf_getfontinfo' => 
  array (
    'init' => '4.0.0',
  ),
  'swf_getframe' => 
  array (
    'init' => '4.0.0',
  ),
  'swf_fonttracking' => 
  array (
    'init' => '4.0.0',
  ),
  'swf_fontslant' => 
  array (
    'init' => '4.0.0',
  ),
  'swf_endshape' => 
  array (
    'init' => '4.0.0',
  ),
  'swf_endsymbol' => 
  array (
    'init' => '4.0.0',
  ),
  'swf_fontsize' => 
  array (
    'init' => '4.0.0',
  ),
  'swf_shapearc' => 
  array (
    'init' => '4.0.0',
  ),
  'swf_shapecurveto' => 
  array (
    'init' => '4.0.0',
  ),
  'udm_alloc_agent' => 
  array (
    'init' => '4.0.5',
    'ext' => 'ext_mnogosearch',
  ),
  'udm_alloc_agent_array' => 
  array (
    'init' => '4.3.3',
    'ext' => 'ext_mnogosearch',
  ),
  'udm_api_version' => 
  array (
    'init' => '4.0.5',
    'ext' => 'ext_mnogosearch',
  ),
  'udm_add_search_limit' => 
  array (
    'init' => '4.0.5',
    'ext' => 'ext_mnogosearch',
  ),
  'trigger_error' => 
  array (
    'init' => '4.0.1',
    'ext' => 'zend',
  ),
  'tanh' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_standard',
  ),
  'token_get_all' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_tokenizer',
  ),
  'token_name' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_tokenizer',
  ),
  'udm_cat_list' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_mnogosearch',
  ),
  'udm_cat_path' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_mnogosearch',
  ),
  'udm_errno' => 
  array (
    'init' => '4.0.5',
    'ext' => 'ext_mnogosearch',
  ),
  'udm_error' => 
  array (
    'init' => '4.0.5',
    'ext' => 'ext_mnogosearch',
  ),
  'udm_find' => 
  array (
    'init' => '4.0.5',
    'ext' => 'ext_mnogosearch',
  ),
  'udm_crc32' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_mnogosearch',
  ),
  'udm_close_stored' => 
  array (
    'init' => '4.2.0',
  ),
  'udm_check_charset' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_mnogosearch',
  ),
  'udm_check_stored' => 
  array (
    'init' => '4.2.0',
  ),
  'udm_clear_search_limits' => 
  array (
    'init' => '4.0.5',
    'ext' => 'ext_mnogosearch',
  ),
  'sybase_unbuffered_query' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_sybase_ct',
  ),
  'sybase_set_message_handler' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_sybase_ct',
  ),
  'swf_shapelinesolid' => 
  array (
    'init' => '4.0.0',
  ),
  'swf_shapelineto' => 
  array (
    'init' => '4.0.0',
  ),
  'swf_shapemoveto' => 
  array (
    'init' => '4.0.0',
  ),
  'swf_shapefillsolid' => 
  array (
    'init' => '4.0.0',
  ),
  'swf_shapefilloff' => 
  array (
    'init' => '4.0.0',
  ),
  'swf_shapecurveto3' => 
  array (
    'init' => '4.0.0',
  ),
  'swf_shapefillbitmapclip' => 
  array (
    'init' => '4.0.0',
  ),
  'swf_shapefillbitmaptile' => 
  array (
    'init' => '4.0.0',
  ),
  'swf_showframe' => 
  array (
    'init' => '4.0.0',
  ),
  'swf_startbutton' => 
  array (
    'init' => '4.0.0',
  ),
  'swf_viewport' => 
  array (
    'init' => '4.0.0',
  ),
  'sybase_deadlock_retry_count' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_sybase_ct',
  ),
  'sybase_fetch_assoc' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_sybase_ct',
  ),
  'swf_translate' => 
  array (
    'init' => '4.0.0',
  ),
  'swf_textwidth' => 
  array (
    'init' => '4.0.0',
  ),
  'swf_startdoaction' => 
  array (
    'init' => '4.0.0',
  ),
  'swf_startshape' => 
  array (
    'init' => '4.0.0',
  ),
  'swf_startsymbol' => 
  array (
    'init' => '4.0.0',
  ),
  'swf_addbuttonrecord' => 
  array (
    'init' => '4.0.0',
  ),
  'swf_actionwaitforframe' => 
  array (
    'init' => '4.0.0',
  ),
  'socket_writev' => 
  array (
    'init' => '4.1.0',
  ),
  'spliti' => 
  array (
    'init' => '4.0.1',
    'ext' => 'ext_standard',
  ),
  'sscanf' => 
  array (
    'init' => '4.0.1',
    'ext' => 'ext_standard',
  ),
  'socket_write' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_sockets',
  ),
  'socket_strerror' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_sockets',
  ),
  'socket_set_option' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_sockets',
  ),
  'socket_set_timeout' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_standard',
  ),
  'socket_shutdown' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_sockets',
  ),
  'strcoll' => 
  array (
    'init' => '4.0.5',
    'ext' => 'ext_standard',
  ),
  'streammp3' => 
  array (
    'init' => '4.0.5',
  ),
  'stream_filter_prepend' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_standard',
  ),
  'stream_get_meta_data' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_standard',
  ),
  'stream_register_wrapper' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_standard',
  ),
  'stream_filter_append' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_standard',
  ),
  'stream_context_set_params' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_standard',
  ),
  'stream_context_create' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_standard',
  ),
  'stream_context_get_options' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_standard',
  ),
  'stream_context_set_option' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_standard',
  ),
  'socket_set_nonblock' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_sockets',
  ),
  'socket_set_blocking' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_standard',
  ),
  'socket_last_error' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_sockets',
  ),
  'socket_listen' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_sockets',
  ),
  'socket_read' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_sockets',
  ),
  'socket_iovec_set' => 
  array (
    'init' => '4.1.0',
  ),
  'socket_iovec_free' => 
  array (
    'init' => '4.1.0',
  ),
  'socket_iovec_alloc' => 
  array (
    'init' => '4.1.0',
  ),
  'socket_iovec_delete' => 
  array (
    'init' => '4.1.0',
  ),
  'socket_iovec_fetch' => 
  array (
    'init' => '4.1.0',
  ),
  'socket_readv' => 
  array (
    'init' => '4.1.0',
  ),
  'socket_recv' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_sockets',
  ),
  'socket_sendto' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_sockets',
  ),
  'socket_setopt' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_sockets',
  ),
  'socket_set_block' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_sockets',
  ),
  'socket_sendmsg' => 
  array (
    'init' => '4.1.0',
  ),
  'socket_send' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_sockets',
  ),
  'socket_recvfrom' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_sockets',
  ),
  'socket_recvmsg' => 
  array (
    'init' => '4.1.0',
  ),
  'socket_select' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_sockets',
  ),
  'stream_select' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_standard',
  ),
  'stream_set_blocking' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_standard',
  ),
  'swfshape' => 
  array (
    'init' => '4.0.5',
  ),
  'swfsprite' => 
  array (
    'init' => '4.0.5',
  ),
  'swftext' => 
  array (
    'init' => '4.0.5',
  ),
  'swfmovie' => 
  array (
    'init' => '4.0.5',
  ),
  'swfmorph' => 
  array (
    'init' => '4.0.5',
  ),
  'swffill' => 
  array (
    'init' => '4.0.5',
  ),
  'swffont' => 
  array (
    'init' => '4.0.5',
  ),
  'swfgradient' => 
  array (
    'init' => '4.0.5',
  ),
  'swftextfield' => 
  array (
    'init' => '4.0.5',
  ),
  'swf_actiongeturl' => 
  array (
    'init' => '4.0.0',
  ),
  'swf_actionsettarget' => 
  array (
    'init' => '4.0.0',
  ),
  'swf_actionstop' => 
  array (
    'init' => '4.0.0',
  ),
  'swf_actiontogglequality' => 
  array (
    'init' => '4.0.0',
  ),
  'swf_actionprevframe' => 
  array (
    'init' => '4.0.0',
  ),
  'swf_actionplay' => 
  array (
    'init' => '4.0.0',
  ),
  'swf_actiongotoframe' => 
  array (
    'init' => '4.0.0',
  ),
  'swf_actiongotolabel' => 
  array (
    'init' => '4.0.0',
  ),
  'swf_actionnextframe' => 
  array (
    'init' => '4.0.0',
  ),
  'swfbutton_keypress' => 
  array (
    'init' => '4.0.5',
  ),
  'swfbutton' => 
  array (
    'init' => '4.0.5',
  ),
  'strnatcasecmp' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_standard',
  ),
  'strnatcmp' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_standard',
  ),
  'strncasecmp' => 
  array (
    'init' => '4.0.2',
    'ext' => 'zend',
  ),
  'stripcslashes' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_standard',
  ),
  'strerror' => 
  array (
    'init' => '4.0.2',
  ),
  'stream_set_timeout' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_standard',
  ),
  'stream_set_write_buffer' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_standard',
  ),
  'stream_wrapper_register' => 
  array (
    'init' => '4.3.2',
    'ext' => 'ext_standard',
  ),
  'strncmp' => 
  array (
    'init' => '4.0.0',
    'ext' => 'zend',
  ),
  'str_pad' => 
  array (
    'init' => '4.0.1',
    'ext' => 'ext_standard',
  ),
  'substr_replace' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_standard',
  ),
  'swfaction' => 
  array (
    'init' => '4.0.5',
  ),
  'swfbitmap' => 
  array (
    'init' => '4.0.5',
  ),
  'substr_count' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_standard',
  ),
  'str_word_count' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_standard',
  ),
  'str_repeat' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_standard',
  ),
  'str_rot13' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_standard',
  ),
  'str_shuffle' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_standard',
  ),
  'udm_free_agent' => 
  array (
    'init' => '4.0.5',
    'ext' => 'ext_mnogosearch',
  ),
  'udm_free_ispell_data' => 
  array (
    'init' => '4.0.5',
    'ext' => 'ext_mnogosearch',
  ),
  'yaz_errno' => 
  array (
    'init' => '4.0.1',
  ),
  'yaz_error' => 
  array (
    'init' => '4.0.1',
  ),
  'yaz_es_result' => 
  array (
    'init' => '4.2.0',
  ),
  'yaz_element' => 
  array (
    'init' => '4.0.1',
  ),
  'yaz_database' => 
  array (
    'init' => '4.0.6',
  ),
  'yaz_ccl_parse' => 
  array (
    'init' => '4.0.5',
  ),
  'yaz_close' => 
  array (
    'init' => '4.0.1',
  ),
  'yaz_connect' => 
  array (
    'init' => '4.0.1',
  ),
  'yaz_hits' => 
  array (
    'init' => '4.0.1',
  ),
  'yaz_itemorder' => 
  array (
    'init' => '4.0.5',
  ),
  'yaz_schema' => 
  array (
    'init' => '4.2.0',
  ),
  'yaz_search' => 
  array (
    'init' => '4.0.1',
  ),
  'yaz_sort' => 
  array (
    'init' => '4.1.0',
  ),
  'yaz_scan_result' => 
  array (
    'init' => '4.0.5',
  ),
  'yaz_scan' => 
  array (
    'init' => '4.0.5',
  ),
  'yaz_present' => 
  array (
    'init' => '4.0.5',
  ),
  'yaz_range' => 
  array (
    'init' => '4.0.1',
  ),
  'yaz_record' => 
  array (
    'init' => '4.0.1',
  ),
  'yaz_ccl_conf' => 
  array (
    'init' => '4.0.5',
  ),
  'yaz_addinfo' => 
  array (
    'init' => '4.0.1',
  ),
  'xslt_process' => 
  array (
    'init' => '4.0.3',
  ),
  'xslt_run' => 
  array (
    'init' => '4.0.3',
  ),
  'xslt_setopt' => 
  array (
    'init' => '4.3.0',
  ),
  'xslt_output_endtransform' => 
  array (
    'init' => '4.0.3',
  ),
  'xslt_output_begintransform' => 
  array (
    'init' => '4.0.3',
  ),
  'xslt_free' => 
  array (
    'init' => '4.0.3',
  ),
  'xslt_getopt' => 
  array (
    'init' => '4.3.0',
  ),
  'xslt_openlog' => 
  array (
    'init' => '4.0.3',
  ),
  'xslt_set_base' => 
  array (
    'init' => '4.0.5',
  ),
  'xslt_set_encoding' => 
  array (
    'init' => '4.0.5',
  ),
  'xslt_set_scheme_handler' => 
  array (
    'init' => '4.0.5',
  ),
  'xslt_set_scheme_handlers' => 
  array (
    'init' => '4.0.6',
  ),
  'xslt_transform' => 
  array (
    'init' => '4.0.3',
  ),
  'xslt_set_sax_handlers' => 
  array (
    'init' => '4.0.6',
  ),
  'xslt_set_sax_handler' => 
  array (
    'init' => '4.0.3',
  ),
  'xslt_set_error_handler' => 
  array (
    'init' => '4.0.4',
  ),
  'xslt_set_log' => 
  array (
    'init' => '4.0.6',
  ),
  'xslt_set_object' => 
  array (
    'init' => '4.3.0',
  ),
  'yaz_syntax' => 
  array (
    'init' => '4.0.1',
  ),
  'yaz_wait' => 
  array (
    'init' => '4.0.1',
  ),
  'zzip_opendir' => 
  array (
    'init' => '4.0.5',
  ),
  'zzip_read' => 
  array (
    'init' => '4.0.5',
  ),
  'zzip_readdir' => 
  array (
    'init' => '4.0.5',
  ),
  'zzip_open' => 
  array (
    'init' => '4.0.5',
  ),
  'zzip_entry_name' => 
  array (
    'init' => '4.0.5',
  ),
  'zzip_entry_compressedsize' => 
  array (
    'init' => '4.0.5',
  ),
  'zzip_entry_compressionmethod' => 
  array (
    'init' => '4.0.5',
  ),
  'zzip_entry_filesize' => 
  array (
    'init' => '4.0.5',
  ),
  'affected_rows' => 
  array (
    'init' => '5.0.0',
  ),
  'array_combine' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_standard',
  ),
  'array_uintersect' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_standard',
  ),
  'array_uintersect_assoc' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_standard',
  ),
  'array_uintersect_uassoc' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_standard',
  ),
  'array_udiff_uassoc' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_standard',
  ),
  'array_udiff_assoc' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_standard',
  ),
  'array_diff_uassoc' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_standard',
  ),
  'array_intersect_uassoc' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_standard',
  ),
  'array_udiff' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_standard',
  ),
  'zzip_closedir' => 
  array (
    'init' => '4.0.5',
  ),
  'zzip_close' => 
  array (
    'init' => '4.0.5',
  ),
  'zend_test_func' => 
  array (
    'init' => '4.0.1',
    'ext' => 'zend',
  ),
  'zend_version' => 
  array (
    'init' => '4.0.0',
    'ext' => 'zend',
  ),
  'zip_close' => 
  array (
    'init' => '4.1.0',
  ),
  'zend_logo_guid' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_standard',
  ),
  'yp_err_string' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_yp',
  ),
  'yp_all' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_yp',
  ),
  'yp_cat' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_yp',
  ),
  'yp_errno' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_yp',
  ),
  'zip_entry_close' => 
  array (
    'init' => '4.1.0',
  ),
  'zip_entry_compressedsize' => 
  array (
    'init' => '4.1.0',
  ),
  'zip_open' => 
  array (
    'init' => '4.1.0',
  ),
  'zip_read' => 
  array (
    'init' => '4.1.0',
  ),
  'zlib_get_coding_type' => 
  array (
    'init' => '4.3.2',
    'ext' => 'ext_zlib',
  ),
  'zip_entry_read' => 
  array (
    'init' => '4.1.0',
  ),
  'zip_entry_open' => 
  array (
    'init' => '4.1.0',
  ),
  'zip_entry_compressionmethod' => 
  array (
    'init' => '4.1.0',
  ),
  'zip_entry_filesize' => 
  array (
    'init' => '4.1.0',
  ),
  'zip_entry_name' => 
  array (
    'init' => '4.1.0',
  ),
  'xslt_fetch_result' => 
  array (
    'init' => '4.0.3',
  ),
  'xslt_error' => 
  array (
    'init' => '4.0.3',
  ),
  'vpopmail_alias_get' => 
  array (
    'init' => '4.1.0',
  ),
  'vpopmail_alias_get_all' => 
  array (
    'init' => '4.1.0',
  ),
  'vpopmail_auth_user' => 
  array (
    'init' => '4.0.5',
  ),
  'vpopmail_alias_del_domain' => 
  array (
    'init' => '4.1.0',
  ),
  'vpopmail_alias_del' => 
  array (
    'init' => '4.1.0',
  ),
  'vpopmail_add_domain_ex' => 
  array (
    'init' => '4.0.5',
  ),
  'vpopmail_add_user' => 
  array (
    'init' => '4.0.5',
  ),
  'vpopmail_alias_add' => 
  array (
    'init' => '4.1.0',
  ),
  'vpopmail_del_domain' => 
  array (
    'init' => '4.0.5',
  ),
  'vpopmail_del_domain_ex' => 
  array (
    'init' => '4.0.5',
  ),
  'vsprintf' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_standard',
  ),
  'w32api_deftype' => 
  array (
    'init' => '4.2.0',
  ),
  'w32api_init_dtype' => 
  array (
    'init' => '4.2.0',
  ),
  'vprintf' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_standard',
  ),
  'vpopmail_set_user_quota' => 
  array (
    'init' => '4.0.5',
  ),
  'vpopmail_del_user' => 
  array (
    'init' => '4.0.5',
  ),
  'vpopmail_error' => 
  array (
    'init' => '4.0.5',
  ),
  'vpopmail_passwd' => 
  array (
    'init' => '4.0.5',
  ),
  'vpopmail_add_domain' => 
  array (
    'init' => '4.0.5',
  ),
  'vpopmail_add_alias_domain_ex' => 
  array (
    'init' => '4.0.5',
  ),
  'udm_hash32' => 
  array (
    'init' => '4.3.3',
    'ext' => 'ext_mnogosearch',
  ),
  'udm_load_ispell_data' => 
  array (
    'init' => '4.0.5',
    'ext' => 'ext_mnogosearch',
  ),
  'udm_make_excerpt' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_mnogosearch',
  ),
  'udm_get_res_param' => 
  array (
    'init' => '4.0.5',
    'ext' => 'ext_mnogosearch',
  ),
  'udm_get_res_field_ex' => 
  array (
    'init' => '4.3.3',
    'ext' => 'ext_mnogosearch',
  ),
  'udm_free_res' => 
  array (
    'init' => '4.0.5',
    'ext' => 'ext_mnogosearch',
  ),
  'udm_get_doc_count' => 
  array (
    'init' => '4.0.5',
    'ext' => 'ext_mnogosearch',
  ),
  'udm_get_res_field' => 
  array (
    'init' => '4.0.5',
    'ext' => 'ext_mnogosearch',
  ),
  'udm_open_stored' => 
  array (
    'init' => '4.2.0',
  ),
  'udm_parse_query_string' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_mnogosearch',
  ),
  'var_export' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_standard',
  ),
  'version_compare' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_standard',
  ),
  'vpopmail_add_alias_domain' => 
  array (
    'init' => '4.0.5',
  ),
  'user_error' => 
  array (
    'init' => '4.0.0',
    'ext' => 'zend',
  ),
  'unregister_tick_function' => 
  array (
    'init' => '4.0.3',
    'ext' => 'ext_standard',
  ),
  'udm_set_agent_param' => 
  array (
    'init' => '4.0.5',
    'ext' => 'ext_mnogosearch',
  ),
  'udm_set_agent_param_ex' => 
  array (
    'init' => '4.3.3',
    'ext' => 'ext_mnogosearch',
  ),
  'unixtojd' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_calendar',
  ),
  'w32api_invoke_function' => 
  array (
    'init' => '4.2.0',
  ),
  'w32api_register_function' => 
  array (
    'init' => '4.2.0',
  ),
  'xml_set_start_namespace_decl_handler' => 
  array (
    'init' => '4.0.5',
    'ext' => 'ext_xml',
  ),
  'xpath_eval' => 
  array (
    'init' => '4.0.4',
  ),
  'xpath_eval_expression' => 
  array (
    'init' => '4.0.4',
  ),
  'xml_set_object' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_xml',
  ),
  'xml_set_end_namespace_decl_handler' => 
  array (
    'init' => '4.0.5',
    'ext' => 'ext_xml',
  ),
  'xmlrpc_set_type' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_xmlrpc',
  ),
  'xmltree' => 
  array (
    'init' => '4.0.0',
  ),
  'xml_parser_create_ns' => 
  array (
    'init' => '4.0.5',
    'ext' => 'ext_xml',
  ),
  'xpath_new_context' => 
  array (
    'init' => '4.0.4',
  ),
  'xpath_register_ns' => 
  array (
    'init' => '4.2.0',
  ),
  'xslt_closelog' => 
  array (
    'init' => '4.0.3',
  ),
  'xslt_create' => 
  array (
    'init' => '4.0.3',
  ),
  'xslt_errno' => 
  array (
    'init' => '4.0.3',
  ),
  'xslt_backend_version' => 
  array (
    'init' => '4.3.0',
  ),
  'xslt_backend_name' => 
  array (
    'init' => '4.3.0',
  ),
  'xptr_eval' => 
  array (
    'init' => '4.0.4',
  ),
  'xptr_new_context' => 
  array (
    'init' => '4.0.4',
  ),
  'xslt_backend_info' => 
  array (
    'init' => '4.3.0',
  ),
  'xmlrpc_server_register_method' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_xmlrpc',
  ),
  'xmlrpc_server_register_introspection_callback' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_xmlrpc',
  ),
  'xmldocfile' => 
  array (
    'init' => '4.0.0',
  ),
  'xmlrpc_decode' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_xmlrpc',
  ),
  'xmlrpc_decode_request' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_xmlrpc',
  ),
  'xmldoc' => 
  array (
    'init' => '4.0.0',
  ),
  'writev' => 
  array (
    'init' => '4.0.2',
  ),
  'w32api_set_call_method' => 
  array (
    'init' => '4.2.0',
  ),
  'wordwrap' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_standard',
  ),
  'write' => 
  array (
    'init' => '4.0.2',
  ),
  'xmlrpc_encode' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_xmlrpc',
  ),
  'xmlrpc_encode_request' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_xmlrpc',
  ),
  'xmlrpc_server_call_method' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_xmlrpc',
  ),
  'xmlrpc_server_create' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_xmlrpc',
  ),
  'xmlrpc_server_destroy' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_xmlrpc',
  ),
  'xmlrpc_server_add_introspection_data' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_xmlrpc',
  ),
  'xmlrpc_parse_method_descriptions' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_xmlrpc',
  ),
  'xmlrpc_get_type' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_xmlrpc',
  ),
  'xmlrpc_is_fault' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_xmlrpc',
  ),
  'socket_iovec_add' => 
  array (
    'init' => '4.1.0',
  ),
  'socket_get_status' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_standard',
  ),
  'pg_fetch_result' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_pgsql',
  ),
  'pg_field_is_null' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_pgsql',
  ),
  'pg_field_name' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_pgsql',
  ),
  'pg_fetch_assoc' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_pgsql',
  ),
  'pg_fetch_all' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_pgsql',
  ),
  'pg_end_copy' => 
  array (
    'init' => '4.0.3',
    'ext' => 'ext_pgsql',
  ),
  'pg_escape_bytea' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_pgsql',
  ),
  'pg_escape_string' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_pgsql',
  ),
  'pg_field_num' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_pgsql',
  ),
  'pg_field_prtlen' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_pgsql',
  ),
  'pg_get_result' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_pgsql',
  ),
  'pg_insert' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_pgsql',
  ),
  'pg_last_error' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_pgsql',
  ),
  'pg_get_pid' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_pgsql',
  ),
  'pg_get_notify' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_pgsql',
  ),
  'pg_field_size' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_pgsql',
  ),
  'pg_field_type' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_pgsql',
  ),
  'pg_free_result' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_pgsql',
  ),
  'pg_delete' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_pgsql',
  ),
  'pg_copy_to' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_pgsql',
  ),
  'pdf_skew' => 
  array (
    'init' => '4.0.0',
  ),
  'pfpro_cleanup' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_pfpro',
  ),
  'pfpro_init' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_pfpro',
  ),
  'pdf_show_boxed' => 
  array (
    'init' => '4.0.0',
  ),
  'pdf_set_value' => 
  array (
    'init' => '4.0.1',
  ),
  'pdf_set_border_dash' => 
  array (
    'init' => '4.0.1',
  ),
  'pdf_set_info' => 
  array (
    'init' => '4.0.1',
  ),
  'pdf_set_parameter' => 
  array (
    'init' => '4.0.0',
  ),
  'pfpro_process' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_pfpro',
  ),
  'pfpro_process_raw' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_pfpro',
  ),
  'pg_connection_status' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_pgsql',
  ),
  'pg_convert' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_pgsql',
  ),
  'pg_copy_from' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_pgsql',
  ),
  'pg_connection_reset' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_pgsql',
  ),
  'pg_connection_busy' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_pgsql',
  ),
  'pfpro_version' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_pfpro',
  ),
  'pg_affected_rows' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_pgsql',
  ),
  'pg_cancel_query' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_pgsql',
  ),
  'pg_last_notice' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_pgsql',
  ),
  'pg_last_oid' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_pgsql',
  ),
  'pg_unescape_bytea' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_pgsql',
  ),
  'pg_untrace' => 
  array (
    'init' => '4.0.1',
    'ext' => 'ext_pgsql',
  ),
  'pg_update' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_pgsql',
  ),
  'pg_trace' => 
  array (
    'init' => '4.0.1',
    'ext' => 'ext_pgsql',
  ),
  'pg_send_query' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_pgsql',
  ),
  'pg_result_seek' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_pgsql',
  ),
  'pg_result_status' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_pgsql',
  ),
  'pg_select' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_pgsql',
  ),
  'phpcredits' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_standard',
  ),
  'php_ini_scanned_files' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_standard',
  ),
  'posix_get_last_error' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_posix',
  ),
  'posix_setegid' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_posix',
  ),
  'posix_seteuid' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_posix',
  ),
  'posix_errno' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_posix',
  ),
  'png2wbmp' => 
  array (
    'init' => '4.0.5',
    'ext' => 'ext_gd',
  ),
  'php_logo_guid' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_standard',
  ),
  'php_sapi_name' => 
  array (
    'init' => '4.0.1',
    'ext' => 'ext_standard',
  ),
  'php_uname' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_standard',
  ),
  'pg_result_error' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_pgsql',
  ),
  'pg_query' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_pgsql',
  ),
  'pg_lo_import' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_pgsql',
  ),
  'pg_lo_open' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_pgsql',
  ),
  'pg_lo_read' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_pgsql',
  ),
  'pg_lo_export' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_pgsql',
  ),
  'pg_lo_create' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_pgsql',
  ),
  'pg_loexport' => 
  array (
    'init' => '4.0.1',
    'ext' => 'ext_pgsql',
  ),
  'pg_loimport' => 
  array (
    'init' => '4.0.1',
    'ext' => 'ext_pgsql',
  ),
  'pg_lo_close' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_pgsql',
  ),
  'pg_lo_read_all' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_pgsql',
  ),
  'pg_lo_seek' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_pgsql',
  ),
  'pg_num_rows' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_pgsql',
  ),
  'pg_ping' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_pgsql',
  ),
  'pg_put_line' => 
  array (
    'init' => '4.0.3',
    'ext' => 'ext_pgsql',
  ),
  'pg_num_fields' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_pgsql',
  ),
  'pg_meta_data' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_pgsql',
  ),
  'pg_lo_tell' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_pgsql',
  ),
  'pg_lo_unlink' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_pgsql',
  ),
  'pg_lo_write' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_pgsql',
  ),
  'pdf_setpolydash' => 
  array (
    'init' => '4.0.5',
  ),
  'pdf_setmatrix' => 
  array (
    'init' => '4.0.5',
  ),
  'ovrimos_rollback' => 
  array (
    'init' => '4.0.3',
    'ext' => 'ext_ovrimos',
  ),
  'parse_ini_file' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_standard',
  ),
  'pathinfo' => 
  array (
    'init' => '4.0.3',
    'ext' => 'ext_standard',
  ),
  'ovrimos_result_all' => 
  array (
    'init' => '4.0.3',
    'ext' => 'ext_ovrimos',
  ),
  'ovrimos_result' => 
  array (
    'init' => '4.0.3',
    'ext' => 'ext_ovrimos',
  ),
  'ovrimos_num_fields' => 
  array (
    'init' => '4.0.3',
    'ext' => 'ext_ovrimos',
  ),
  'ovrimos_num_rows' => 
  array (
    'init' => '4.0.3',
    'ext' => 'ext_ovrimos',
  ),
  'ovrimos_prepare' => 
  array (
    'init' => '4.0.3',
    'ext' => 'ext_ovrimos',
  ),
  'pcntl_alarm' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_pcntl',
  ),
  'pcntl_exec' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_pcntl',
  ),
  'pcntl_wifsignaled' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_pcntl',
  ),
  'pcntl_wifstopped' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_pcntl',
  ),
  'pcntl_wstopsig' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_pcntl',
  ),
  'pcntl_wifexited' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_pcntl',
  ),
  'pcntl_wexitstatus' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_pcntl',
  ),
  'pcntl_fork' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_pcntl',
  ),
  'pcntl_signal' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_pcntl',
  ),
  'pcntl_waitpid' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_pcntl',
  ),
  'ovrimos_longreadlen' => 
  array (
    'init' => '4.0.3',
    'ext' => 'ext_ovrimos',
  ),
  'ovrimos_free_result' => 
  array (
    'init' => '4.0.3',
    'ext' => 'ext_ovrimos',
  ),
  'ovrimos_close' => 
  array (
    'init' => '4.0.3',
    'ext' => 'ext_ovrimos',
  ),
  'ovrimos_close_all' => 
  array (
    'init' => '4.0.3',
  ),
  'ovrimos_commit' => 
  array (
    'init' => '4.0.3',
    'ext' => 'ext_ovrimos',
  ),
  'overload' => 
  array (
    'init' => '4.2.0',
  ),
  'output_reset_rewrite_vars' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_standard',
  ),
  'orbit_load_idl' => 
  array (
    'init' => '4.0.3',
  ),
  'output' => 
  array (
    'init' => '4.0.5',
  ),
  'output_add_rewrite_var' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_standard',
  ),
  'ovrimos_connect' => 
  array (
    'init' => '4.0.3',
    'ext' => 'ext_ovrimos',
  ),
  'ovrimos_cursor' => 
  array (
    'init' => '4.0.3',
    'ext' => 'ext_ovrimos',
  ),
  'ovrimos_field_name' => 
  array (
    'init' => '4.0.3',
    'ext' => 'ext_ovrimos',
  ),
  'ovrimos_field_num' => 
  array (
    'init' => '4.0.3',
    'ext' => 'ext_ovrimos',
  ),
  'ovrimos_field_type' => 
  array (
    'init' => '4.0.3',
    'ext' => 'ext_ovrimos',
  ),
  'ovrimos_field_len' => 
  array (
    'init' => '4.0.3',
    'ext' => 'ext_ovrimos',
  ),
  'ovrimos_fetch_row' => 
  array (
    'init' => '4.0.3',
    'ext' => 'ext_ovrimos',
  ),
  'ovrimos_exec' => 
  array (
    'init' => '4.0.3',
    'ext' => 'ext_ovrimos',
  ),
  'ovrimos_execute' => 
  array (
    'init' => '4.0.3',
    'ext' => 'ext_ovrimos',
  ),
  'ovrimos_fetch_into' => 
  array (
    'init' => '4.0.3',
    'ext' => 'ext_ovrimos',
  ),
  'pcntl_wtermsig' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_pcntl',
  ),
  'pdf_add_bookmark' => 
  array (
    'init' => '4.0.1',
  ),
  'pdf_initgraphics' => 
  array (
    'init' => '4.0.5',
  ),
  'pdf_makespotcolor' => 
  array (
    'init' => '4.0.5',
  ),
  'pdf_new' => 
  array (
    'init' => '4.0.5',
  ),
  'pdf_get_value' => 
  array (
    'init' => '4.0.1',
  ),
  'pdf_get_pdi_value' => 
  array (
    'init' => '4.0.5',
  ),
  'pdf_get_minorversion' => 
  array (
    'init' => '4.2.0',
  ),
  'pdf_get_parameter' => 
  array (
    'init' => '4.0.1',
  ),
  'pdf_get_pdi_parameter' => 
  array (
    'init' => '4.0.5',
  ),
  'pdf_open_ccitt' => 
  array (
    'init' => '4.0.5',
  ),
  'pdf_open_file' => 
  array (
    'init' => '4.0.5',
  ),
  'pdf_place_pdi_page' => 
  array (
    'init' => '4.0.6',
  ),
  'pdf_setcolor' => 
  array (
    'init' => '4.0.5',
  ),
  'pdf_setfont' => 
  array (
    'init' => '4.0.5',
  ),
  'pdf_open_tiff' => 
  array (
    'init' => '4.0.0',
  ),
  'pdf_open_png' => 
  array (
    'init' => '4.0.0',
  ),
  'pdf_open_image' => 
  array (
    'init' => '4.0.5',
  ),
  'pdf_open_pdi' => 
  array (
    'init' => '4.0.5',
  ),
  'pdf_open_pdi_page' => 
  array (
    'init' => '4.0.5',
  ),
  'pdf_get_majorversion' => 
  array (
    'init' => '4.2.0',
  ),
  'pdf_get_fontsize' => 
  array (
    'init' => '4.0.0',
  ),
  'pdf_attach_file' => 
  array (
    'init' => '4.0.5',
  ),
  'pdf_begin_pattern' => 
  array (
    'init' => '4.0.5',
  ),
  'pdf_begin_template' => 
  array (
    'init' => '4.0.5',
  ),
  'pdf_arcn' => 
  array (
    'init' => '4.0.5',
  ),
  'pdf_add_thumbnail' => 
  array (
    'init' => '4.0.5',
  ),
  'pdf_add_launchlink' => 
  array (
    'init' => '4.0.5',
  ),
  'pdf_add_locallink' => 
  array (
    'init' => '4.0.5',
  ),
  'pdf_add_note' => 
  array (
    'init' => '4.0.5',
  ),
  'pdf_close_pdi' => 
  array (
    'init' => '4.0.5',
  ),
  'pdf_close_pdi_page' => 
  array (
    'init' => '4.0.5',
  ),
  'pdf_get_buffer' => 
  array (
    'init' => '4.0.5',
  ),
  'pdf_get_font' => 
  array (
    'init' => '4.0.0',
  ),
  'pdf_get_fontname' => 
  array (
    'init' => '4.0.0',
  ),
  'pdf_findfont' => 
  array (
    'init' => '4.0.5',
  ),
  'pdf_end_template' => 
  array (
    'init' => '4.0.5',
  ),
  'pdf_concat' => 
  array (
    'init' => '4.0.5',
  ),
  'pdf_delete' => 
  array (
    'init' => '4.0.5',
  ),
  'pdf_end_pattern' => 
  array (
    'init' => '4.0.5',
  ),
  'posix_strerror' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_posix',
  ),
  'preg_grep' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_pcre',
  ),
  'setspacing' => 
  array (
    'init' => '4.0.5',
  ),
  'setup' => 
  array (
    'init' => '4.0.5',
  ),
  'set_content' => 
  array (
    'init' => '4.1.0',
  ),
  'setsockopt' => 
  array (
    'init' => '4.0.2',
  ),
  'setrightmargin' => 
  array (
    'init' => '4.0.5',
  ),
  'setrate' => 
  array (
    'init' => '4.0.5',
  ),
  'setratio' => 
  array (
    'init' => '4.0.5',
  ),
  'setrightfill' => 
  array (
    'init' => '4.0.5',
  ),
  'set_error_handler' => 
  array (
    'init' => '4.0.1',
    'ext' => 'zend',
  ),
  'set_include_path' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_standard',
  ),
  'shell_exec' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_standard',
  ),
  'shmop_close' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_shmop',
  ),
  'shmop_delete' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_shmop',
  ),
  'sha1_file' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_standard',
  ),
  'sha1' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_standard',
  ),
  'set_iovec' => 
  array (
    'init' => '4.0.2',
  ),
  'set_nonblock' => 
  array (
    'init' => '4.0.2',
  ),
  'set_user_error_handler' => 
  array (
    'init' => '4.0.0',
  ),
  'setover' => 
  array (
    'init' => '4.0.5',
  ),
  'setname' => 
  array (
    'init' => '4.0.5',
  ),
  'setdimension' => 
  array (
    'init' => '4.0.5',
  ),
  'setdown' => 
  array (
    'init' => '4.0.5',
  ),
  'setfont' => 
  array (
    'init' => '4.0.5',
  ),
  'setdepth' => 
  array (
    'init' => '4.0.5',
  ),
  'setcolor' => 
  array (
    'init' => '4.0.5',
  ),
  'setaction' => 
  array (
    'init' => '4.0.5',
  ),
  'setbackground' => 
  array (
    'init' => '4.0.5',
  ),
  'setbounds' => 
  array (
    'init' => '4.0.5',
  ),
  'setframes' => 
  array (
    'init' => '4.0.5',
  ),
  'setheight' => 
  array (
    'init' => '4.0.5',
  ),
  'setlinespacing' => 
  array (
    'init' => '4.0.5',
  ),
  'setmargins' => 
  array (
    'init' => '4.0.5',
  ),
  'setmatrix' => 
  array (
    'init' => '4.0.5',
  ),
  'setline' => 
  array (
    'init' => '4.0.5',
  ),
  'setleftmargin' => 
  array (
    'init' => '4.0.5',
  ),
  'sethit' => 
  array (
    'init' => '4.0.5',
  ),
  'setindentation' => 
  array (
    'init' => '4.0.5',
  ),
  'setleftfill' => 
  array (
    'init' => '4.0.5',
  ),
  'shmop_open' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_shmop',
  ),
  'shmop_read' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_shmop',
  ),
  'socket_create' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_sockets',
  ),
  'socket_create_listen' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_sockets',
  ),
  'socket_create_pair' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_sockets',
  ),
  'socket_connect' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_sockets',
  ),
  'socket_close' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_sockets',
  ),
  'socket_accept' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_sockets',
  ),
  'socket_bind' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_sockets',
  ),
  'socket_clear_error' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_sockets',
  ),
  'socket_fd_alloc' => 
  array (
    'init' => '4.1.0',
  ),
  'socket_fd_clear' => 
  array (
    'init' => '4.1.0',
  ),
  'socket_getpeername' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_sockets',
  ),
  'socket_getsockname' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_sockets',
  ),
  'socket_get_option' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_sockets',
  ),
  'socket_getopt' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_sockets',
  ),
  'socket_fd_zero' => 
  array (
    'init' => '4.1.0',
  ),
  'socket_fd_free' => 
  array (
    'init' => '4.1.0',
  ),
  'socket_fd_isset' => 
  array (
    'init' => '4.1.0',
  ),
  'socket_fd_set' => 
  array (
    'init' => '4.1.0',
  ),
  'socketpair' => 
  array (
    'init' => '4.0.2',
  ),
  'socket' => 
  array (
    'init' => '4.0.2',
  ),
  'sinh' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_standard',
  ),
  'skewx' => 
  array (
    'init' => '4.0.5',
  ),
  'skewxto' => 
  array (
    'init' => '4.0.5',
  ),
  'signal' => 
  array (
    'init' => '4.0.2',
  ),
  'shutdown' => 
  array (
    'init' => '4.0.2',
  ),
  'shmop_size' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_shmop',
  ),
  'shmop_write' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_shmop',
  ),
  'show_source' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_standard',
  ),
  'skewy' => 
  array (
    'init' => '4.0.5',
  ),
  'skewyto' => 
  array (
    'init' => '4.0.5',
  ),
  'snmp_set_enum_print' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_snmp',
  ),
  'snmp_set_oid_numeric_print' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_snmp',
  ),
  'snmp_set_valueretrieval' => 
  array (
    'init' => '4.3.3',
    'ext' => 'ext_snmp',
  ),
  'snmp_get_valueretrieval' => 
  array (
    'init' => '4.3.3',
    'ext' => 'ext_snmp',
  ),
  'snmp3_walk' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_snmp',
  ),
  'snmp3_get' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_snmp',
  ),
  'snmp3_real_walk' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_snmp',
  ),
  'snmp3_set' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_snmp',
  ),
  'session_write_close' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_session',
  ),
  'session_unset' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_session',
  ),
  'readline_add_history' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_readline',
  ),
  'readline_clear_history' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_readline',
  ),
  'readline_completion_function' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_readline',
  ),
  'readline' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_readline',
  ),
  'read' => 
  array (
    'init' => '4.0.2',
  ),
  'pspell_suggest' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_pspell',
  ),
  'qdom_error' => 
  array (
    'init' => '4.0.5',
  ),
  'qdom_tree' => 
  array (
    'init' => '4.0.4',
  ),
  'readline_info' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_readline',
  ),
  'readline_list_history' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_readline',
  ),
  'recode' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_recode',
  ),
  'recv' => 
  array (
    'init' => '4.0.2',
  ),
  'recvfrom' => 
  array (
    'init' => '4.0.2',
  ),
  'realpath' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_standard',
  ),
  'read_exif_data' => 
  array (
    'init' => '4.0.1',
    'ext' => 'ext_exif',
  ),
  'readline_read_history' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_readline',
  ),
  'readline_write_history' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_readline',
  ),
  'readv' => 
  array (
    'init' => '4.0.2',
  ),
  'pspell_store_replacement' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_pspell',
  ),
  'pspell_save_wordlist' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_pspell',
  ),
  'pspell_add_to_session' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_pspell',
  ),
  'pspell_check' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_pspell',
  ),
  'pspell_clear_session' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_pspell',
  ),
  'pspell_add_to_personal' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_pspell',
  ),
  'proc_open' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_standard',
  ),
  'preg_replace_callback' => 
  array (
    'init' => '4.0.5',
    'ext' => 'ext_pcre',
  ),
  'print_r' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_standard',
  ),
  'proc_close' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_standard',
  ),
  'pspell_config_create' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_pspell',
  ),
  'pspell_config_ignore' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_pspell',
  ),
  'pspell_new' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_pspell',
  ),
  'pspell_new_config' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_pspell',
  ),
  'pspell_new_personal' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_pspell',
  ),
  'pspell_config_save_repl' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_pspell',
  ),
  'pspell_config_runtogether' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_pspell',
  ),
  'pspell_config_mode' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_pspell',
  ),
  'pspell_config_personal' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_pspell',
  ),
  'pspell_config_repl' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_pspell',
  ),
  'recvmsg' => 
  array (
    'init' => '4.0.2',
  ),
  'register_tick_function' => 
  array (
    'init' => '4.0.3',
    'ext' => 'ext_standard',
  ),
  'session_encode' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_session',
  ),
  'session_get_cookie_params' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_session',
  ),
  'session_id' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_session',
  ),
  'session_destroy' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_session',
  ),
  'session_decode' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_session',
  ),
  'sendto' => 
  array (
    'init' => '4.0.2',
  ),
  'session_cache_expire' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_session',
  ),
  'session_cache_limiter' => 
  array (
    'init' => '4.0.3',
    'ext' => 'ext_session',
  ),
  'session_is_registered' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_session',
  ),
  'session_module_name' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_session',
  ),
  'session_set_save_handler' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_session',
  ),
  'session_start' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_session',
  ),
  'session_unregister' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_session',
  ),
  'session_set_cookie_params' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_session',
  ),
  'session_save_path' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_session',
  ),
  'session_name' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_session',
  ),
  'session_regenerate_id' => 
  array (
    'init' => '4.3.2',
    'ext' => 'ext_session',
  ),
  'session_register' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_session',
  ),
  'sendmsg' => 
  array (
    'init' => '4.0.2',
  ),
  'send' => 
  array (
    'init' => '4.0.2',
  ),
  'satellite_caught_exception' => 
  array (
    'init' => '4.0.3',
  ),
  'satellite_exception_id' => 
  array (
    'init' => '4.0.3',
  ),
  'satellite_exception_value' => 
  array (
    'init' => '4.0.3',
  ),
  'rotateto' => 
  array (
    'init' => '4.0.5',
  ),
  'rotate' => 
  array (
    'init' => '4.0.5',
  ),
  'remove' => 
  array (
    'init' => '4.0.5',
  ),
  'restore_error_handler' => 
  array (
    'init' => '4.0.1',
    'ext' => 'zend',
  ),
  'restore_include_path' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_standard',
  ),
  'satellite_get_repository_id' => 
  array (
    'init' => '4.0.3',
  ),
  'satellite_load_idl' => 
  array (
    'init' => '4.0.3',
  ),
  'scaleto' => 
  array (
    'init' => '4.0.5',
  ),
  'select' => 
  array (
    'init' => '4.0.2',
  ),
  'sem_remove' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_sysvsem',
  ),
  'scale' => 
  array (
    'init' => '4.0.5',
  ),
  'savetofile' => 
  array (
    'init' => '4.0.5',
  ),
  'satellite_object_to_string' => 
  array (
    'init' => '4.1.0',
  ),
  'save' => 
  array (
    'init' => '4.0.5',
  ),
  'array_walk_recursive' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_standard',
  ),
  'autocommit' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'tidy_get_html' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_tidy',
  ),
  'tidy_get_html_ver' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_tidy',
  ),
  'tidy_get_output' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_tidy',
  ),
  'tidy_get_head' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_tidy',
  ),
  'tidy_get_error_buffer' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_tidy',
  ),
  'tidy_getopt' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_tidy',
  ),
  'tidy_get_body' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_tidy',
  ),
  'tidy_get_config' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_tidy',
  ),
  'tidy_get_release' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_tidy',
  ),
  'tidy_get_root' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_tidy',
  ),
  'tidy_repair_file' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_tidy',
  ),
  'tidy_repair_string' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_tidy',
  ),
  'tidy_warning_count' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_tidy',
  ),
  'tidy_parse_string' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_tidy',
  ),
  'tidy_parse_file' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_tidy',
  ),
  'tidy_get_status' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_tidy',
  ),
  'tidy_is_xhtml' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_tidy',
  ),
  'tidy_is_xml' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_tidy',
  ),
  'tidy_error_count' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_tidy',
  ),
  'tidy_diagnose' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_tidy',
  ),
  'stream_socket_recvfrom' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_standard',
  ),
  'stream_socket_sendto' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_standard',
  ),
  'stream_socket_server' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_standard',
  ),
  'stream_socket_get_name' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_standard',
  ),
  'stream_socket_client' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_standard',
  ),
  'stream_get_transports' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_standard',
  ),
  'stream_get_wrappers' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_standard',
  ),
  'stream_socket_accept' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_standard',
  ),
  'stripos' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_standard',
  ),
  'strpbrk' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_standard',
  ),
  'tidy_access_count' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_tidy',
  ),
  'tidy_clean_repair' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_tidy',
  ),
  'tidy_config_count' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_tidy',
  ),
  'thread_safe' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'substr_compare' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_standard',
  ),
  'strripos' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_standard',
  ),
  'str_ireplace' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_standard',
  ),
  'str_split' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_standard',
  ),
  'time_nanosleep' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_standard',
  ),
  'use_result' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'variant_sub' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_com_dotnet',
  ),
  'variant_xor' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_com_dotnet',
  ),
  'vfprintf' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_standard',
  ),
  'variant_set_type' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_com_dotnet',
  ),
  'variant_set' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_com_dotnet',
  ),
  'variant_or' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_com_dotnet',
  ),
  'variant_pow' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_com_dotnet',
  ),
  'variant_round' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_com_dotnet',
  ),
  'yaz_es' => 
  array (
    'init' => '5.0.0',
  ),
  'yaz_get_option' => 
  array (
    'init' => '5.0.0',
  ),
  'fbsql_set_characterset' => 
  array (
    'ext' => 'ext_fbsql',
    'init' => '5-dev',
  ),
  'fbird_add_user' => 
  array (
    'ext' => 'ext_interbase',
    'init' => '5-dev',
  ),
  'fbird_affected_rows' => 
  array (
    'ext' => 'ext_interbase',
    'init' => '5-dev',
  ),
  'fbsql_rows_fetched' => 
  array (
    'ext' => 'ext_fbsql',
    'init' => '5-dev',
  ),
  'com_get_active_object' => 
  array (
    'ext' => 'ext_com_dotnet',
    'init' => '5-dev',
  ),
  'yaz_set_option' => 
  array (
    'init' => '5.0.0',
  ),
  'zend_thread_id' => 
  array (
    'init' => '5.0.0',
    'ext' => 'zend',
  ),
  'interface_exists' => 
  array (
    'ext' => 'zend',
    'init' => '5-dev',
  ),
  'variant_not' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_com_dotnet',
  ),
  'variant_neg' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_com_dotnet',
  ),
  'variant_cat' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_com_dotnet',
  ),
  'variant_cmp' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_com_dotnet',
  ),
  'variant_date_from_timestamp' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_com_dotnet',
  ),
  'variant_cast' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_com_dotnet',
  ),
  'variant_and' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_com_dotnet',
  ),
  'use_soap_error_handler' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_soap',
  ),
  'variant_abs' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_com_dotnet',
  ),
  'variant_add' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_com_dotnet',
  ),
  'variant_date_to_timestamp' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_com_dotnet',
  ),
  'variant_div' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_com_dotnet',
  ),
  'variant_int' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_com_dotnet',
  ),
  'variant_mod' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_com_dotnet',
  ),
  'variant_mul' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_com_dotnet',
  ),
  'variant_imp' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_com_dotnet',
  ),
  'variant_idiv' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_com_dotnet',
  ),
  'variant_eqv' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_com_dotnet',
  ),
  'variant_fix' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_com_dotnet',
  ),
  'variant_get_type' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_com_dotnet',
  ),
  'stream_get_line' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_standard',
  ),
  'stream_get_filters' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_standard',
  ),
  'snmp_read_mib' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_snmp',
  ),
  'soap_encode_to_xml' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_soap',
  ),
  'soap_encode_to_zval' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_soap',
  ),
  'snmpgetnext' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_snmp',
  ),
  'snmp3_getnext' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_snmp',
  ),
  'smfi_setflags' => 
  array (
    'init' => '5.0.0',
    'ext' => 'sapi_milter',
  ),
  'smfi_setreply' => 
  array (
    'init' => '5.0.0',
    'ext' => 'sapi_milter',
  ),
  'smfi_settimeout' => 
  array (
    'init' => '5.0.0',
    'ext' => 'sapi_milter',
  ),
  'spl_classes' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_spl',
  ),
  'sqlite_array_query' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_sqlite',
  ),
  'sqlite_create_function' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_sqlite',
  ),
  'sqlite_current' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_sqlite',
  ),
  'sqlite_error_string' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_sqlite',
  ),
  'sqlite_create_aggregate' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_sqlite',
  ),
  'sqlite_column' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_sqlite',
  ),
  'sqlite_busy_timeout' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_sqlite',
  ),
  'sqlite_changes' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_sqlite',
  ),
  'sqlite_close' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_sqlite',
  ),
  'smfi_replacebody' => 
  array (
    'init' => '5.0.0',
    'ext' => 'sapi_milter',
  ),
  'smfi_getsymval' => 
  array (
    'init' => '5.0.0',
    'ext' => 'sapi_milter',
  ),
  'send_long_data' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'session_commit' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_session',
  ),
  'setrawcookie' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_standard',
  ),
  'select_db' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'scandir' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_standard',
  ),
  'rpl_parse_enabled' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'rpl_probe' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'rpl_query_type' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'set_exception_handler' => 
  array (
    'init' => '5.0.0',
    'ext' => 'zend',
  ),
  'set_opt' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'smfi_addrcpt' => 
  array (
    'init' => '5.0.0',
    'ext' => 'sapi_milter',
  ),
  'smfi_chgheader' => 
  array (
    'init' => '5.0.0',
    'ext' => 'sapi_milter',
  ),
  'smfi_delrcpt' => 
  array (
    'init' => '5.0.0',
    'ext' => 'sapi_milter',
  ),
  'smfi_addheader' => 
  array (
    'init' => '5.0.0',
    'ext' => 'sapi_milter',
  ),
  'slave_query' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'simplexml_import_dom' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_simplexml',
  ),
  'simplexml_load_file' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_simplexml',
  ),
  'simplexml_load_string' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_simplexml',
  ),
  'sqlite_escape_string' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_sqlite',
  ),
  'sqlite_factory' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_sqlite',
  ),
  'sqlite_unbuffered_query' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_sqlite',
  ),
  'sqlite_valid' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_sqlite',
  ),
  'ssl_set' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'sqlite_udf_encode_binary' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_sqlite',
  ),
  'sqlite_udf_decode_binary' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_sqlite',
  ),
  'sqlite_rewind' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_sqlite',
  ),
  'sqlite_seek' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_sqlite',
  ),
  'sqlite_single_query' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_sqlite',
  ),
  'stmt' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'stmt_init' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'stream_copy_to_stream' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_standard',
  ),
  'stream_filter_register' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_standard',
  ),
  'stream_get_contents' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_standard',
  ),
  'stream_bucket_prepend' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_standard',
  ),
  'stream_bucket_new' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_standard',
  ),
  'store_result' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'stream_bucket_append' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_standard',
  ),
  'stream_bucket_make_writeable' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_standard',
  ),
  'sqlite_query' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_sqlite',
  ),
  'sqlite_prev' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_sqlite',
  ),
  'sqlite_fetch_string' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_sqlite',
  ),
  'sqlite_field_name' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_sqlite',
  ),
  'sqlite_has_more' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_sqlite',
  ),
  'sqlite_fetch_single' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_sqlite',
  ),
  'sqlite_fetch_object' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_sqlite',
  ),
  'sqlite_fetch_all' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_sqlite',
  ),
  'sqlite_fetch_array' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_sqlite',
  ),
  'sqlite_fetch_column_types' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_sqlite',
  ),
  'sqlite_has_prev' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_sqlite',
  ),
  'sqlite_last_error' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_sqlite',
  ),
  'sqlite_num_rows' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_sqlite',
  ),
  'sqlite_open' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_sqlite',
  ),
  'sqlite_popen' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_sqlite',
  ),
  'sqlite_num_fields' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_sqlite',
  ),
  'sqlite_next' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_sqlite',
  ),
  'sqlite_last_insert_rowid' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_sqlite',
  ),
  'sqlite_libencoding' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_sqlite',
  ),
  'sqlite_libversion' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_sqlite',
  ),
  'fbird_backup' => 
  array (
    'ext' => 'ext_interbase',
    'init' => '5-dev',
  ),
  'fbird_blob_add' => 
  array (
    'ext' => 'ext_interbase',
    'init' => '5-dev',
  ),
  'm_transactionauth' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'm_transactionavs' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'm_transactionbatch' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'm_text_cv' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'm_text_code' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'm_settimeout' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'm_settle' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'm_text_avs' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'm_transactioncv' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'm_transactionid' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'm_transparam' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'm_transsend' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'm_ub' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'm_transnew' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'm_transinqueue' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'm_transactionitem' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'm_transactionssent' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'm_transactiontext' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'm_setssl_files' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'm_setssl' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'm_parsecommadelimited' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'm_ping' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'm_preauth' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'm_override' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'm_numrows' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'm_maxconntimeout' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'm_monitor' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'm_numcolumns' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'm_preauthcompletion' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'm_qc' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'm_setblocking' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'm_setdropfile' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'm_setip' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'm_sale' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'm_returnstatus' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'm_responseparam' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'm_return' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'm_returncode' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'm_uwait' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'm_verifyconnection' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'array_diff_ukey' => 
  array (
    'ext' => 'ext_standard',
    'init' => '5-dev',
  ),
  'array_intersect_key' => 
  array (
    'ext' => 'ext_standard',
    'init' => '5-dev',
  ),
  'array_intersect_ukey' => 
  array (
    'ext' => 'ext_standard',
    'init' => '5-dev',
  ),
  'array_diff_key' => 
  array (
    'ext' => 'ext_standard',
    'init' => '5-dev',
  ),
  'sqlite_exec' => 
  array (
    'ext' => 'ext_sqlite',
    'init' => '5-dev',
  ),
  '__soapCall' => 
  array (
    'ext' => 'ext_soap',
    'init' => '5-dev',
  ),
  'iterator_count' => 
  array (
    'ext' => 'ext_spl',
    'init' => '5-dev',
  ),
  'iterator_to_array' => 
  array (
    'ext' => 'ext_spl',
    'init' => '5-dev',
  ),
  'fputcsv' => 
  array (
    'ext' => 'ext_standard',
    'init' => '5-dev',
  ),
  'inet_ntop' => 
  array (
    'ext' => 'ext_standard',
    'init' => '5-dev',
  ),
  'stream_wrapper_restore' => 
  array (
    'ext' => 'ext_standard',
    'init' => '5-dev',
  ),
  'stream_wrapper_unregister' => 
  array (
    'ext' => 'ext_standard',
    'init' => '5-dev',
  ),
  'strptime' => 
  array (
    'ext' => 'ext_standard',
    'init' => '5-dev',
  ),
  'stream_socket_pair' => 
  array (
    'ext' => 'ext_standard',
    'init' => '5-dev',
  ),
  'stream_socket_enable_crypto' => 
  array (
    'ext' => 'ext_standard',
    'init' => '5-dev',
  ),
  'inet_pton' => 
  array (
    'ext' => 'ext_standard',
    'init' => '5-dev',
  ),
  'stream_context_get_default' => 
  array (
    'ext' => 'ext_standard',
    'init' => '5-dev',
  ),
  'stream_filter_remove' => 
  array (
    'ext' => 'ext_standard',
    'init' => '5-dev',
  ),
  'confirm_extname_compiled' => 
  array (
    'ext' => 'ext_skeleton',
    'init' => '5-dev',
  ),
  'readline_redisplay' => 
  array (
    'ext' => 'ext_readline',
    'init' => '5-dev',
  ),
  'attr_set' => 
  array (
    'ext' => 'ext_mysqli',
    'init' => '5-dev',
  ),
  'mysqli_set_local_infile_default' => 
  array (
    'ext' => 'ext_mysqli',
    'init' => '5-dev',
  ),
  'mysqli_set_local_infile_handler' => 
  array (
    'ext' => 'ext_mysqli',
    'init' => '5-dev',
  ),
  'attr_get' => 
  array (
    'ext' => 'ext_mysqli',
    'init' => '5-dev',
  ),
  'udm_store_doc_cgi' => 
  array (
    'ext' => 'ext_mnogosearch',
    'init' => '5-dev',
  ),
  'm_verifysslcert' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'm_void' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'udm_get_agent_param_ex' => 
  array (
    'ext' => 'ext_mnogosearch',
    'init' => '5-dev',
  ),
  'mysqli_stmt_attr_get' => 
  array (
    'ext' => 'ext_mysqli',
    'init' => '5-dev',
  ),
  'mysqli_stmt_attr_set' => 
  array (
    'ext' => 'ext_mysqli',
    'init' => '5-dev',
  ),
  'readline_callback_handler_remove' => 
  array (
    'ext' => 'ext_readline',
    'init' => '5-dev',
  ),
  'readline_callback_read_char' => 
  array (
    'ext' => 'ext_readline',
    'init' => '5-dev',
  ),
  'readline_on_new_line' => 
  array (
    'ext' => 'ext_readline',
    'init' => '5-dev',
  ),
  'readline_callback_handler_install' => 
  array (
    'ext' => 'ext_readline',
    'init' => '5-dev',
  ),
  'set_local_infile_handler' => 
  array (
    'ext' => 'ext_mysqli',
    'init' => '5-dev',
  ),
  'mysqli_stmt_field_count' => 
  array (
    'ext' => 'ext_mysqli',
    'init' => '5-dev',
  ),
  'mysqli_stmt_insert_id' => 
  array (
    'ext' => 'ext_mysqli',
    'init' => '5-dev',
  ),
  'set_local_infile_default' => 
  array (
    'ext' => 'ext_mysqli',
    'init' => '5-dev',
  ),
  'm_listusers' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'm_liststats' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'fbird_gen_id' => 
  array (
    'ext' => 'ext_interbase',
    'init' => '5-dev',
  ),
  'fbird_maintain_db' => 
  array (
    'ext' => 'ext_interbase',
    'init' => '5-dev',
  ),
  'fbird_modify_user' => 
  array (
    'ext' => 'ext_interbase',
    'init' => '5-dev',
  ),
  'fbird_free_result' => 
  array (
    'ext' => 'ext_interbase',
    'init' => '5-dev',
  ),
  'fbird_free_query' => 
  array (
    'ext' => 'ext_interbase',
    'init' => '5-dev',
  ),
  'fbird_fetch_row' => 
  array (
    'ext' => 'ext_interbase',
    'init' => '5-dev',
  ),
  'fbird_field_info' => 
  array (
    'ext' => 'ext_interbase',
    'init' => '5-dev',
  ),
  'fbird_free_event_handler' => 
  array (
    'ext' => 'ext_interbase',
    'init' => '5-dev',
  ),
  'fbird_name_result' => 
  array (
    'ext' => 'ext_interbase',
    'init' => '5-dev',
  ),
  'fbird_num_fields' => 
  array (
    'ext' => 'ext_interbase',
    'init' => '5-dev',
  ),
  'fbird_query' => 
  array (
    'ext' => 'ext_interbase',
    'init' => '5-dev',
  ),
  'fbird_restore' => 
  array (
    'ext' => 'ext_interbase',
    'init' => '5-dev',
  ),
  'fbird_rollback' => 
  array (
    'ext' => 'ext_interbase',
    'init' => '5-dev',
  ),
  'fbird_prepare' => 
  array (
    'ext' => 'ext_interbase',
    'init' => '5-dev',
  ),
  'fbird_pconnect' => 
  array (
    'ext' => 'ext_interbase',
    'init' => '5-dev',
  ),
  'fbird_num_params' => 
  array (
    'ext' => 'ext_interbase',
    'init' => '5-dev',
  ),
  'fbird_num_rows' => 
  array (
    'ext' => 'ext_interbase',
    'init' => '5-dev',
  ),
  'fbird_param_info' => 
  array (
    'ext' => 'ext_interbase',
    'init' => '5-dev',
  ),
  'fbird_fetch_object' => 
  array (
    'ext' => 'ext_interbase',
    'init' => '5-dev',
  ),
  'fbird_fetch_assoc' => 
  array (
    'ext' => 'ext_interbase',
    'init' => '5-dev',
  ),
  'fbird_blob_import' => 
  array (
    'ext' => 'ext_interbase',
    'init' => '5-dev',
  ),
  'fbird_blob_info' => 
  array (
    'ext' => 'ext_interbase',
    'init' => '5-dev',
  ),
  'fbird_blob_open' => 
  array (
    'ext' => 'ext_interbase',
    'init' => '5-dev',
  ),
  'fbird_blob_get' => 
  array (
    'ext' => 'ext_interbase',
    'init' => '5-dev',
  ),
  'fbird_blob_echo' => 
  array (
    'ext' => 'ext_interbase',
    'init' => '5-dev',
  ),
  'fbird_blob_cancel' => 
  array (
    'ext' => 'ext_interbase',
    'init' => '5-dev',
  ),
  'fbird_blob_close' => 
  array (
    'ext' => 'ext_interbase',
    'init' => '5-dev',
  ),
  'fbird_blob_create' => 
  array (
    'ext' => 'ext_interbase',
    'init' => '5-dev',
  ),
  'fbird_close' => 
  array (
    'ext' => 'ext_interbase',
    'init' => '5-dev',
  ),
  'fbird_commit' => 
  array (
    'ext' => 'ext_interbase',
    'init' => '5-dev',
  ),
  'fbird_errcode' => 
  array (
    'ext' => 'ext_interbase',
    'init' => '5-dev',
  ),
  'fbird_errmsg' => 
  array (
    'ext' => 'ext_interbase',
    'init' => '5-dev',
  ),
  'fbird_execute' => 
  array (
    'ext' => 'ext_interbase',
    'init' => '5-dev',
  ),
  'fbird_drop_db' => 
  array (
    'ext' => 'ext_interbase',
    'init' => '5-dev',
  ),
  'fbird_delete_user' => 
  array (
    'ext' => 'ext_interbase',
    'init' => '5-dev',
  ),
  'fbird_commit_ret' => 
  array (
    'ext' => 'ext_interbase',
    'init' => '5-dev',
  ),
  'fbird_connect' => 
  array (
    'ext' => 'ext_interbase',
    'init' => '5-dev',
  ),
  'fbird_db_info' => 
  array (
    'ext' => 'ext_interbase',
    'init' => '5-dev',
  ),
  'fbird_rollback_ret' => 
  array (
    'ext' => 'ext_interbase',
    'init' => '5-dev',
  ),
  'fbird_server_info' => 
  array (
    'ext' => 'ext_interbase',
    'init' => '5-dev',
  ),
  'm_getcell' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'm_getcellbynum' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'm_getcommadelimited' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'm_force' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'm_enableuser' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'm_destroyengine' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'm_disableuser' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'm_edituser' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'm_getheader' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'm_getuserarg' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'm_initengine' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'm_initusersetup' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'm_iscommadelimited' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'm_initconn' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'm_gut' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'm_getuserparam' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'm_gft' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'm_gl' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'm_destroyconn' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'm_deluser' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'm_adduser' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'm_adduserarg' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'm_bt' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'fbird_wait_event' => 
  array (
    'ext' => 'ext_interbase',
    'init' => '5-dev',
  ),
  'fbird_trans' => 
  array (
    'ext' => 'ext_interbase',
    'init' => '5-dev',
  ),
  'fbird_service_attach' => 
  array (
    'ext' => 'ext_interbase',
    'init' => '5-dev',
  ),
  'fbird_service_detach' => 
  array (
    'ext' => 'ext_interbase',
    'init' => '5-dev',
  ),
  'fbird_set_event_handler' => 
  array (
    'ext' => 'ext_interbase',
    'init' => '5-dev',
  ),
  'm_checkstatus' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'm_chkpwd' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'm_deleteresponse' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'm_deletetrans' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'm_deleteusersetup' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'm_connectionerror' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'm_connect' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'm_chngpwd' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'm_completeauthorizations' => 
  array (
    'ext' => 'ext_mcve',
    'init' => '5-dev',
  ),
  'rollback' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'result_metadata' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'imagexbm' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_gd',
  ),
  'imap_getacl' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_imap',
  ),
  'init' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'imagefilter' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_gd',
  ),
  'idate' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_standard',
  ),
  'iconv_strpos' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_iconv',
  ),
  'iconv_strrpos' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_iconv',
  ),
  'iconv_substr' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_iconv',
  ),
  'ircg_set_on_read_data' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_ircg',
  ),
  'is_soap_fault' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_soap',
  ),
  'ming_keypress' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_ming',
  ),
  'ming_useconstants' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_ming',
  ),
  'mono_method_call' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mono',
  ),
  'mb_list_encodings' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mbstring',
  ),
  'master_query' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'kill' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'ldap_sasl_bind' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_ldap',
  ),
  'libxml_set_streams_context' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_libxml',
  ),
  'iconv_strlen' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_iconv',
  ),
  'iconv_mime_encode' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_iconv',
  ),
  'ibase_name_result' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_interbase',
  ),
  'ibase_num_params' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_interbase',
  ),
  'ibase_num_rows' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_interbase',
  ),
  'ibase_maintain_db' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_interbase',
  ),
  'ibase_gen_id' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_interbase',
  ),
  'ibase_drop_db' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_interbase',
  ),
  'ibase_errcode' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_interbase',
  ),
  'ibase_free_event_handler' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_interbase',
  ),
  'ibase_param_info' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_interbase',
  ),
  'ibase_restore' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_interbase',
  ),
  'ibase_wait_event' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_interbase',
  ),
  'iconv_mime_decode' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_iconv',
  ),
  'iconv_mime_decode_headers' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_iconv',
  ),
  'ibase_set_event_handler' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_interbase',
  ),
  'ibase_service_detach' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_interbase',
  ),
  'ibase_rollback_ret' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_interbase',
  ),
  'ibase_server_info' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_interbase',
  ),
  'ibase_service_attach' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_interbase',
  ),
  'mono_method_find' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mono',
  ),
  'more_results' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_error' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_escape_string' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_execute' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_errno' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_enable_rpl_parse' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_dump_debug_info' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_embedded_connect' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_enable_reads_from_master' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_fetch' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_fetch_array' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_fetch_object' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_fetch_row' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_field_count' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_fetch_lengths' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_fetch_field_direct' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_fetch_assoc' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_fetch_field' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_fetch_fields' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_disable_rpl_parse' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_disable_reads_from_master' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_autocommit' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_bind_param' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_bind_result' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_affected_rows' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'msession_exec' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_msession',
  ),
  'msession_ping' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_msession',
  ),
  'multi_query' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_change_user' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_character_set_name' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_connect_error' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_data_seek' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_debug' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_connect_errno' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_connect' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_client_encoding' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_close' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_commit' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'ibase_db_info' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_interbase',
  ),
  'ibase_commit_ret' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_interbase',
  ),
  'dba_key_split' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_dba',
  ),
  'dbx_fetch_row' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_dbx',
  ),
  'debug' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'dbase_get_header_info' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_dbase',
  ),
  'date_sunset' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_standard',
  ),
  'curl_multi_select' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_curl',
  ),
  'data_seek' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'date_sunrise' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_standard',
  ),
  'debug_print_backtrace' => 
  array (
    'init' => '5.0.0',
    'ext' => 'zend',
  ),
  'disable_reads_from_master' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'dump_debug_info' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'enable_reads_from_master' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'enable_rpl_parse' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'dom_import_simplexml' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_dom',
  ),
  'dns_get_record' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_standard',
  ),
  'disable_rpl_parse' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'dns_check_record' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_standard',
  ),
  'dns_get_mx' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_standard',
  ),
  'curl_multi_remove_handle' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_curl',
  ),
  'curl_multi_init' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_curl',
  ),
  'class_implements' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_spl',
  ),
  'class_parents' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_spl',
  ),
  'client_encoding' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'character_set_name' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'change_user' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'bcpowmod' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_bcmath',
  ),
  'bind_param' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'bind_result' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'commit' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'com_create_guid' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_com_dotnet',
  ),
  'curl_multi_exec' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_curl',
  ),
  'curl_multi_getcontent' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_curl',
  ),
  'curl_multi_info_read' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_curl',
  ),
  'curl_multi_close' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_curl',
  ),
  'curl_multi_add_handle' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_curl',
  ),
  'convert_uudecode' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_standard',
  ),
  'convert_uuencode' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_standard',
  ),
  'curl_copy_handle' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_curl',
  ),
  'escape_string' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'execute' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'free' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'free_result' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'ftp_alloc' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_ftp',
  ),
  'fprintf' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_standard',
  ),
  'filter' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_standard',
  ),
  'field_count' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'field_seek' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'file_put_contents' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_standard',
  ),
  'ftp_chmod' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_ftp',
  ),
  'ftp_raw' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_ftp',
  ),
  'http_build_query' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_standard',
  ),
  'ibase_affected_rows' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_interbase',
  ),
  'ibase_backup' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_interbase',
  ),
  'headers_list' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_standard',
  ),
  'get_server_info' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'get_client_info' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'get_declared_interfaces' => 
  array (
    'init' => '5.0.0',
    'ext' => 'zend',
  ),
  'get_headers' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_standard',
  ),
  'fetch_row' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'fetch_object' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'fam_monitor_file' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_fam',
  ),
  'fam_next_event' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_fam',
  ),
  'fam_open' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_fam',
  ),
  'fam_monitor_directory' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_fam',
  ),
  'fam_monitor_collection' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_fam',
  ),
  'export' => 
  array (
    'init' => '5.0.0',
    'ext' => 'zend',
  ),
  'fam_cancel_monitor' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_fam',
  ),
  'fam_close' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_fam',
  ),
  'fam_pending' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_fam',
  ),
  'fam_resume_monitor' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_fam',
  ),
  'fetch_field' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'fetch_fields' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'fetch_field_direct' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'fetch_assoc' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'fetch_array' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'fam_suspend_monitor' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_fam',
  ),
  'fbsql_set_password' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_fbsql',
  ),
  'fetch' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_field_seek' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_field_tell' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'oci_lob_copy' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_oci8',
  ),
  'oci_lob_eof' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_oci8',
  ),
  'oci_lob_erase' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_oci8',
  ),
  'oci_lob_append' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_oci8',
  ),
  'oci_internal_debug' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_oci8',
  ),
  'oci_free_cursor' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_oci8',
  ),
  'oci_free_descriptor' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_oci8',
  ),
  'oci_free_statement' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_oci8',
  ),
  'oci_lob_export' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_oci8',
  ),
  'oci_lob_flush' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_oci8',
  ),
  'oci_lob_save' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_oci8',
  ),
  'oci_lob_size' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_oci8',
  ),
  'oci_lob_tell' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_oci8',
  ),
  'oci_lob_rewind' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_oci8',
  ),
  'oci_lob_read' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_oci8',
  ),
  'oci_lob_import' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_oci8',
  ),
  'oci_lob_is_equal' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_oci8',
  ),
  'oci_lob_load' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_oci8',
  ),
  'oci_free_collection' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_oci8',
  ),
  'oci_field_type_raw' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_oci8',
  ),
  'oci_execute' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_oci8',
  ),
  'oci_fetch' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_oci8',
  ),
  'oci_fetch_all' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_oci8',
  ),
  'oci_error' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_oci8',
  ),
  'oci_define_by_name' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_oci8',
  ),
  'oci_collection_trim' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_oci8',
  ),
  'oci_commit' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_oci8',
  ),
  'oci_connect' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_oci8',
  ),
  'oci_fetch_array' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_oci8',
  ),
  'oci_fetch_assoc' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_oci8',
  ),
  'oci_field_scale' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_oci8',
  ),
  'oci_field_size' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_oci8',
  ),
  'oci_field_type' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_oci8',
  ),
  'oci_field_precision' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_oci8',
  ),
  'oci_field_name' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_oci8',
  ),
  'oci_fetch_object' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_oci8',
  ),
  'oci_fetch_row' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_oci8',
  ),
  'oci_field_is_null' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_oci8',
  ),
  'oci_lob_truncate' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_oci8',
  ),
  'oci_lob_write' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_oci8',
  ),
  'php_strip_whitespace' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_standard',
  ),
  'ping' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'prepare' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'php_real_logo_guid' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_standard',
  ),
  'php_egg_logo_guid' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_standard',
  ),
  'pg_parameter_status' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_pgsql',
  ),
  'pg_version' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_pgsql',
  ),
  'php_check_syntax' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_standard',
  ),
  'proc_get_status' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_standard',
  ),
  'proc_nice' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_standard',
  ),
  'real_escape_string' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'real_query' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'restore_exception_handler' => 
  array (
    'init' => '5.0.0',
    'ext' => 'zend',
  ),
  'real_connect' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'query' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'proc_terminate' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_standard',
  ),
  'pspell_config_data_dir' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_pspell',
  ),
  'pspell_config_dict_dir' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_pspell',
  ),
  'pcntl_wait' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_pcntl',
  ),
  'pcntl_setpriority' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_pcntl',
  ),
  'oci_num_rows' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_oci8',
  ),
  'oci_parse' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_oci8',
  ),
  'oci_password_change' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_oci8',
  ),
  'oci_num_fields' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_oci8',
  ),
  'oci_new_descriptor' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_oci8',
  ),
  'oci_new_collection' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_oci8',
  ),
  'oci_new_connect' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_oci8',
  ),
  'oci_new_cursor' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_oci8',
  ),
  'oci_pconnect' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_oci8',
  ),
  'oci_result' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_oci8',
  ),
  'onCreate' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_standard',
  ),
  'options' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'pcntl_getpriority' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_pcntl',
  ),
  'onClose' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_standard',
  ),
  'oci_statement_type' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_oci8',
  ),
  'oci_rollback' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_oci8',
  ),
  'oci_server_version' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_oci8',
  ),
  'oci_set_prefetch' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_oci8',
  ),
  'oci_collection_size' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_oci8',
  ),
  'oci_collection_max' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_oci8',
  ),
  'mysqli_real_query' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_report' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_rollback' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_real_escape_string' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_real_connect' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_ping' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_prepare' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_query' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_rpl_parse_enabled' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_rpl_probe' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_server_init' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_set_opt' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_slave_query' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_server_end' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_send_query' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_rpl_query_type' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_select_db' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_send_long_data' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_param_count' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_options' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_get_proto_info' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_get_server_info' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_get_server_version' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_get_metadata' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_get_host_info' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_free_result' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_get_client_info' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_get_client_version' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_info' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_init' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_next_result' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_num_fields' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_num_rows' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_multi_query' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_more_results' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_insert_id' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_kill' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_master_query' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_sqlstate' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_ssl_set' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_warning_count' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'next_result' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'num_rows' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_use_result' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_thread_safe' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_stmt_store_result' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_store_result' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_thread_id' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'ob_tidyhandler' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_tidy',
  ),
  'ocigetbufferinglob' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_oci8',
  ),
  'oci_collection_assign' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_oci8',
  ),
  'oci_collection_element_assign' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_oci8',
  ),
  'oci_collection_element_get' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_oci8',
  ),
  'oci_collection_append' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_oci8',
  ),
  'oci_close' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_oci8',
  ),
  'ocisetbufferinglob' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_oci8',
  ),
  'oci_bind_by_name' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_oci8',
  ),
  'oci_cancel' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_oci8',
  ),
  'mysqli_stmt_sqlstate' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_stmt_send_long_data' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_stmt_data_seek' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_stmt_errno' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_stmt_error' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_stmt_close' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_stmt_bind_result' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_stat' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_stmt_affected_rows' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_stmt_bind_param' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_stmt_execute' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_stmt_fetch' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_stmt_prepare' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_stmt_reset' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_stmt_result_metadata' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_stmt_param_count' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_stmt_num_rows' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_stmt_free_result' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'mysqli_stmt_init' => 
  array (
    'init' => '5.0.0',
    'ext' => 'ext_mysqli',
  ),
  'orbit_get_repository_id' => 
  array (
    'init' => '4.0.3',
  ),
  'orbit_exception_value' => 
  array (
    'init' => '4.0.3',
  ),
  'fdf_enum_values' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_fdf',
  ),
  'fdf_errno' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_fdf',
  ),
  'fdf_error' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_fdf',
  ),
  'fdf_add_doc_javascript' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_fdf',
  ),
  'fbsql_warnings' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_fbsql',
  ),
  'fbsql_tablename' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_fbsql',
  ),
  'fbsql_table_name' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_fbsql',
  ),
  'fbsql_username' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_fbsql',
  ),
  'fdf_get_ap' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_fdf',
  ),
  'fdf_get_attachment' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_fdf',
  ),
  'fdf_open_string' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_fdf',
  ),
  'fdf_remove_item' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_fdf',
  ),
  'fdf_save_string' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_fdf',
  ),
  'fdf_header' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_fdf',
  ),
  'fdf_get_version' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_fdf',
  ),
  'fdf_get_encoding' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_fdf',
  ),
  'fdf_get_flags' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_fdf',
  ),
  'fdf_get_opt' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_fdf',
  ),
  'fbsql_stop_db' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_fbsql',
  ),
  'fbsql_start_db' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_fbsql',
  ),
  'fbsql_next_result' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_fbsql',
  ),
  'fbsql_num_fields' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_fbsql',
  ),
  'fbsql_num_rows' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_fbsql',
  ),
  'fbsql_list_tables' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_fbsql',
  ),
  'fbsql_list_fields' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_fbsql',
  ),
  'fbsql_hostname' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_fbsql',
  ),
  'fbsql_insert_id' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_fbsql',
  ),
  'fbsql_list_dbs' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_fbsql',
  ),
  'fbsql_password' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_fbsql',
  ),
  'fbsql_pconnect' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_fbsql',
  ),
  'fbsql_select_db' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_fbsql',
  ),
  'fbsql_set_lob_mode' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_fbsql',
  ),
  'fbsql_set_transaction' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_fbsql',
  ),
  'fbsql_rollback' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_fbsql',
  ),
  'fbsql_result' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_fbsql',
  ),
  'fbsql_query' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_fbsql',
  ),
  'fbsql_read_blob' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_fbsql',
  ),
  'fbsql_read_clob' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_fbsql',
  ),
  'fdf_set_encoding' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_fdf',
  ),
  'fdf_set_flags' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_fdf',
  ),
  'ftok' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_standard',
  ),
  'ftp_close' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_ftp',
  ),
  'ftp_exec' => 
  array (
    'init' => '4.0.3',
    'ext' => 'ext_ftp',
  ),
  'fstat' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_standard',
  ),
  'fscanf' => 
  array (
    'init' => '4.0.1',
    'ext' => 'ext_standard',
  ),
  'fribidi_charset_info' => 
  array (
    'init' => '4.3.0',
  ),
  'fribidi_get_charsets' => 
  array (
    'init' => '4.3.0',
  ),
  'fribidi_log2vis' => 
  array (
    'init' => '4.0.4',
  ),
  'ftp_get_option' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_ftp',
  ),
  'ftp_nb_continue' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_ftp',
  ),
  'ftp_ssl_connect' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_ftp',
  ),
  'ftruncate' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_standard',
  ),
  'func_get_arg' => 
  array (
    'init' => '4.0.0',
    'ext' => 'zend',
  ),
  'ftp_set_option' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_ftp',
  ),
  'ftp_nb_put' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_ftp',
  ),
  'ftp_nb_fget' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_ftp',
  ),
  'ftp_nb_fput' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_ftp',
  ),
  'ftp_nb_get' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_ftp',
  ),
  'free_iovec' => 
  array (
    'init' => '4.0.2',
  ),
  'fopenstream' => 
  array (
    'init' => '4.0.6',
  ),
  'fdf_set_version' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_fdf',
  ),
  'fd_alloc' => 
  array (
    'init' => '4.0.2',
  ),
  'fd_clear' => 
  array (
    'init' => '4.0.2',
  ),
  'fdf_set_target_frame' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_fdf',
  ),
  'fdf_set_submit_form_action' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_fdf',
  ),
  'fdf_set_javascript_action' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_fdf',
  ),
  'fdf_set_on_import_javascript' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_fdf',
  ),
  'fdf_set_opt' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_fdf',
  ),
  'fd_dealloc' => 
  array (
    'init' => '4.0.2',
  ),
  'fd_isset' => 
  array (
    'init' => '4.0.2',
  ),
  'floatval' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_standard',
  ),
  'fmod' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_standard',
  ),
  'fnmatch' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_standard',
  ),
  'file_get_contents' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_standard',
  ),
  'fflush' => 
  array (
    'init' => '4.0.1',
    'ext' => 'ext_standard',
  ),
  'fd_set' => 
  array (
    'init' => '4.0.2',
  ),
  'fd_zero' => 
  array (
    'init' => '4.0.2',
  ),
  'fetch_iovec' => 
  array (
    'init' => '4.0.2',
  ),
  'fbsql_get_autostart_info' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_fbsql',
  ),
  'fbsql_free_result' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_fbsql',
  ),
  'domxml_xslt_process' => 
  array (
    'init' => '4.2.0',
  ),
  'domxml_xslt_result_dump_file' => 
  array (
    'init' => '4.3.0',
  ),
  'domxml_xslt_result_dump_mem' => 
  array (
    'init' => '4.3.0',
  ),
  'domxml_xmltree' => 
  array (
    'init' => '4.2.1',
  ),
  'domxml_version' => 
  array (
    'init' => '4.1.0',
  ),
  'domxml_set_content' => 
  array (
    'init' => '4.0.4',
  ),
  'domxml_substitute_entities_default' => 
  array (
    'init' => '4.2.0',
  ),
  'domxml_unlink_node' => 
  array (
    'init' => '4.0.5',
  ),
  'domxml_xslt_stylesheet' => 
  array (
    'init' => '4.2.0',
  ),
  'domxml_xslt_stylesheet_doc' => 
  array (
    'init' => '4.2.0',
  ),
  'drawcubicto' => 
  array (
    'init' => '4.0.5',
  ),
  'drawcurve' => 
  array (
    'init' => '4.0.5',
  ),
  'drawcurveto' => 
  array (
    'init' => '4.0.5',
  ),
  'drawcubic' => 
  array (
    'init' => '4.0.5',
  ),
  'drawcircle' => 
  array (
    'init' => '4.0.5',
  ),
  'domxml_xslt_stylesheet_file' => 
  array (
    'init' => '4.2.0',
  ),
  'domxml_xslt_version' => 
  array (
    'init' => '4.2.0',
  ),
  'drawarc' => 
  array (
    'init' => '4.0.5',
  ),
  'domxml_set_attribute' => 
  array (
    'init' => '4.0.5',
  ),
  'domxml_setattr' => 
  array (
    'init' => '4.0.0',
  ),
  'domxml_parser_cdata_section' => 
  array (
    'init' => '4.3.0',
  ),
  'domxml_parser_characters' => 
  array (
    'init' => '4.3.0',
  ),
  'domxml_parser_comment' => 
  array (
    'init' => '4.3.0',
  ),
  'domxml_parser_add_chunk' => 
  array (
    'init' => '4.2.1',
  ),
  'domxml_parser' => 
  array (
    'init' => '4.2.1',
  ),
  'domxml_node_unlink_node' => 
  array (
    'init' => '4.1.0',
  ),
  'domxml_open_file' => 
  array (
    'init' => '4.2.1',
  ),
  'domxml_open_mem' => 
  array (
    'init' => '4.2.1',
  ),
  'domxml_parser_end' => 
  array (
    'init' => '4.2.1',
  ),
  'domxml_parser_end_document' => 
  array (
    'init' => '4.3.0',
  ),
  'domxml_parser_start_document' => 
  array (
    'init' => '4.3.0',
  ),
  'domxml_parser_start_element' => 
  array (
    'init' => '4.3.0',
  ),
  'domxml_root' => 
  array (
    'init' => '4.0.0',
  ),
  'domxml_parser_processing_instruction' => 
  array (
    'init' => '4.3.0',
  ),
  'domxml_parser_namespace_decl' => 
  array (
    'init' => '4.3.0',
  ),
  'domxml_parser_end_element' => 
  array (
    'init' => '4.3.0',
  ),
  'domxml_parser_entity_reference' => 
  array (
    'init' => '4.3.0',
  ),
  'domxml_parser_get_document' => 
  array (
    'init' => '4.3.0',
  ),
  'drawglyph' => 
  array (
    'init' => '4.0.5',
  ),
  'drawline' => 
  array (
    'init' => '4.0.5',
  ),
  'fbsql_error' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_fbsql',
  ),
  'fbsql_fetch_array' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_fbsql',
  ),
  'fbsql_fetch_assoc' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_fbsql',
  ),
  'fbsql_errno' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_fbsql',
  ),
  'fbsql_drop_db' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_fbsql',
  ),
  'fbsql_data_seek' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_fbsql',
  ),
  'fbsql_db_query' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_fbsql',
  ),
  'fbsql_db_status' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_fbsql',
  ),
  'fbsql_fetch_field' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_fbsql',
  ),
  'fbsql_fetch_lengths' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_fbsql',
  ),
  'fbsql_field_seek' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_fbsql',
  ),
  'fbsql_field_table' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_fbsql',
  ),
  'fbsql_field_type' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_fbsql',
  ),
  'fbsql_field_name' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_fbsql',
  ),
  'fbsql_field_len' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_fbsql',
  ),
  'fbsql_fetch_object' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_fbsql',
  ),
  'fbsql_fetch_row' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_fbsql',
  ),
  'fbsql_field_flags' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_fbsql',
  ),
  'fbsql_database_password' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_fbsql',
  ),
  'fbsql_database' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_fbsql',
  ),
  'exif_thumbnail' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_exif',
  ),
  'expm1' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_standard',
  ),
  'fbsql' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_fbsql',
  ),
  'exif_tagname' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_exif',
  ),
  'exif_read_data' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_exif',
  ),
  'drawlineto' => 
  array (
    'init' => '4.0.5',
  ),
  'escapeshellarg' => 
  array (
    'init' => '4.0.3',
    'ext' => 'ext_standard',
  ),
  'exif_imagetype' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_exif',
  ),
  'fbsql_affected_rows' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_fbsql',
  ),
  'fbsql_autocommit' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_fbsql',
  ),
  'fbsql_create_blob' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_fbsql',
  ),
  'fbsql_create_clob' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_fbsql',
  ),
  'fbsql_create_db' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_fbsql',
  ),
  'fbsql_connect' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_fbsql',
  ),
  'fbsql_commit' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_fbsql',
  ),
  'fbsql_blob_size' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_fbsql',
  ),
  'fbsql_clob_size' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_fbsql',
  ),
  'fbsql_close' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_fbsql',
  ),
  'func_get_args' => 
  array (
    'init' => '4.0.0',
    'ext' => 'zend',
  ),
  'func_num_args' => 
  array (
    'init' => '4.0.0',
    'ext' => 'zend',
  ),
  'ibase_fetch_assoc' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_interbase',
  ),
  'ibase_modify_user' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_interbase',
  ),
  'icap_create_calendar' => 
  array (
    'init' => '4.2.3',
  ),
  'ibase_delete_user' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_interbase',
  ),
  'ibase_add_user' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_interbase',
  ),
  'i18n_ja_jp_hantozen' => 
  array (
    'init' => '4.0.6',
  ),
  'i18n_mime_header_decode' => 
  array (
    'init' => '4.0.6',
  ),
  'i18n_mime_header_encode' => 
  array (
    'init' => '4.0.6',
  ),
  'icap_delete_calendar' => 
  array (
    'init' => '4.2.3',
  ),
  'icap_delete_event' => 
  array (
    'init' => '4.2.3',
  ),
  'icap_rename_calendar' => 
  array (
    'init' => '4.2.3',
  ),
  'icap_reopen' => 
  array (
    'init' => '4.2.3',
  ),
  'icap_snooze' => 
  array (
    'init' => '4.2.3',
  ),
  'icap_popen' => 
  array (
    'init' => '4.2.3',
  ),
  'icap_open' => 
  array (
    'init' => '4.2.3',
  ),
  'icap_fetch_event' => 
  array (
    'init' => '4.2.3',
  ),
  'icap_list_alarms' => 
  array (
    'init' => '4.2.3',
  ),
  'icap_list_events' => 
  array (
    'init' => '4.2.3',
  ),
  'i18n_internal_encoding' => 
  array (
    'init' => '4.0.6',
  ),
  'i18n_http_output' => 
  array (
    'init' => '4.0.6',
  ),
  'html_doc_file' => 
  array (
    'init' => '4.2.0',
  ),
  'html_entity_decode' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_standard',
  ),
  'hw_document_setcontent' => 
  array (
    'init' => '4.0.0',
  ),
  'html_doc' => 
  array (
    'init' => '4.2.0',
  ),
  'highlight_string' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_standard',
  ),
  'gzuncompress' => 
  array (
    'init' => '4.0.1',
    'ext' => 'ext_zlib',
  ),
  'handle' => 
  array (
    'init' => '4.0.0',
  ),
  'highlight_file' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_standard',
  ),
  'hw_getobjectbyftquery' => 
  array (
    'init' => '4.0.4',
  ),
  'hw_getobjectbyftquerycoll' => 
  array (
    'init' => '4.0.4',
  ),
  'i18n_convert' => 
  array (
    'init' => '4.0.6',
  ),
  'i18n_discover_encoding' => 
  array (
    'init' => '4.0.6',
  ),
  'i18n_http_input' => 
  array (
    'init' => '4.0.6',
  ),
  'hypot' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_standard',
  ),
  'hw_new_document_from_file' => 
  array (
    'init' => '4.0.5',
  ),
  'hw_getobjectbyftquerycollobj' => 
  array (
    'init' => '4.0.4',
  ),
  'hw_getobjectbyftqueryobj' => 
  array (
    'init' => '4.0.4',
  ),
  'hw_insertanchors' => 
  array (
    'init' => '4.0.4',
  ),
  'icap_store_event' => 
  array (
    'init' => '4.2.3',
  ),
  'iconv' => 
  array (
    'init' => '4.0.5',
    'ext' => 'ext_iconv',
  ),
  'imageftbbox' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_gd',
  ),
  'imagefttext' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_gd',
  ),
  'imagegd' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_gd',
  ),
  'imagefilledellipse' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_gd',
  ),
  'imagefilledarc' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_gd',
  ),
  'imagecreatefromxpm' => 
  array (
    'init' => '4.0.1',
    'ext' => 'ext_gd',
  ),
  'imagecreatetruecolor' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_gd',
  ),
  'imageellipse' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_gd',
  ),
  'imagegd2' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_gd',
  ),
  'imageistruecolor' => 
  array (
    'init' => '4.3.2',
    'ext' => 'ext_gd',
  ),
  'imagesetstyle' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_gd',
  ),
  'imagesetthickness' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_gd',
  ),
  'imagesettile' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_gd',
  ),
  'imagesetbrush' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_gd',
  ),
  'imagesavealpha' => 
  array (
    'init' => '4.3.2',
    'ext' => 'ext_gd',
  ),
  'imagelayereffect' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_gd',
  ),
  'imagepalettecopy' => 
  array (
    'init' => '4.0.1',
    'ext' => 'ext_gd',
  ),
  'imagerotate' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_gd',
  ),
  'imagecreatefromxbm' => 
  array (
    'init' => '4.0.1',
    'ext' => 'ext_gd',
  ),
  'imagecreatefromwbmp' => 
  array (
    'init' => '4.0.1',
    'ext' => 'ext_gd',
  ),
  'imagecolorallocatealpha' => 
  array (
    'init' => '4.3.2',
    'ext' => 'ext_gd',
  ),
  'imagecolorclosestalpha' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_gd',
  ),
  'imagecolorclosesthwb' => 
  array (
    'init' => '4.0.1',
    'ext' => 'ext_gd',
  ),
  'imageantialias' => 
  array (
    'init' => '4.3.2',
    'ext' => 'ext_gd',
  ),
  'imagealphablending' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_gd',
  ),
  'iconv_get_encoding' => 
  array (
    'init' => '4.0.5',
    'ext' => 'ext_iconv',
  ),
  'iconv_set_encoding' => 
  array (
    'init' => '4.0.5',
    'ext' => 'ext_iconv',
  ),
  'image2wbmp' => 
  array (
    'init' => '4.0.5',
    'ext' => 'ext_gd',
  ),
  'imagecolorexactalpha' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_gd',
  ),
  'imagecolormatch' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_gd',
  ),
  'imagecreatefromgd2' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_gd',
  ),
  'imagecreatefromgd2part' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_gd',
  ),
  'imagecreatefromstring' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_gd',
  ),
  'imagecreatefromgd' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_gd',
  ),
  'imagecopyresampled' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_gd',
  ),
  'imagecolorresolvealpha' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_gd',
  ),
  'imagecopymerge' => 
  array (
    'init' => '4.0.1',
    'ext' => 'ext_gd',
  ),
  'imagecopymergegray' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_gd',
  ),
  'gzinflate' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_zlib',
  ),
  'gzencode' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_zlib',
  ),
  'get_defined_vars' => 
  array (
    'init' => '4.0.4',
    'ext' => 'zend',
  ),
  'get_extension_funcs' => 
  array (
    'init' => '4.0.0',
    'ext' => 'zend',
  ),
  'get_html_translation_table' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_standard',
  ),
  'get_defined_functions' => 
  array (
    'init' => '4.0.4',
    'ext' => 'zend',
  ),
  'get_defined_constants' => 
  array (
    'init' => '4.1.0',
    'ext' => 'zend',
  ),
  'get_class_methods' => 
  array (
    'init' => '4.0.0',
    'ext' => 'zend',
  ),
  'get_class_vars' => 
  array (
    'init' => '4.0.0',
    'ext' => 'zend',
  ),
  'get_declared_classes' => 
  array (
    'init' => '4.0.0',
    'ext' => 'zend',
  ),
  'get_included_files' => 
  array (
    'init' => '4.0.0',
    'ext' => 'zend',
  ),
  'get_include_path' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_standard',
  ),
  'glob' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_standard',
  ),
  'gmp_abs' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_gmp',
  ),
  'gmp_add' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_gmp',
  ),
  'get_resource_type' => 
  array (
    'init' => '4.0.2',
    'ext' => 'zend',
  ),
  'get_required_files' => 
  array (
    'init' => '4.0.0',
    'ext' => 'zend',
  ),
  'get_loaded_extensions' => 
  array (
    'init' => '4.0.0',
    'ext' => 'zend',
  ),
  'get_object_vars' => 
  array (
    'init' => '4.0.0',
    'ext' => 'zend',
  ),
  'get_parent_class' => 
  array (
    'init' => '4.0.0',
    'ext' => 'zend',
  ),
  'get_class' => 
  array (
    'init' => '4.0.0',
    'ext' => 'zend',
  ),
  'get_all_headers' => 
  array (
    'init' => '4.0.4',
  ),
  'getleading' => 
  array (
    'init' => '4.0.5',
  ),
  'getmygid' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_standard',
  ),
  'getopt' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_standard',
  ),
  'getheight' => 
  array (
    'init' => '4.0.5',
  ),
  'getdescent' => 
  array (
    'init' => '4.0.5',
  ),
  'gd_info' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_gd',
  ),
  'getascent' => 
  array (
    'init' => '4.0.5',
  ),
  'getcwd' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_standard',
  ),
  'getpeername' => 
  array (
    'init' => '4.0.2',
  ),
  'getprotobyname' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_standard',
  ),
  'getsockname' => 
  array (
    'init' => '4.0.2',
  ),
  'getsockopt' => 
  array (
    'init' => '4.0.2',
  ),
  'getwidth' => 
  array (
    'init' => '4.0.5',
  ),
  'getshape2' => 
  array (
    'init' => '4.0.5',
  ),
  'getshape1' => 
  array (
    'init' => '4.0.5',
  ),
  'getprotobynumber' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_standard',
  ),
  'getservbyname' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_standard',
  ),
  'getservbyport' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_standard',
  ),
  'gmp_and' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_gmp',
  ),
  'gmp_clrbit' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_gmp',
  ),
  'gmp_prob_prime' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_gmp',
  ),
  'gmp_random' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_gmp',
  ),
  'gmp_scan0' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_gmp',
  ),
  'gmp_powm' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_gmp',
  ),
  'gmp_pow' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_gmp',
  ),
  'gmp_or' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_gmp',
  ),
  'gmp_perfect_square' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_gmp',
  ),
  'gmp_popcount' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_gmp',
  ),
  'gmp_scan1' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_gmp',
  ),
  'gmp_setbit' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_gmp',
  ),
  'gmp_xor' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_gmp',
  ),
  'gzcompress' => 
  array (
    'init' => '4.0.1',
    'ext' => 'ext_zlib',
  ),
  'gzdeflate' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_zlib',
  ),
  'gmp_sub' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_gmp',
  ),
  'gmp_strval' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_gmp',
  ),
  'gmp_sign' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_gmp',
  ),
  'gmp_sqrt' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_gmp',
  ),
  'gmp_sqrtrem' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_gmp',
  ),
  'gmp_neg' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_gmp',
  ),
  'gmp_mul' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_gmp',
  ),
  'gmp_div_qr' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_gmp',
  ),
  'gmp_div_r' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_gmp',
  ),
  'gmp_fact' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_gmp',
  ),
  'gmp_div_q' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_gmp',
  ),
  'gmp_divexact' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_gmp',
  ),
  'gmp_cmp' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_gmp',
  ),
  'gmp_com' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_gmp',
  ),
  'gmp_div' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_gmp',
  ),
  'gmp_gcd' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_gmp',
  ),
  'gmp_gcdext' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_gmp',
  ),
  'gmp_jacobi' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_gmp',
  ),
  'gmp_legendre' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_gmp',
  ),
  'gmp_mod' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_gmp',
  ),
  'gmp_invert' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_gmp',
  ),
  'gmp_intval' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_gmp',
  ),
  'gmp_hamdist' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_gmp',
  ),
  'gmp_init' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_gmp',
  ),
  'domxml_node_set_namespace' => 
  array (
    'init' => '4.3.0',
  ),
  'domxml_node_set_content' => 
  array (
    'init' => '4.1.0',
  ),
  'bzflush' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_bz2',
  ),
  'bzopen' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_bz2',
  ),
  'bzread' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_bz2',
  ),
  'bzerrstr' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_bz2',
  ),
  'bzerror' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_bz2',
  ),
  'bzcompress' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_bz2',
  ),
  'bzdecompress' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_bz2',
  ),
  'bzerrno' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_bz2',
  ),
  'bzwrite' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_bz2',
  ),
  'call_user_func_array' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_standard',
  ),
  'ccvs_add' => 
  array (
    'init' => '4.0.2',
  ),
  'ccvs_auth' => 
  array (
    'init' => '4.0.2',
  ),
  'ccvs_command' => 
  array (
    'init' => '4.0.2',
  ),
  'cal_to_jd' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_calendar',
  ),
  'cal_info' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_calendar',
  ),
  'call_user_method_array' => 
  array (
    'init' => '4.0.5',
    'ext' => 'ext_standard',
  ),
  'cal_days_in_month' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_calendar',
  ),
  'cal_from_jd' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_calendar',
  ),
  'bzclose' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_bz2',
  ),
  'build_iovec' => 
  array (
    'init' => '4.0.2',
  ),
  'bind_textdomain_codeset' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_gettext',
  ),
  'birdstep_autocommit' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_odbc',
  ),
  'birdstep_close' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_odbc',
  ),
  'bind' => 
  array (
    'init' => '4.0.2',
  ),
  'atanh' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_standard',
  ),
  'asinh' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_standard',
  ),
  'assert' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_standard',
  ),
  'assert_options' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_standard',
  ),
  'birdstep_commit' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_odbc',
  ),
  'birdstep_connect' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_odbc',
  ),
  'birdstep_off_autocommit' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_odbc',
  ),
  'birdstep_result' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_odbc',
  ),
  'birdstep_rollback' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_odbc',
  ),
  'birdstep_freeresult' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_odbc',
  ),
  'birdstep_fieldnum' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_odbc',
  ),
  'birdstep_exec' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_odbc',
  ),
  'birdstep_fetch' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_odbc',
  ),
  'birdstep_fieldname' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_odbc',
  ),
  'ccvs_count' => 
  array (
    'init' => '4.0.2',
  ),
  'ccvs_delete' => 
  array (
    'init' => '4.0.2',
  ),
  'confirm_ctype_compiled' => 
  array (
    'init' => '4.0.0',
  ),
  'confirm_cybermut_compiled' => 
  array (
    'init' => '4.0.5',
  ),
  'confirm_ncurses_compiled' => 
  array (
    'init' => '4.1.0',
  ),
  'com_release' => 
  array (
    'init' => '4.1.0',
  ),
  'com_print_typeinfo' => 
  array (
    'init' => '4.2.3',
    'ext' => 'ext_com_dotnet',
  ),
  'COM_load' => 
  array (
    'init' => '4.0.5',
  ),
  'com_load_typelib' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_com_dotnet',
  ),
  'com_message_pump' => 
  array (
    'init' => '4.2.3',
    'ext' => 'ext_com_dotnet',
  ),
  'confirm_zziplib_compiled' => 
  array (
    'init' => '4.0.0',
  ),
  'connect' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_mysqli',
  ),
  'cpdf_set_font_map_file' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_cpdf',
  ),
  'crack_check' => 
  array (
    'init' => '4.0.5',
  ),
  'crack_closedict' => 
  array (
    'init' => '4.0.5',
  ),
  'cpdf_set_font_directories' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_cpdf',
  ),
  'cpdf_global_set_document_limits' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_cpdf',
  ),
  'constant' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_standard',
  ),
  'cosh' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_standard',
  ),
  'count_chars' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_standard',
  ),
  'com_isenum' => 
  array (
    'init' => '4.1.0',
  ),
  'com_invoke_ex' => 
  array (
    'init' => '4.3.0',
  ),
  'ccvs_return' => 
  array (
    'init' => '4.0.2',
  ),
  'ccvs_reverse' => 
  array (
    'init' => '4.0.2',
  ),
  'ccvs_sale' => 
  array (
    'init' => '4.0.2',
  ),
  'ccvs_report' => 
  array (
    'init' => '4.0.2',
  ),
  'ccvs_new' => 
  array (
    'init' => '4.0.2',
  ),
  'ccvs_done' => 
  array (
    'init' => '4.0.2',
  ),
  'ccvs_init' => 
  array (
    'init' => '4.0.2',
  ),
  'ccvs_lookup' => 
  array (
    'init' => '4.0.2',
  ),
  'ccvs_status' => 
  array (
    'init' => '4.0.2',
  ),
  'ccvs_textvalue' => 
  array (
    'init' => '4.0.2',
  ),
  'com_addref' => 
  array (
    'init' => '4.1.0',
  ),
  'com_event_sink' => 
  array (
    'init' => '4.2.3',
    'ext' => 'ext_com_dotnet',
  ),
  'COM_invoke' => 
  array (
    'init' => '4.0.5',
  ),
  'compact' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_standard',
  ),
  'close' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_mysqli',
  ),
  'ccvs_void' => 
  array (
    'init' => '4.0.2',
  ),
  'chroot' => 
  array (
    'init' => '4.0.5',
    'ext' => 'ext_standard',
  ),
  'class_exists' => 
  array (
    'init' => '4.0.0',
    'ext' => 'zend',
  ),
  'array_values' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_standard',
  ),
  'array_unshift' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_standard',
  ),
  'addaction' => 
  array (
    'init' => '4.0.5',
  ),
  'addcolor' => 
  array (
    'init' => '4.0.5',
  ),
  'addcslashes' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_standard',
  ),
  'add' => 
  array (
    'init' => '4.0.5',
  ),
  'acosh' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_standard',
  ),
  'vm_deluser' => 
  array (
    'init' => '4.0.0',
  ),
  'vm_passwd' => 
  array (
    'init' => '4.0.0',
  ),
  'accept_connect' => 
  array (
    'init' => '4.0.2',
  ),
  'addentry' => 
  array (
    'init' => '4.0.5',
  ),
  'addfill' => 
  array (
    'init' => '4.0.5',
  ),
  'aggregate_methods_by_list' => 
  array (
    'init' => '4.2.0',
  ),
  'aggregate_methods_by_regexp' => 
  array (
    'init' => '4.2.0',
  ),
  'aggregate_properties' => 
  array (
    'init' => '4.2.0',
  ),
  'aggregate_methods' => 
  array (
    'init' => '4.2.0',
  ),
  'aggregate' => 
  array (
    'init' => '4.2.0',
  ),
  'addshape' => 
  array (
    'init' => '4.0.5',
  ),
  'addstring' => 
  array (
    'init' => '4.0.5',
  ),
  'add_iovec' => 
  array (
    'init' => '4.0.2',
  ),
  'vm_delalias' => 
  array (
    'init' => '4.0.0',
  ),
  'vm_adduser' => 
  array (
    'init' => '4.0.0',
  ),
  'getlastref' => 
  array (
    'init' => '4.0.0',
  ),
  'getlogdir' => 
  array (
    'init' => '4.0.0',
  ),
  'getloghost' => 
  array (
    'init' => '4.0.0',
  ),
  'getlasthost' => 
  array (
    'init' => '4.0.0',
  ),
  'getlastemail' => 
  array (
    'init' => '4.0.0',
  ),
  'encrypt' => 
  array (
    'init' => '4.0.0',
  ),
  'getlastaccess' => 
  array (
    'init' => '4.0.0',
  ),
  'getlastbrowser' => 
  array (
    'init' => '4.0.0',
  ),
  'getstartlogging' => 
  array (
    'init' => '4.0.0',
  ),
  'gettoday' => 
  array (
    'init' => '4.0.0',
  ),
  'pg_setclientencoding' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_pgsql',
  ),
  'pg_set_client_encoding' => 
  array (
    'init' => '4.0.3',
    'ext' => 'ext_pgsql',
  ),
  'vm_addalias' => 
  array (
    'init' => '4.0.0',
  ),
  'pg_client_encoding' => 
  array (
    'init' => '4.0.3',
    'ext' => 'ext_pgsql',
  ),
  'pg_clientencoding' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_pgsql',
  ),
  'gettotal' => 
  array (
    'init' => '4.0.0',
  ),
  'imagetypes' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_gd',
  ),
  'logas' => 
  array (
    'init' => '4.0.0',
  ),
  'aggregate_properties_by_list' => 
  array (
    'init' => '4.2.0',
  ),
  'aggregate_properties_by_regexp' => 
  array (
    'init' => '4.2.0',
  ),
  'array_multisort' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_standard',
  ),
  'array_pad' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_standard',
  ),
  'array_pop' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_standard',
  ),
  'array_merge_recursive' => 
  array (
    'init' => '4.0.1',
    'ext' => 'ext_standard',
  ),
  'array_merge' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_standard',
  ),
  'array_keys' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_standard',
  ),
  'array_key_exists' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_standard',
  ),
  'array_map' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_standard',
  ),
  'array_push' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_standard',
  ),
  'array_rand' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_standard',
  ),
  'array_splice' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_standard',
  ),
  'array_sum' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_standard',
  ),
  'array_unique' => 
  array (
    'init' => '4.0.1',
    'ext' => 'ext_standard',
  ),
  'array_slice' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_standard',
  ),
  'array_shift' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_standard',
  ),
  'array_reduce' => 
  array (
    'init' => '4.0.5',
    'ext' => 'ext_standard',
  ),
  'array_reverse' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_standard',
  ),
  'array_search' => 
  array (
    'init' => '4.0.5',
    'ext' => 'ext_standard',
  ),
  'array_intersect_assoc' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_standard',
  ),
  'array_intersect' => 
  array (
    'init' => '4.0.1',
    'ext' => 'ext_standard',
  ),
  'apache_get_version' => 
  array (
    'init' => '4.3.2',
    'ext' => 'sapi_apache',
  ),
  'apache_request_headers' => 
  array (
    'init' => '4.3.0',
    'ext' => 'sapi_apache',
  ),
  'apache_response_headers' => 
  array (
    'init' => '4.3.0',
    'ext' => 'sapi_apache',
  ),
  'apache_get_modules' => 
  array (
    'init' => '4.3.2',
    'ext' => 'sapi_apache',
  ),
  'apache_getenv' => 
  array (
    'init' => '4.3.0',
    'ext' => 'sapi_apache2filter',
  ),
  'aggregation_info' => 
  array (
    'init' => '4.2.0',
  ),
  'align' => 
  array (
    'init' => '4.0.5',
  ),
  'apache_child_terminate' => 
  array (
    'init' => '4.0.5',
    'ext' => 'sapi_apache',
  ),
  'apache_setenv' => 
  array (
    'init' => '4.2.0',
    'ext' => 'sapi_apache',
  ),
  'apache_sub_req' => 
  array (
    'init' => '4.0.4',
  ),
  'array_fill' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_standard',
  ),
  'array_filter' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_standard',
  ),
  'array_flip' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_standard',
  ),
  'array_diff_assoc' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_standard',
  ),
  'array_diff' => 
  array (
    'init' => '4.0.1',
    'ext' => 'ext_standard',
  ),
  'array_change_key_case' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_standard',
  ),
  'array_chunk' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_standard',
  ),
  'array_count_values' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_standard',
  ),
  'crack_getlastmessage' => 
  array (
    'init' => '4.0.5',
  ),
  'crack_opendict' => 
  array (
    'init' => '4.0.5',
  ),
  'dbx_error' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_dbx',
  ),
  'dbx_escape_string' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_dbx',
  ),
  'dbx_query' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_dbx',
  ),
  'dbx_connect' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_dbx',
  ),
  'dbx_compare' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_dbx',
  ),
  'dbx_close' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_dbx',
  ),
  'dbx_cmp_asc' => 
  array (
    'init' => '4.0.0',
  ),
  'dbx_cmp_desc' => 
  array (
    'init' => '4.0.0',
  ),
  'dbx_sort' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_dbx',
  ),
  'db_id_list' => 
  array (
    'init' => '4.3.0',
  ),
  'dio_close' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_dio',
  ),
  'dio_fcntl' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_dio',
  ),
  'dio_open' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_dio',
  ),
  'delete_iovec' => 
  array (
    'init' => '4.0.2',
  ),
  'debug_zval_dump' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_standard',
  ),
  'dcngettext' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_gettext',
  ),
  'deaggregate' => 
  array (
    'init' => '4.2.0',
  ),
  'debug_backtrace' => 
  array (
    'init' => '4.3.0',
    'ext' => 'zend',
  ),
  'dbplus_xunlockrel' => 
  array (
    'init' => '4.1.0',
  ),
  'dbplus_xlockrel' => 
  array (
    'init' => '4.1.0',
  ),
  'dbplus_runlink' => 
  array (
    'init' => '4.1.0',
  ),
  'dbplus_rzap' => 
  array (
    'init' => '4.1.0',
  ),
  'dbplus_savepos' => 
  array (
    'init' => '4.1.0',
  ),
  'dbplus_rsecindex' => 
  array (
    'init' => '4.1.0',
  ),
  'dbplus_rrename' => 
  array (
    'init' => '4.1.0',
  ),
  'dbplus_rkeys' => 
  array (
    'init' => '4.1.0',
  ),
  'dbplus_ropen' => 
  array (
    'init' => '4.1.0',
  ),
  'dbplus_rquery' => 
  array (
    'init' => '4.1.0',
  ),
  'dbplus_setindex' => 
  array (
    'init' => '4.1.0',
  ),
  'dbplus_setindexbynumber' => 
  array (
    'init' => '4.1.0',
  ),
  'dbplus_unlockrel' => 
  array (
    'init' => '4.1.0',
  ),
  'dbplus_unselect' => 
  array (
    'init' => '4.1.0',
  ),
  'dbplus_update' => 
  array (
    'init' => '4.1.0',
  ),
  'dbplus_undoprepare' => 
  array (
    'init' => '4.1.0',
  ),
  'dbplus_undo' => 
  array (
    'init' => '4.1.0',
  ),
  'dbplus_sql' => 
  array (
    'init' => '4.1.0',
  ),
  'dbplus_tcl' => 
  array (
    'init' => '4.1.0',
  ),
  'dbplus_tremove' => 
  array (
    'init' => '4.1.0',
  ),
  'dio_read' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_dio',
  ),
  'dio_seek' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_dio',
  ),
  'domxml_getattr' => 
  array (
    'init' => '4.0.0',
  ),
  'domxml_get_attribute' => 
  array (
    'init' => '4.0.5',
  ),
  'domxml_html_dump_mem' => 
  array (
    'init' => '4.2.0',
  ),
  'domxml_elem_set_attribute' => 
  array (
    'init' => '4.1.0',
  ),
  'domxml_elem_get_attribute' => 
  array (
    'init' => '4.1.0',
  ),
  'domxml_dump_mem' => 
  array (
    'init' => '4.2.0',
  ),
  'domxml_dump_mem_file' => 
  array (
    'init' => '4.2.0',
  ),
  'domxml_dump_node' => 
  array (
    'init' => '4.2.0',
  ),
  'domxml_new_child' => 
  array (
    'init' => '4.0.0',
  ),
  'domxml_new_doc' => 
  array (
    'init' => '4.2.1',
  ),
  'domxml_node_get_content' => 
  array (
    'init' => '4.2.0',
  ),
  'domxml_node_has_attributes' => 
  array (
    'init' => '4.2.0',
  ),
  'domxml_node_new_child' => 
  array (
    'init' => '4.1.0',
  ),
  'domxml_node_children' => 
  array (
    'init' => '4.1.0',
  ),
  'domxml_node_attributes' => 
  array (
    'init' => '4.1.0',
  ),
  'domxml_new_xmldoc' => 
  array (
    'init' => '4.0.0',
  ),
  'domxml_node' => 
  array (
    'init' => '4.0.0',
  ),
  'domxml_node_add_namespace' => 
  array (
    'init' => '4.3.0',
  ),
  'domxml_dumpmem' => 
  array (
    'init' => '4.0.0',
  ),
  'domxml_doc_xinclude' => 
  array (
    'init' => '4.3.0',
  ),
  'disk_total_space' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_standard',
  ),
  'display_disabled_function' => 
  array (
    'init' => '4.0.1',
    'ext' => 'zend',
  ),
  'dngettext' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_gettext',
  ),
  'disk_free_space' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_standard',
  ),
  'dio_write' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_dio',
  ),
  'dio_stat' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_dio',
  ),
  'dio_tcsetattr' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_dio',
  ),
  'dio_truncate' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_dio',
  ),
  'domxml_add_root' => 
  array (
    'init' => '4.0.0',
  ),
  'domxml_attributes' => 
  array (
    'init' => '4.0.0',
  ),
  'domxml_doc_get_root' => 
  array (
    'init' => '4.3.0',
  ),
  'domxml_doc_set_root' => 
  array (
    'init' => '4.3.0',
  ),
  'domxml_doc_validate' => 
  array (
    'init' => '4.3.0',
  ),
  'domxml_doc_get_element_by_id' => 
  array (
    'init' => '4.2.1',
  ),
  'domxml_doc_get_elements_by_tagname' => 
  array (
    'init' => '4.2.1',
  ),
  'domxml_children' => 
  array (
    'init' => '4.0.0',
  ),
  'domxml_doc_add_root' => 
  array (
    'init' => '4.3.0',
  ),
  'domxml_doc_document_element' => 
  array (
    'init' => '4.3.0',
  ),
  'dbplus_restorepos' => 
  array (
    'init' => '4.1.0',
  ),
  'dbplus_resolve' => 
  array (
    'init' => '4.1.0',
  ),
  'cv_count' => 
  array (
    'init' => '4.0.2',
  ),
  'cv_delete' => 
  array (
    'init' => '4.0.2',
  ),
  'cv_done' => 
  array (
    'init' => '4.0.2',
  ),
  'cv_command' => 
  array (
    'init' => '4.0.2',
  ),
  'cv_auth' => 
  array (
    'init' => '4.0.2',
  ),
  'curl_setopt' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_curl',
  ),
  'curl_version' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_curl',
  ),
  'cv_add' => 
  array (
    'init' => '4.0.2',
  ),
  'cv_init' => 
  array (
    'init' => '4.0.2',
  ),
  'cv_lookup' => 
  array (
    'init' => '4.0.2',
  ),
  'cv_status' => 
  array (
    'init' => '4.0.2',
  ),
  'cv_textvalue' => 
  array (
    'init' => '4.0.2',
  ),
  'cv_void' => 
  array (
    'init' => '4.0.2',
  ),
  'cv_sale' => 
  array (
    'init' => '4.0.2',
  ),
  'cv_reverse' => 
  array (
    'init' => '4.0.2',
  ),
  'cv_new' => 
  array (
    'init' => '4.0.2',
  ),
  'cv_report' => 
  array (
    'init' => '4.0.2',
  ),
  'cv_return' => 
  array (
    'init' => '4.0.2',
  ),
  'curl_init' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_curl',
  ),
  'curl_getinfo' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_curl',
  ),
  'ctype_cntrl' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_ctype',
  ),
  'ctype_digit' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_ctype',
  ),
  'ctype_graph' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_ctype',
  ),
  'ctype_alpha' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_ctype',
  ),
  'ctype_alnum' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_ctype',
  ),
  'crash' => 
  array (
    'init' => '4.0.0',
    'ext' => 'zend',
  ),
  'crc32' => 
  array (
    'init' => '4.0.1',
    'ext' => 'ext_standard',
  ),
  'create_function' => 
  array (
    'init' => '4.0.1',
    'ext' => 'zend',
  ),
  'ctype_lower' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_ctype',
  ),
  'ctype_print' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_ctype',
  ),
  'curl_errno' => 
  array (
    'init' => '4.0.3',
    'ext' => 'ext_curl',
  ),
  'curl_error' => 
  array (
    'init' => '4.0.3',
    'ext' => 'ext_curl',
  ),
  'curl_exec' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_curl',
  ),
  'curl_close' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_curl',
  ),
  'ctype_xdigit' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_ctype',
  ),
  'ctype_punct' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_ctype',
  ),
  'ctype_space' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_ctype',
  ),
  'ctype_upper' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_ctype',
  ),
  'cybercash_base64_decode' => 
  array (
    'init' => '4.2.3',
  ),
  'cybercash_base64_encode' => 
  array (
    'init' => '4.2.3',
  ),
  'dbplus_freelock' => 
  array (
    'init' => '4.1.0',
  ),
  'dbplus_freerlocks' => 
  array (
    'init' => '4.1.0',
  ),
  'dbplus_getlock' => 
  array (
    'init' => '4.1.0',
  ),
  'dbplus_freealllocks' => 
  array (
    'init' => '4.1.0',
  ),
  'dbplus_flush' => 
  array (
    'init' => '4.1.0',
  ),
  'dbplus_errno' => 
  array (
    'init' => '4.1.0',
  ),
  'dbplus_find' => 
  array (
    'init' => '4.1.0',
  ),
  'dbplus_first' => 
  array (
    'init' => '4.1.0',
  ),
  'dbplus_getunique' => 
  array (
    'init' => '4.1.0',
  ),
  'dbplus_info' => 
  array (
    'init' => '4.1.0',
  ),
  'dbplus_rcreate' => 
  array (
    'init' => '4.1.0',
  ),
  'dbplus_rcrtexact' => 
  array (
    'init' => '4.1.0',
  ),
  'dbplus_rcrtlike' => 
  array (
    'init' => '4.1.0',
  ),
  'dbplus_rchperm' => 
  array (
    'init' => '4.1.0',
  ),
  'dbplus_prev' => 
  array (
    'init' => '4.1.0',
  ),
  'dbplus_last' => 
  array (
    'init' => '4.1.0',
  ),
  'dbplus_next' => 
  array (
    'init' => '4.1.0',
  ),
  'dbplus_open' => 
  array (
    'init' => '4.1.0',
  ),
  'dbplus_errcode' => 
  array (
    'init' => '4.1.0',
  ),
  'dbplus_curr' => 
  array (
    'init' => '4.1.0',
  ),
  'cyrus_authenticate' => 
  array (
    'init' => '4.1.0',
  ),
  'cyrus_bind' => 
  array (
    'init' => '4.1.0',
  ),
  'cyrus_close' => 
  array (
    'init' => '4.1.0',
  ),
  'cybermut_testmac' => 
  array (
    'init' => '4.0.5',
  ),
  'cybermut_creerreponsecm' => 
  array (
    'init' => '4.0.5',
  ),
  'cybercash_decr' => 
  array (
    'init' => '4.2.3',
  ),
  'cybercash_encr' => 
  array (
    'init' => '4.2.3',
  ),
  'cybermut_creerformulairecm' => 
  array (
    'init' => '4.0.5',
  ),
  'cyrus_connect' => 
  array (
    'init' => '4.1.0',
  ),
  'cyrus_query' => 
  array (
    'init' => '4.1.0',
  ),
  'dbplus_aql' => 
  array (
    'init' => '4.1.0',
  ),
  'dbplus_chdir' => 
  array (
    'init' => '4.1.0',
  ),
  'dbplus_close' => 
  array (
    'init' => '4.1.0',
  ),
  'dbplus_add' => 
  array (
    'init' => '4.1.0',
  ),
  'dba_list' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_dba',
  ),
  'cyrus_unbind' => 
  array (
    'init' => '4.1.0',
  ),
  'dba_handlers' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_dba',
  ),
  'imagetruecolortopalette' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_gd',
  ),
  'image_type_to_mime_type' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_standard',
  ),
  'ncurses_instr' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_isendwin' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_keyok' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_insstr' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_insertln' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_init_pair' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_insch' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_insdelln' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_keypad' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_killchar' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_move' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_move_panel' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_mvaddch' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_mouse_trafo' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_mousemask' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_longname' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_meta' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_mouseinterval' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_init_color' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_init' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_flushinp' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_getch' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_getmaxyx' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_flash' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_filter' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_end' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_erase' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_erasechar' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_getmouse' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_getyx' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_hide_panel' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_hline' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_inch' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_has_key' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_has_il' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_halfdelay' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_has_colors' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_has_ic' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_mvaddchnstr' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_mvaddchstr' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_qiflush' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_raw' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_refresh' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_putp' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_prefresh' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_panel_below' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_panel_window' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_pnoutrefresh' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_replace_panel' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_resetty' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_scr_init' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_scr_restore' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_scr_set' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_scr_dump' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_scrl' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_reset_prog_mode' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_reset_shell_mode' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_savetty' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_panel_above' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_pair_content' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_mvhline' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_mvinch' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_mvwaddstr' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_mvgetch' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_mvdelch' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_mvaddnstr' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_mvaddstr' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_mvcur' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_napms' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_newpad' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_nonl' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_noqiflush' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_noraw' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_noecho' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_nocbreak' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_newwin' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_new_panel' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_nl' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_echochar' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_echo' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'muscat_get' => 
  array (
    'init' => '4.0.5',
  ),
  'muscat_give' => 
  array (
    'init' => '4.0.5',
  ),
  'muscat_setup' => 
  array (
    'init' => '4.0.5',
  ),
  'muscat_close' => 
  array (
    'init' => '4.0.5',
  ),
  'multcolor' => 
  array (
    'init' => '4.0.5',
  ),
  'mssql_rows_affected' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_mssql',
  ),
  'mssql_set_message_handler' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_sybase_ct',
  ),
  'mssql_unbuffered_query' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_sybase_ct',
  ),
  'muscat_setup_net' => 
  array (
    'init' => '4.0.5',
  ),
  'mysql_client_encoding' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_mysql',
  ),
  'mysql_get_server_info' => 
  array (
    'init' => '4.0.5',
    'ext' => 'ext_mysql',
  ),
  'mysql_info' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_mysql',
  ),
  'mysql_list_processes' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_mysql',
  ),
  'mysql_get_proto_info' => 
  array (
    'init' => '4.0.5',
    'ext' => 'ext_mysql',
  ),
  'mysql_get_host_info' => 
  array (
    'init' => '4.0.5',
    'ext' => 'ext_mysql',
  ),
  'mysql_escape_string' => 
  array (
    'init' => '4.0.3',
    'ext' => 'ext_mysql',
  ),
  'mysql_fetch_assoc' => 
  array (
    'init' => '4.0.3',
    'ext' => 'ext_mysql',
  ),
  'mysql_get_client_info' => 
  array (
    'init' => '4.0.5',
    'ext' => 'ext_mysql',
  ),
  'mssql_next_result' => 
  array (
    'init' => '4.0.5',
    'ext' => 'ext_mssql',
  ),
  'mssql_init' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_mssql',
  ),
  'msg_receive' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_sysvmsg',
  ),
  'msg_remove_queue' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_sysvmsg',
  ),
  'msg_send' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_sysvmsg',
  ),
  'msg_get_queue' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_sysvmsg',
  ),
  'msession_unlock' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_msession',
  ),
  'msession_set_data' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_msession',
  ),
  'msession_timeout' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_msession',
  ),
  'msession_uniq' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_msession',
  ),
  'msg_set_queue' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_sysvmsg',
  ),
  'msg_stat_queue' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_sysvmsg',
  ),
  'mssql_Fetch_object' => 
  array (
    'init' => '4.0.0',
  ),
  'mssql_free_statement' => 
  array (
    'init' => '4.3.2',
    'ext' => 'ext_mssql',
  ),
  'mssql_guid_string' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_mssql',
  ),
  'mssql_fetch_batch' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_mssql',
  ),
  'mssql_fetch_assoc' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_mssql',
  ),
  'mssql_bind' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_mssql',
  ),
  'mssql_deadlock_retry_count' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_sybase_ct',
  ),
  'mssql_execute' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_mssql',
  ),
  'mysql_ping' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_mysql',
  ),
  'mysql_real_escape_string' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_mysql',
  ),
  'ncurses_clrtoeol' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_color_content' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_color_set' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_clrtobot' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_clear' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_bottom_panel' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_can_change_color' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_cbreak' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_curs_set' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_define_key' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_delwin' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_del_panel' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_doupdate' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_deleteln' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_delch' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_def_prog_mode' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_def_shell_mode' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_delay_output' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_border' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_bkgdset' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'natsort' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_standard',
  ),
  'ncurses_addch' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_addchnstr' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_ncurses',
  ),
  'natcasesort' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_standard',
  ),
  'mysql_unbuffered_query' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_mysql',
  ),
  'mysql_stat' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_mysql',
  ),
  'mysql_table_name' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_mysql',
  ),
  'mysql_thread_id' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_mysql',
  ),
  'ncurses_addchstr' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_addnstr' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_baudrate' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_beep' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_bkgd' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_attrset' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_attron' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_addstr' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_assume_default_colors' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_attroff' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_show_panel' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_slk_attr' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'odbc_errormsg' => 
  array (
    'init' => '4.0.5',
    'ext' => 'ext_odbc',
  ),
  'odbc_fetch_array' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_odbc',
  ),
  'odbc_fetch_object' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_odbc',
  ),
  'odbc_error' => 
  array (
    'init' => '4.0.5',
    'ext' => 'ext_odbc',
  ),
  'odbc_data_source' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_odbc',
  ),
  'ociwritelobtofile' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_oci8',
  ),
  'odbc_columnprivileges' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_odbc',
  ),
  'odbc_columns' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_odbc',
  ),
  'odbc_field_precision' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_odbc',
  ),
  'odbc_field_scale' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_odbc',
  ),
  'odbc_procedures' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_odbc',
  ),
  'odbc_specialcolumns' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_odbc',
  ),
  'odbc_statistics' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_odbc',
  ),
  'odbc_procedurecolumns' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_odbc',
  ),
  'odbc_primarykeys' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_odbc',
  ),
  'odbc_foreignkeys' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_odbc',
  ),
  'odbc_gettypeinfo' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_odbc',
  ),
  'odbc_next_result' => 
  array (
    'init' => '4.0.5',
    'ext' => 'ext_odbc',
  ),
  'ocisavelobfile' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_oci8',
  ),
  'ocisavelob' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_oci8',
  ),
  'ocicollgetelem' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_oci8',
  ),
  'ocicollmax' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_oci8',
  ),
  'ocicollsize' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_oci8',
  ),
  'ocicollassignelem' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_oci8',
  ),
  'ocicollassign' => 
  array (
    'init' => '4.0.6',
  ),
  'ob_list_handlers' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_standard',
  ),
  'ob_start' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_standard',
  ),
  'ocicollappend' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_oci8',
  ),
  'ocicolltrim' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_oci8',
  ),
  'ocicolumnprecision' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_oci8',
  ),
  'ociloadlob' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_oci8',
  ),
  'ocinewcollection' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_oci8',
  ),
  'ocipasswordchange' => 
  array (
    'init' => '4.3.2',
    'ext' => 'ext_oci8',
  ),
  'ocifreedesc' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_oci8',
  ),
  'ocifreecollection' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_oci8',
  ),
  'ocicolumnscale' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_oci8',
  ),
  'ocicolumntyperaw' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_oci8',
  ),
  'ocifreecoll' => 
  array (
    'init' => '4.0.0',
  ),
  'odbc_tableprivileges' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_odbc',
  ),
  'openssl_csr_export' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_openssl',
  ),
  'openssl_seal' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_openssl',
  ),
  'openssl_sign' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_openssl',
  ),
  'openssl_verify' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_openssl',
  ),
  'openssl_read_x509' => 
  array (
    'init' => '4.0.4',
  ),
  'openssl_read_publickey' => 
  array (
    'init' => '4.0.4',
  ),
  'openssl_private_encrypt' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_openssl',
  ),
  'openssl_public_decrypt' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_openssl',
  ),
  'openssl_public_encrypt' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_openssl',
  ),
  'openssl_x509_checkpurpose' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_openssl',
  ),
  'openssl_x509_check_private_key' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_openssl',
  ),
  'open_listen_sock' => 
  array (
    'init' => '4.0.2',
  ),
  'orbit_caught_exception' => 
  array (
    'init' => '4.0.3',
  ),
  'orbit_exception_id' => 
  array (
    'init' => '4.0.3',
  ),
  'openssl_x509_read' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_openssl',
  ),
  'openssl_x509_parse' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_openssl',
  ),
  'openssl_x509_export' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_openssl',
  ),
  'openssl_x509_export_to_file' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_openssl',
  ),
  'openssl_x509_free' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_openssl',
  ),
  'openssl_private_decrypt' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_openssl',
  ),
  'openssl_pkey_new' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_openssl',
  ),
  'openssl_free_x509' => 
  array (
    'init' => '4.0.4',
  ),
  'openssl_get_privatekey' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_openssl',
  ),
  'openssl_get_publickey' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_openssl',
  ),
  'openssl_free_key' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_openssl',
  ),
  'openssl_error_string' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_openssl',
  ),
  'openssl_csr_export_to_file' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_openssl',
  ),
  'openssl_csr_new' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_openssl',
  ),
  'openssl_csr_sign' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_openssl',
  ),
  'openssl_open' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_openssl',
  ),
  'openssl_pkcs7_decrypt' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_openssl',
  ),
  'openssl_pkey_free' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_openssl',
  ),
  'openssl_pkey_get_private' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_openssl',
  ),
  'openssl_pkey_get_public' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_openssl',
  ),
  'openssl_pkey_export_to_file' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_openssl',
  ),
  'openssl_pkey_export' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_openssl',
  ),
  'openssl_pkcs7_encrypt' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_openssl',
  ),
  'openssl_pkcs7_sign' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_openssl',
  ),
  'openssl_pkcs7_verify' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_openssl',
  ),
  'ob_implicit_flush' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_standard',
  ),
  'ob_iconv_handler' => 
  array (
    'init' => '4.0.5',
    'ext' => 'ext_iconv',
  ),
  'ncurses_vidattr' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_vline' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_waddch' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_use_extended_names' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_use_env' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_ungetmouse' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_update_panels' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_use_default_colors' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_waddstr' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_wattroff' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_werase' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_wgetch' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_whline' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_wcolor_set' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_wclear' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_wattron' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_wattrset' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_wborder' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_ungetch' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_typeahead' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_slk_init' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_slk_noutrefresh' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_slk_refresh' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_slk_color' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_slk_clear' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_slk_attroff' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_slk_attron' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_slk_attrset' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_slk_restore' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_slk_set' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_termname' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_timeout' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_top_panel' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_termattrs' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_start_color' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_slk_touch' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_standend' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_standout' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_wmouse_trafo' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_wmove' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_ncurses',
  ),
  'nsapi_response_headers' => 
  array (
    'init' => '4.3.3',
    'ext' => 'sapi_nsapi',
  ),
  'nsapi_virtual' => 
  array (
    'init' => '4.3.3',
    'ext' => 'sapi_nsapi',
  ),
  'ob_clean' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_standard',
  ),
  'nsapi_request_headers' => 
  array (
    'init' => '4.3.3',
    'ext' => 'sapi_nsapi',
  ),
  'notes_version' => 
  array (
    'init' => '4.0.5',
  ),
  'notes_nav_create' => 
  array (
    'init' => '4.0.5',
  ),
  'notes_search' => 
  array (
    'init' => '4.0.5',
  ),
  'notes_unread' => 
  array (
    'init' => '4.0.5',
  ),
  'ob_end_clean' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_standard',
  ),
  'ob_end_flush' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_standard',
  ),
  'ob_get_level' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_standard',
  ),
  'ob_get_status' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_standard',
  ),
  'ob_gzhandler' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_zlib',
  ),
  'ob_get_length' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_standard',
  ),
  'ob_get_flush' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_standard',
  ),
  'ob_flush' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_standard',
  ),
  'ob_get_clean' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_standard',
  ),
  'ob_get_contents' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_standard',
  ),
  'notes_mark_unread' => 
  array (
    'init' => '4.0.5',
  ),
  'notes_mark_read' => 
  array (
    'init' => '4.0.5',
  ),
  'new_xmldoc' => 
  array (
    'init' => '4.0.0',
  ),
  'nextframe' => 
  array (
    'init' => '4.0.5',
  ),
  'ngettext' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_gettext',
  ),
  'ncurses_wvline' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_wstandout' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_wnoutrefresh' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_wrefresh' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_ncurses',
  ),
  'ncurses_wstandend' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_ncurses',
  ),
  'nl_langinfo' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_standard',
  ),
  'notes_body' => 
  array (
    'init' => '4.0.5',
  ),
  'notes_find_note' => 
  array (
    'init' => '4.0.5',
  ),
  'notes_header_info' => 
  array (
    'init' => '4.0.5',
  ),
  'notes_list_msgs' => 
  array (
    'init' => '4.0.5',
  ),
  'notes_drop_db' => 
  array (
    'init' => '4.0.5',
  ),
  'notes_create_note' => 
  array (
    'init' => '4.0.5',
  ),
  'notes_copy_db' => 
  array (
    'init' => '4.0.5',
  ),
  'notes_create_db' => 
  array (
    'init' => '4.0.5',
  ),
  'msession_set_array' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_msession',
  ),
  'msession_set' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_msession',
  ),
  'mailparse_msg_extract_part_file' => 
  array (
    'init' => '4.1.0',
  ),
  'mailparse_msg_free' => 
  array (
    'init' => '4.1.0',
  ),
  'mailparse_msg_get_part' => 
  array (
    'init' => '4.1.0',
  ),
  'mailparse_msg_extract_part' => 
  array (
    'init' => '4.1.0',
  ),
  'mailparse_msg_create' => 
  array (
    'init' => '4.1.0',
  ),
  'log1p' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_standard',
  ),
  'long2ip' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_standard',
  ),
  'mailparse_determine_best_xfer_encoding' => 
  array (
    'init' => '4.1.0',
  ),
  'mailparse_msg_get_part_data' => 
  array (
    'init' => '4.1.0',
  ),
  'mailparse_msg_get_structure' => 
  array (
    'init' => '4.1.0',
  ),
  'mberegi' => 
  array (
    'init' => '4.2.0',
  ),
  'mberegi_replace' => 
  array (
    'init' => '4.2.0',
  ),
  'mbereg_match' => 
  array (
    'init' => '4.2.0',
  ),
  'mbereg' => 
  array (
    'init' => '4.2.0',
  ),
  'mailparse_stream_encode' => 
  array (
    'init' => '4.1.0',
  ),
  'mailparse_msg_parse' => 
  array (
    'init' => '4.1.0',
  ),
  'mailparse_msg_parse_file' => 
  array (
    'init' => '4.1.0',
  ),
  'mailparse_rfc822_parse_addresses' => 
  array (
    'init' => '4.1.0',
  ),
  'localtime' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_standard',
  ),
  'localeconv' => 
  array (
    'init' => '4.0.5',
    'ext' => 'ext_standard',
  ),
  'ldap_compare' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_ldap',
  ),
  'ldap_first_reference' => 
  array (
    'init' => '4.0.5',
    'ext' => 'ext_ldap',
  ),
  'ldap_get_option' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_ldap',
  ),
  'ldap_8859_to_t61' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_ldap',
  ),
  'lcg_value' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_standard',
  ),
  'jpeg2wbmp' => 
  array (
    'init' => '4.0.5',
    'ext' => 'ext_gd',
  ),
  'key_exists' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_standard',
  ),
  'labelframe' => 
  array (
    'init' => '4.0.5',
  ),
  'ldap_next_reference' => 
  array (
    'init' => '4.0.5',
    'ext' => 'ext_ldap',
  ),
  'ldap_parse_reference' => 
  array (
    'init' => '4.0.5',
    'ext' => 'ext_ldap',
  ),
  'ldap_start_tls' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_ldap',
  ),
  'ldap_t61_to_8859' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_ldap',
  ),
  'listen' => 
  array (
    'init' => '4.0.2',
  ),
  'ldap_sort' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_ldap',
  ),
  'ldap_set_rebind_proc' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_ldap',
  ),
  'ldap_parse_result' => 
  array (
    'init' => '4.0.5',
    'ext' => 'ext_ldap',
  ),
  'ldap_rename' => 
  array (
    'init' => '4.0.5',
    'ext' => 'ext_ldap',
  ),
  'ldap_set_option' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_ldap',
  ),
  'mbereg_replace' => 
  array (
    'init' => '4.2.0',
  ),
  'mbereg_search' => 
  array (
    'init' => '4.2.0',
  ),
  'mb_eregi_replace' => 
  array (
    'init' => '4.2.0',
  ),
  'mb_ereg_match' => 
  array (
    'init' => '4.2.0',
  ),
  'mb_ereg_replace' => 
  array (
    'init' => '4.2.0',
  ),
  'mb_eregi' => 
  array (
    'init' => '4.2.0',
  ),
  'mb_ereg' => 
  array (
    'init' => '4.2.0',
  ),
  'mb_detect_order' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_mbstring',
  ),
  'mb_encode_mimeheader' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_mbstring',
  ),
  'mb_encode_numericentity' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_mbstring',
  ),
  'mb_ereg_search' => 
  array (
    'init' => '4.2.0',
  ),
  'mb_ereg_search_getpos' => 
  array (
    'init' => '4.2.0',
  ),
  'mb_get_info' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_mbstring',
  ),
  'mb_http_input' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_mbstring',
  ),
  'mb_http_output' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_mbstring',
  ),
  'mb_ereg_search_setpos' => 
  array (
    'init' => '4.2.0',
  ),
  'mb_ereg_search_regs' => 
  array (
    'init' => '4.2.0',
  ),
  'mb_ereg_search_getregs' => 
  array (
    'init' => '4.2.0',
  ),
  'mb_ereg_search_init' => 
  array (
    'init' => '4.2.0',
  ),
  'mb_ereg_search_pos' => 
  array (
    'init' => '4.2.0',
  ),
  'mb_detect_encoding' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_mbstring',
  ),
  'mb_decode_numericentity' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_mbstring',
  ),
  'mbereg_search_setpos' => 
  array (
    'init' => '4.2.0',
  ),
  'mbregex_encoding' => 
  array (
    'init' => '4.2.0',
  ),
  'mbsplit' => 
  array (
    'init' => '4.2.0',
  ),
  'mbereg_search_regs' => 
  array (
    'init' => '4.2.0',
  ),
  'mbereg_search_pos' => 
  array (
    'init' => '4.2.0',
  ),
  'mbereg_search_getpos' => 
  array (
    'init' => '4.2.0',
  ),
  'mbereg_search_getregs' => 
  array (
    'init' => '4.2.0',
  ),
  'mbereg_search_init' => 
  array (
    'init' => '4.2.0',
  ),
  'mbstrcut' => 
  array (
    'init' => '4.0.6',
  ),
  'mbstrlen' => 
  array (
    'init' => '4.0.6',
  ),
  'mb_convert_kana' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_mbstring',
  ),
  'mb_convert_variables' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_mbstring',
  ),
  'mb_decode_mimeheader' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_mbstring',
  ),
  'mb_convert_encoding' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_mbstring',
  ),
  'mb_convert_case' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_mbstring',
  ),
  'mbstrpos' => 
  array (
    'init' => '4.0.6',
  ),
  'mbstrrpos' => 
  array (
    'init' => '4.0.6',
  ),
  'mbsubstr' => 
  array (
    'init' => '4.0.6',
  ),
  'jdtounix' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_calendar',
  ),
  'java_last_exception_get' => 
  array (
    'init' => '4.0.2',
  ),
  'ingres_rollback' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_ingres_ii',
  ),
  'ini_alter' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_standard',
  ),
  'ini_get' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_standard',
  ),
  'ingres_query' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_ingres_ii',
  ),
  'ingres_pconnect' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_ingres_ii',
  ),
  'ingres_field_type' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_ingres_ii',
  ),
  'ingres_num_fields' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_ingres_ii',
  ),
  'ingres_num_rows' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_ingres_ii',
  ),
  'ini_get_all' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_standard',
  ),
  'ini_restore' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_standard',
  ),
  'ircg_eval_ecmascript_params' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_ircg',
  ),
  'ircg_fetch_error_msg' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ircg',
  ),
  'ircg_get_username' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_ircg',
  ),
  'ircg_disconnect' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_ircg',
  ),
  'ircg_channel_mode' => 
  array (
    'init' => '4.0.5',
    'ext' => 'ext_ircg',
  ),
  'ini_set' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_standard',
  ),
  'in_array' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_standard',
  ),
  'ip2long' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_standard',
  ),
  'ingres_field_scale' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_ingres_ii',
  ),
  'ingres_field_precision' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_ingres_ii',
  ),
  'imap_thread' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_imap',
  ),
  'imap_timeout' => 
  array (
    'init' => '4.3.3',
    'ext' => 'ext_imap',
  ),
  'import_request_variables' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_standard',
  ),
  'imap_set_quota' => 
  array (
    'init' => '4.0.5',
    'ext' => 'ext_imap',
  ),
  'imap_setacl' => 
  array (
    'init' => '4.1.0',
    'ext' => 'ext_imap',
  ),
  'imap_get_quota' => 
  array (
    'init' => '4.0.5',
    'ext' => 'ext_imap',
  ),
  'imap_get_quotaroot' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_imap',
  ),
  'imap_rfc822_parse_headers' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_imap',
  ),
  'ingres_autocommit' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_ingres_ii',
  ),
  'ingres_close' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_ingres_ii',
  ),
  'ingres_field_length' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_ingres_ii',
  ),
  'ingres_field_name' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_ingres_ii',
  ),
  'ingres_field_nullable' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_ingres_ii',
  ),
  'ingres_fetch_row' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_ingres_ii',
  ),
  'ingres_fetch_object' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_ingres_ii',
  ),
  'ingres_commit' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_ingres_ii',
  ),
  'ingres_connect' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_ingres_ii',
  ),
  'ingres_fetch_array' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_ingres_ii',
  ),
  'ircg_html_encode' => 
  array (
    'init' => '4.0.5',
    'ext' => 'ext_ircg',
  ),
  'ircg_ignore_add' => 
  array (
    'init' => '4.0.5',
    'ext' => 'ext_ircg',
  ),
  'is_a' => 
  array (
    'init' => '4.2.0',
    'ext' => 'zend',
  ),
  'is_bool' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_standard',
  ),
  'is_callable' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_standard',
  ),
  'ircg_whois' => 
  array (
    'init' => '4.0.5',
    'ext' => 'ext_ircg',
  ),
  'ircg_who' => 
  array (
    'init' => '4.3.3',
    'ext' => 'ext_ircg',
  ),
  'ircg_set_file' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_ircg',
  ),
  'ircg_set_on_die' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_ircg',
  ),
  'ircg_topic' => 
  array (
    'init' => '4.0.5',
    'ext' => 'ext_ircg',
  ),
  'is_finite' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_standard',
  ),
  'is_infinite' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_standard',
  ),
  'is_subclass_of' => 
  array (
    'init' => '4.0.0',
    'ext' => 'zend',
  ),
  'is_writable' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_standard',
  ),
  'java_last_exception_clear' => 
  array (
    'init' => '4.0.2',
  ),
  'is_scalar' => 
  array (
    'init' => '4.0.5',
    'ext' => 'ext_standard',
  ),
  'is_resource' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_standard',
  ),
  'is_nan' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_standard',
  ),
  'is_null' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_standard',
  ),
  'is_numeric' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_standard',
  ),
  'ircg_set_current' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_ircg',
  ),
  'ircg_register_format_messages' => 
  array (
    'init' => '4.0.5',
    'ext' => 'ext_ircg',
  ),
  'ircg_list' => 
  array (
    'init' => '4.3.3',
    'ext' => 'ext_ircg',
  ),
  'ircg_lookup_format_messages' => 
  array (
    'init' => '4.0.5',
    'ext' => 'ext_ircg',
  ),
  'ircg_lusers' => 
  array (
    'init' => '4.3.3',
    'ext' => 'ext_ircg',
  ),
  'ircg_kick' => 
  array (
    'init' => '4.0.5',
    'ext' => 'ext_ircg',
  ),
  'ircg_join' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_ircg',
  ),
  'ircg_ignore_del' => 
  array (
    'init' => '4.0.5',
    'ext' => 'ext_ircg',
  ),
  'ircg_invite' => 
  array (
    'init' => '4.3.3',
    'ext' => 'ext_ircg',
  ),
  'ircg_is_conn_alive' => 
  array (
    'init' => '4.0.5',
    'ext' => 'ext_ircg',
  ),
  'ircg_msg' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_ircg',
  ),
  'ircg_names' => 
  array (
    'init' => '4.3.3',
    'ext' => 'ext_ircg',
  ),
  'ircg_oper' => 
  array (
    'init' => '4.3.3',
    'ext' => 'ext_ircg',
  ),
  'ircg_part' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_ircg',
  ),
  'ircg_pconnect' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_ircg',
  ),
  'ircg_notice' => 
  array (
    'init' => '4.0.5',
    'ext' => 'ext_ircg',
  ),
  'ircg_nickname_unescape' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_ircg',
  ),
  'ircg_nick' => 
  array (
    'init' => '4.0.5',
    'ext' => 'ext_ircg',
  ),
  'ircg_nickname_escape' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_ircg',
  ),
  'mb_internal_encoding' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_mbstring',
  ),
  'mb_language' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_mbstring',
  ),
  'mcve_text_avs' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_mcve',
  ),
  'mcve_text_code' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_mcve',
  ),
  'mcve_text_cv' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_mcve',
  ),
  'mcve_settle' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_mcve',
  ),
  'mcve_settimeout' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_mcve',
  ),
  'mcve_setip' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_mcve',
  ),
  'mcve_setssl' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_mcve',
  ),
  'mcve_setssl_files' => 
  array (
    'init' => '4.3.3',
    'ext' => 'ext_mcve',
  ),
  'mcve_transactionauth' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_mcve',
  ),
  'mcve_transactionavs' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_mcve',
  ),
  'mcve_transactiontext' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_mcve',
  ),
  'mcve_transinqueue' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_mcve',
  ),
  'mcve_transnew' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_mcve',
  ),
  'mcve_transactionssent' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_mcve',
  ),
  'mcve_transactionitem' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_mcve',
  ),
  'mcve_transactionbatch' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_mcve',
  ),
  'mcve_transactioncv' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_mcve',
  ),
  'mcve_transactionid' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_mcve',
  ),
  'mcve_setdropfile' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_mcve',
  ),
  'mcve_setblocking' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_mcve',
  ),
  'mcve_numcolumns' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_mcve',
  ),
  'mcve_numrows' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_mcve',
  ),
  'mcve_override' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_mcve',
  ),
  'mcve_monitor' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_mcve',
  ),
  'mcve_maxconntimeout' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_mcve',
  ),
  'mcve_iscommadelimited' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_mcve',
  ),
  'mcve_liststats' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_mcve',
  ),
  'mcve_listusers' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_mcve',
  ),
  'mcve_parsecommadelimited' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_mcve',
  ),
  'mcve_ping' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_mcve',
  ),
  'mcve_returncode' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_mcve',
  ),
  'mcve_returnstatus' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_mcve',
  ),
  'mcve_sale' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_mcve',
  ),
  'mcve_return' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_mcve',
  ),
  'mcve_responseparam' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_mcve',
  ),
  'mcve_preauth' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_mcve',
  ),
  'mcve_preauthcompletion' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_mcve',
  ),
  'mcve_qc' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_mcve',
  ),
  'mcve_transparam' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_mcve',
  ),
  'mcve_transsend' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_mcve',
  ),
  'msession_ctl' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_msession',
  ),
  'msession_destroy' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_msession',
  ),
  'msession_disconnect' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_msession',
  ),
  'msession_create' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_msession',
  ),
  'msession_count' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_msession',
  ),
  'move_uploaded_file' => 
  array (
    'init' => '4.0.3',
    'ext' => 'ext_standard',
  ),
  'msession_call' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_msession',
  ),
  'msession_connect' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_msession',
  ),
  'msession_find' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_msession',
  ),
  'msession_get' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_msession',
  ),
  'msession_lock' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_msession',
  ),
  'msession_plugin' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_msession',
  ),
  'msession_randstr' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_msession',
  ),
  'msession_listvar' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_msession',
  ),
  'msession_list' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_msession',
  ),
  'msession_get_array' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_msession',
  ),
  'msession_get_data' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_msession',
  ),
  'msession_inc' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_msession',
  ),
  'moveto' => 
  array (
    'init' => '4.0.5',
  ),
  'movepento' => 
  array (
    'init' => '4.0.5',
  ),
  'md5_file' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_standard',
  ),
  'mdecrypt_generic' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_mcrypt',
  ),
  'memory_get_usage' => 
  array (
    'init' => '4.3.2',
    'ext' => 'ext_standard',
  ),
  'mcve_void' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_mcve',
  ),
  'mcve_verifysslcert' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_mcve',
  ),
  'mcve_ub' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_mcve',
  ),
  'mcve_uwait' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_mcve',
  ),
  'mcve_verifyconnection' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_mcve',
  ),
  'metaphone' => 
  array (
    'init' => '4.0.0',
    'ext' => 'ext_standard',
  ),
  'method_exists' => 
  array (
    'init' => '4.0.0',
    'ext' => 'zend',
  ),
  'money_format' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_standard',
  ),
  'move' => 
  array (
    'init' => '4.0.5',
  ),
  'movepen' => 
  array (
    'init' => '4.0.5',
  ),
  'ming_useswfversion' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_ming',
  ),
  'ming_setscale' => 
  array (
    'init' => '4.0.5',
    'ext' => 'ext_ming',
  ),
  'mhash_keygen_s2k' => 
  array (
    'init' => '4.0.4',
    'ext' => 'ext_mhash',
  ),
  'mime_content_type' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_mime_magic',
  ),
  'ming_setcubicthreshold' => 
  array (
    'init' => '4.0.5',
    'ext' => 'ext_ming',
  ),
  'mcve_initusersetup' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_mcve',
  ),
  'mcve_initengine' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_mcve',
  ),
  'mcrypt_enc_get_key_size' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_mcrypt',
  ),
  'mcrypt_enc_get_modes_name' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_mcrypt',
  ),
  'mcrypt_enc_get_supported_key_sizes' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_mcrypt',
  ),
  'mcrypt_enc_get_iv_size' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_mcrypt',
  ),
  'mcrypt_enc_get_block_size' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_mcrypt',
  ),
  'mcrypt_decrypt' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_mcrypt',
  ),
  'mcrypt_encrypt' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_mcrypt',
  ),
  'mcrypt_enc_get_algorithms_name' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_mcrypt',
  ),
  'mcrypt_enc_is_block_algorithm' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_mcrypt',
  ),
  'mcrypt_enc_is_block_algorithm_mode' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_mcrypt',
  ),
  'mcrypt_generic_init' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_mcrypt',
  ),
  'mcrypt_get_iv_size' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_mcrypt',
  ),
  'mcrypt_list_algorithms' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_mcrypt',
  ),
  'mcrypt_generic_end' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_mcrypt',
  ),
  'mcrypt_generic_deinit' => 
  array (
    'init' => '4.1.1',
    'ext' => 'ext_mcrypt',
  ),
  'mcrypt_enc_is_block_mode' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_mcrypt',
  ),
  'mcrypt_enc_self_test' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_mcrypt',
  ),
  'mcrypt_generic' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_mcrypt',
  ),
  'mcal_week_of_year' => 
  array (
    'init' => '4.0.0',
  ),
  'mcal_append_event' => 
  array (
    'init' => '4.0.0',
  ),
  'mb_send_mail' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_mbstring',
  ),
  'mb_split' => 
  array (
    'init' => '4.2.0',
  ),
  'mb_strcut' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_mbstring',
  ),
  'mb_regex_set_options' => 
  array (
    'init' => '4.3.0',
  ),
  'mb_regex_encoding' => 
  array (
    'init' => '4.2.0',
  ),
  'mb_output_handler' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_mbstring',
  ),
  'mb_parse_str' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_mbstring',
  ),
  'mb_preferred_mime_name' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_mbstring',
  ),
  'mb_strimwidth' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_mbstring',
  ),
  'mb_strlen' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_mbstring',
  ),
  'mb_substitute_character' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_mbstring',
  ),
  'mb_substr' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_mbstring',
  ),
  'mb_substr_count' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_mbstring',
  ),
  'mb_strwidth' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_mbstring',
  ),
  'mb_strtoupper' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_mbstring',
  ),
  'mb_strpos' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_mbstring',
  ),
  'mb_strrpos' => 
  array (
    'init' => '4.0.6',
    'ext' => 'ext_mbstring',
  ),
  'mb_strtolower' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_mbstring',
  ),
  'mcrypt_list_modes' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_mcrypt',
  ),
  'mcrypt_module_close' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_mcrypt',
  ),
  'mcve_edituser' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_mcve',
  ),
  'mcve_enableuser' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_mcve',
  ),
  'mcve_force' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_mcve',
  ),
  'mcve_disableuser' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_mcve',
  ),
  'mcve_destroyengine' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_mcve',
  ),
  'mcve_deleteusersetup' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_mcve',
  ),
  'mcve_deluser' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_mcve',
  ),
  'mcve_destroyconn' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_mcve',
  ),
  'mcve_getcell' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_mcve',
  ),
  'mcve_getcellbynum' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_mcve',
  ),
  'mcve_gl' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_mcve',
  ),
  'mcve_gut' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_mcve',
  ),
  'mcve_initconn' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_mcve',
  ),
  'mcve_gft' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_mcve',
  ),
  'mcve_getuserparam' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_mcve',
  ),
  'mcve_getcommadelimited' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_mcve',
  ),
  'mcve_getheader' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_mcve',
  ),
  'mcve_getuserarg' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_mcve',
  ),
  'mcve_deletetrans' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_mcve',
  ),
  'mcve_deleteresponse' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_mcve',
  ),
  'mcrypt_module_is_block_mode' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_mcrypt',
  ),
  'mcrypt_module_open' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_mcrypt',
  ),
  'mcrypt_module_self_test' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_mcrypt',
  ),
  'mcrypt_module_is_block_algorithm_mode' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_mcrypt',
  ),
  'mcrypt_module_is_block_algorithm' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_mcrypt',
  ),
  'mcrypt_module_get_algo_block_size' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_mcrypt',
  ),
  'mcrypt_module_get_algo_key_size' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_mcrypt',
  ),
  'mcrypt_module_get_supported_key_sizes' => 
  array (
    'init' => '4.0.2',
    'ext' => 'ext_mcrypt',
  ),
  'mcve_adduser' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_mcve',
  ),
  'mcve_adduserarg' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_mcve',
  ),
  'mcve_completeauthorizations' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_mcve',
  ),
  'mcve_connect' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_mcve',
  ),
  'mcve_connectionerror' => 
  array (
    'init' => '4.3.0',
    'ext' => 'ext_mcve',
  ),
  'mcve_chngpwd' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_mcve',
  ),
  'mcve_chkpwd' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_mcve',
  ),
  'mcve_bt' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_mcve',
  ),
  'mcve_checkstatus' => 
  array (
    'init' => '4.2.0',
    'ext' => 'ext_mcve',
  ),
  'decrypt' => 
  array (
    'init' => '4.0.0',
  ),
)
?>