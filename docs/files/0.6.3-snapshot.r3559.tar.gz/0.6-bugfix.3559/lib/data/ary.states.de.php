<?php
    $states = array(
        ''      =>'',
        'BAY'   =>'Bayern',
        'BAWÜ'  =>'Baden-Württemberg',
        'BBG'   =>'Brandenburg',
        'HB'    =>'Freie Hansestadt Bremen',
        'HE'    =>'Hessen',
        'HH'    =>'Hansestadt Hamburg',
        'MV'    =>'Mecklenburg-Vorpommern',
        'NdS'   =>'Niedersachsen',
        'NRW'   =>'Nordrhein-Westfalen',
        'RP'    =>'Rheinland-Pfalz',
        'SA'    =>'Sachsen',
        'SAAN'  =>'Sachsen-Anahlt',
        'SAAR'  =>'Saarland',
        'SH'    =>'Schleswig-Hostein',
        'TH'    =>'Thüringen',
    );
?>
