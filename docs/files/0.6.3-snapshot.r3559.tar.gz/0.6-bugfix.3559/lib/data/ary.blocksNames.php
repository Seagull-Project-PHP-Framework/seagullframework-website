<?php
$aBlocksNames = array(
    'Right'=> 'Right',
    'Left' => 'Left',
    'Top' => 'Top',
    'Bottom' => 'Bottom',
    'BodyTop' => 'BodyTop',
    'AdminCategory' => 'AdminCategory',
    'AdminNav' => 'AdminNav',
    'AdminBreadcrumbs' => 'AdminBreadcrumbs',
    'MainNav' => 'MainNav',
    'MainBreadcrumb' => 'MainBreadcrumb',
    );
?>
