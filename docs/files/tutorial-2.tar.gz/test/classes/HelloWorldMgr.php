<?php
class HelloWorldMgr extends SGL_Manager
{
    function HelloWorldMgr()
    {
        parent::SGL_Manager();
        $this->_aActionsMapping =  array(
            'sayHello'    => array('sayHello'),
            'sayGoodBye'    => array('sayGoodBye'),
        );
    }

    function validate($req, &$input)
    {
        $this->validated = true;
        $input->action   = ($req->get('action')) ? $req->get('action') : 'sayHello';
    }

    function display(&$output)
    {
        $output->template = 'helloWorld.html';
        $output->testVariable = 'World!';
    }

    function _cmd_sayHello(&$input, &$output)
    {
        $output->word = 'Hello';
    }

    function _cmd_sayGoodBye(&$input, &$output)
    {
        $output->word = 'Goodbye';
    }
}
?>