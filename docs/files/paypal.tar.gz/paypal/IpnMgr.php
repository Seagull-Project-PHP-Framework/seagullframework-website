<?php
/* Reminder: always indent with 4 spaces (no tabs). */
// +---------------------------------------------------------------------------+
// | Seagull 0.3                                                               |
// +---------------------------------------------------------------------------+
// | IpnMgr.php                                                                |
// +---------------------------------------------------------------------------+
// | Copyright (C) 2003 Demian Turner                                          |
// |                                                                           |
// | Author: Demian Turner <demian@phpkitchen.com>                             |
// +---------------------------------------------------------------------------+
// |                                                                           |
// | This library is free software; you can redistribute it and/or             |
// | modify it under the terms of the GNU Library General Public               |
// | License as published by the Free Software Foundation; either              |
// | version 2 of the License, or (at your option) any later version.          |
// |                                                                           |
// | This library is distributed in the hope that it will be useful,           |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of            |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU         |
// | Library General Public License for more details.                          |
// |                                                                           |
// | You should have received a copy of the GNU Library General Public         |
// | License along with this library; if not, write to the Free                |
// | Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA |
// |                                                                           |
// +---------------------------------------------------------------------------+
//

require_once SGL_CORE_DIR . '/Manager.php';
require_once SGL_LIB_DIR . '/paypal_ipn.php';
require_once SGL_ENT_DIR . '/Transaction.php';

/**
 * To allow users to contact site admins.
 *
 * @package faq
 * @author  Demian Turner <demian@phpkitchen.com>
 * @version 0.3
 * @since   PHP 4.0
 */
class IpnMgr extends Manager
{
    var $module = 'property';

    function IpnMgr()
    {
        Base::logMessage(   __CLASS__ . '::' . __FUNCTION__ ,
                            null, null, PEAR_LOG_DEBUG);
    }

    function validate($req, $input)
    {
        Base::logMessage(   __CLASS__ . '::' . __FUNCTION__ ,
                            null, null, PEAR_LOG_DEBUG);
        $this->validated    = true;
        $input->error       = array();
        $input->action      = $req->get('action');
        $input->submit      = $req->get('submitted');
        return $input;
    }

    function process($input, $output)
    {
        Base::logMessage(   __CLASS__ . '::' . __FUNCTION__ ,
                            null, null, PEAR_LOG_DEBUG);

        $paypal_info = $_POST;
ob_start();
print_r($paypal_info);
$test = ob_get_contents();
ob_end_clean();
error_log('debug = ' . $test);
        // To disable https posting to PayPal uncomment the following
        // $paypal_ipn = new paypal_ipn($paypal_info, "");
        
        // Then comment out this one
        $paypal_ipn = new paypal_ipn($paypal_info, 's', SGL_LOG_DIR . '/paypal.txt');
        
        // where to contact us if something goes wrong
        $paypal_ipn->error_email = "demian@muse23.com";
        
        // We send an identical response back to PayPal for verification
        $paypal_ipn->send_response();
        
        // PayPal will tell us whether or not this order is valid.
        // This will prevent people from simply running your order script
        // manually
        if( !$paypal_ipn->is_verified() )
        {
        	// bad order, someone must have tried to run this script manually
        	$paypal_ipn->error_out("Bad order (PayPal says it's invalid)");
        }


// payment status
error_log($paypal_ipn->get_payment_status());
switch ($paypal_ipn->get_payment_status() )
{
	case 'Completed':
		// order is good
	break;

	case 'Pending':
		// money isn't in yet, just quit.
		// paypal will contact this script again when it's ready
		$paypal_ipn->error_out("Pending Payment");
	break;

	case 'Failed':
		// whoops, not enough money
		$paypal_ipn->error_out("Failed Payment");
	break;

	case 'Denied':
		// denied payment by us
		// not sure what causes this one
		$paypal_ipn->error_out("Denied Payment");
	break;

	default:
		// order is no good
		$paypal_ipn->error_out("Unknown Payment Status" . $paypal_ipn->get_payment_status());
	break;
}

// If we made it down here, the order is verified and payment is complete.
// You could log the order to a MySQL database or do anything else at this point.
@reset($paypal_info);
//  checks
#if ($paypal_info['payer_status'] != 'verified') {
#    $aErrors[] = 'payer unverfied';
#}
if ($paypal_info['receiver_email'] != 'mark@sudburyenterprises.com') {
    $aErrors[] = 'incorrect payee email';
}
if ($paypal_info['mc_gross'] != '9.95') {
    $aErrors[] = 'incorrect amount';
}
if ($paypal_info['mc_currency'] != 'USD') {
    $aErrors[] = 'incorrect currency';
}
if ($paypal_info['quantity'] != 1) {
    $aErrors[] = 'incorrect amount';
}
if (!$this->_isTxnUnique($paypal_info['txn_id'])) {
    $aErrors[] = 'transaction not unique';
}

$date = date("D M j G:i:s T Y", time());
if (isset($aErrors) && count($aErrors)) {
    $text = "Transaction was aborted for the following reasons: \n\n";
    $text .= implode('\n', $aErrors);
    mail("demian@phpkitchen.com", "[$date] PayPal Payment Notification Errors", $text);
    exit;
}

//  otherwise prepare transaction insert
$oTxn = & new DataObjects_Transaction();
$dbh = $oTxn->getDatabaseConnection();
$oTxn->transaction_id = $dbh->nextId('transaction');
//  convert paypal date to mysql datetime
$paymentDate = $paypal_info['payment_date'];
$timestamp = strtotime($paymentDate);
$mysqlDateTime = date('Y-m-d h:i:s', $timestamp);
$oTxn->purchase_date = $mysqlDateTime;
$oTxn->txn_id = $paypal_info['txn_id'];
$oTxn->txn_type = $paypal_info['txn_type'];
$oTxn->item_number = $paypal_info['item_number'];
$oTxn->quantity = $paypal_info['quantity'];
$oTxn->amount = $paypal_info['payment_gross'];
$oTxn->payer_id = $paypal_info['payer_id'];
$oTxn->payer_first_name = $paypal_info['first_name'];
$oTxn->payer_last_name = $paypal_info['last_name'];
$oTxn->payer_email = $paypal_info['payer_email'];
$oTxn->receiver_id = $paypal_info['receiver_id'];
$oTxn->hash = $paypal_info['verify_sign'];
$oTxn->payment_type = $paypal_info['payment_type'];
$oTxn->notify_version = $paypal_info['notify_version'];
$insSuccess = $oTxn->insert();

if ($insSuccess) {
    require_once SGL_ENT_DIR . '/Usr.php';
    $oUser = & new DataObjects_Usr();
    $oUser->get($paypal_info['custom']);
    //  determine acct expiry date
    $currYear = date('Y');
    $expiryMysqlDateTime = date($currYear+1 .'-m-d h:i:s', $timestamp);
    $oUser->acct_expiry_time = $expiryMysqlDateTime;
    $updSuccess = $oUser->update();
}

// Email the information to us
$message .= "\n\nThe following info was received from PayPal - $date:\n\n";
@reset($paypal_info);
while( @list($key,$value) = @each($paypal_info) )
{
	$message .= $key . ':' . " \t$value\n";
}
$message .= "\ntranaction record inserted correctly = " .  (($insSuccess) ? 'YES' : 'NO');
$message .= "\nuser record updated correctly = " .  (($updSuccess) ? 'YES' : 'NO');
mail("demian@phpkitchen.com", "[$date] PayPal Payment Notification", $message);

        return $output;
    }

    function display($output)
    {
        Base::logMessage(   __CLASS__ . '::' . __FUNCTION__ ,
                            null, null, PEAR_LOG_DEBUG);
        return $output;
    }

    function _isTxnUnique($txn)
    {
        if (isset($txn)) {
            $oTxn = & new DataObjects_Transaction();
            $oTxn->whereAdd("txn_id = '$txn'");
            $numRows = $oTxn->find();
            //  return false if any rows found
            return (boolean)$numRows == 0;
        }
    }

}
?>