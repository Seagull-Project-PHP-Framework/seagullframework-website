CREATE TABLE `transaction` (
  `transaction_id` int(11) NOT NULL default '0',
  `txn_id` varchar(32) NOT NULL default '',
  `txn_type` varchar(16) NOT NULL default '',
  `purchase_date` datetime NOT NULL default '0000-00-00 00:00:00',
  `item_number` varchar(64) NOT NULL default '',
  `quantity` int(5) NOT NULL default '0',
  `amount` float(5,2) NOT NULL default '0.00',
  `payer_id` varchar(16) NOT NULL default '',
  `payer_first_name` varchar(64) NOT NULL default '',
  `payer_last_name` varchar(64) NOT NULL default '',
  `payer_email` varchar(128) NOT NULL default '',
  `receiver_id` varchar(16) NOT NULL default '',
  `hash` varchar(64) NOT NULL default '',
  `payment_type` varchar(16) NOT NULL default '',
  `notify_version` varchar(5) NOT NULL default '',
  PRIMARY KEY  (`transaction_id`),
  UNIQUE KEY `txn_id` (`txn_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
