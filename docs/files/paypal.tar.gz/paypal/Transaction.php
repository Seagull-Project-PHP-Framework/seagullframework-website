<?php
/**
 * Table Definition for transaction
 */
require_once 'DB/DataObject.php';

class DataObjects_Transaction extends DB_DataObject 
{

    ###START_AUTOCODE
    /* the code below is auto generated do not remove the above tag */

    var $__table = 'transaction';                     // table name
    var $transaction_id;                  // int(11)  not_null primary_key
    var $txn_id;                          // string(32)  not_null unique_key
    var $txn_type;                        // string(16)  not_null
    var $purchase_date;                   // datetime(19)  not_null
    var $item_number;                     // string(64)  not_null
    var $quantity;                        // int(5)  not_null
    var $amount;                          // real(5)  not_null
    var $payer_id;                        // string(16)  not_null
    var $payer_first_name;                // string(64)  not_null
    var $payer_last_name;                 // string(64)  not_null
    var $payer_email;                     // string(128)  not_null
    var $receiver_id;                     // string(16)  not_null
    var $hash;                            // string(64)  not_null
    var $payment_type;                    // string(16)  not_null
    var $notify_version;                  // string(5)  not_null

    /* ZE2 compatibility trick*/
    function __clone() { return $this;}

    /* Static get */
    function staticGet($k,$v=NULL) { return DB_DataObject::staticGet('DataObjects_Transaction',$k,$v); }

    /* the code above is auto generated do not remove the tag below */
    ###END_AUTOCODE
}
?>