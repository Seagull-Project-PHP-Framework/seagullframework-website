<?php
/**
 * Table Definition for liveuser_groups
 */
require_once 'DB/DataObject.php';

class DataObjects_Liveuser_groups extends DB_DataObject 
{
    ###START_AUTOCODE
    /* the code below is auto generated do not remove the above tag */

    var $__table = 'liveuser_groups';                 // table name
    var $group_id;                        // int(10)  not_null primary_key unsigned
    var $owner_perm_user_id;              // int(20)  multiple_key
    var $owner_group_id;                  // int(11)  multiple_key
    var $is_active;                       // string(1)  not_null
    var $group_define_name;               // string(32)  not_null
    var $description;                     // blob(65535)  not_null blob

    /* ZE2 compatibility trick*/
    function __clone() { return $this;}

    /* Static get */
    function staticGet($k,$v=NULL) { return DB_DataObject::staticGet('DataObjects_Liveuser_groups',$k,$v); }

    /* the code above is auto generated do not remove the tag below */
    ###END_AUTOCODE
    
    /**
     * Delete associated rows
     */
    function delete($useWhere = false)
    {
        // delete rights from linked table (not rights!)
        require_once SGL_ENT_DIR . '/Liveuser_grouprights.php';
        $groupRights =& new DataObjects_Liveuser_grouprights();
        $groupRights->group_id = $this->group_id;
        $groupRights->find();
        if(!empty($groupRights->N)) {
            $ret = $groupRights->delete();
            if(PEAR::isError($ret)) {
                Base::raiseError('There was a problem deleting the record '
                    . __FILE__ . ':' . __LINE__, 
                    SGL_ERROR_NOAFFECTEDROWS);
            }
        }
        unset($groupRights);
        
        // delete groupusers from linked table (not users!)
        require_once SGL_ENT_DIR . '/Liveuser_groupusers.php';
        $groupUsers =& new DataObjects_Liveuser_groupusers();
        $groupUsers->group_id = $this->group_id;
        $groupUsers->find();
        if(!empty($groupUsers->N)) {
            $ret = $groupUsers->delete();
            if(!$ret || PEAR::isError($ret)) {
                Base::raiseError('There was a problem deleting the record '
                    . __FILE__ . ':' . __LINE__, 
                    SGL_ERROR_NOAFFECTEDROWS);
            }
        }
        unset($groupUsers);
        return parent::delete($useWhere);
    }
    
    function getGroups()
    {
        $groups = array();
        $this->find();
        while($this->fetch()) {
            $groups[$this->group_id] = $this->group_define_name;
        }
        return $groups;
    }
    
}

?>