<?php
/**
 * Table Definition for liveuser_languages
 */
require_once 'DB/DataObject.php';

class DataObjects_Liveuser_languages extends DB_DataObject 
{

    ###START_AUTOCODE
    /* the code below is auto generated do not remove the above tag */

    var $__table = 'liveuser_languages';              // table name
    var $language_id;                     // int(5)  not_null primary_key unsigned
    var $two_letter_name;                 // string(2)  
    var $native_name;                     // string(50)  

    /* ZE2 compatibility trick*/
    function __clone() { return $this;}

    /* Static get */
    function staticGet($k,$v=NULL) { return DB_DataObject::staticGet('DataObjects_Liveuser_languages',$k,$v); }

    /* the code above is auto generated do not remove the tag below */
    ###END_AUTOCODE
}
?>