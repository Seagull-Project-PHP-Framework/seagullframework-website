<?php
/**
 * Table Definition for liveuser_rights
 */
require_once 'DB/DataObject.php';

class DataObjects_Liveuser_rights extends DB_DataObject 
{

    ###START_AUTOCODE
    /* the code below is auto generated do not remove the above tag */

    var $__table = 'liveuser_rights';                 // table name
    var $right_id;                        // int(10)  not_null primary_key unsigned
    var $area_id;                         // int(11)  not_null multiple_key
    var $right_define_name;               // string(100)  not_null
    var $right_constant;                  // string(50)  not_null
    var $has_implied;                     // string(1)  not_null
    var $has_level;                       // string(1)  not_null
    var $has_scope;                       // string(1)  not_null

    /* ZE2 compatibility trick*/
    function __clone() { return $this;}

    /* Static get */
    function staticGet($k,$v=NULL) { return DB_DataObject::staticGet('DataObjects_Liveuser_rights',$k,$v); }

    /* the code above is auto generated do not remove the tag below */
    ###END_AUTOCODE
}
?>