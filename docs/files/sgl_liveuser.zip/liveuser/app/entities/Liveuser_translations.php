<?php
/**
 * Table Definition for liveuser_translations
 */
require_once 'DB/DataObject.php';

class DataObjects_Liveuser_translations extends DB_DataObject 
{

    ###START_AUTOCODE
    /* the code below is auto generated do not remove the above tag */

    var $__table = 'liveuser_translations';           // table name
    var $section_id;                      // int(16)  not_null primary_key unsigned
    var $section_type;                    // string(16)  not_null primary_key
    var $language_id;                     // int(5)  unsigned
    var $name;                            // string(50)  not_null
    var $description;                     // string(255)  

    /* ZE2 compatibility trick*/
    function __clone() { return $this;}

    /* Static get */
    function staticGet($k,$v=NULL) { return DB_DataObject::staticGet('DataObjects_Liveuser_translations',$k,$v); }

    /* the code above is auto generated do not remove the tag below */
    ###END_AUTOCODE
}
?>