<?php
/**
 * Table Definition for liveuser_right_scopes
 */
require_once 'DB/DataObject.php';

class DataObjects_Liveuser_right_scopes extends DB_DataObject 
{

    ###START_AUTOCODE
    /* the code below is auto generated do not remove the above tag */

    var $__table = 'liveuser_right_scopes';           // table name
    var $right_id;                        // int(11)  not_null primary_key
    var $type;                            // int(3)  not_null unsigned

    /* ZE2 compatibility trick*/
    function __clone() { return $this;}

    /* Static get */
    function staticGet($k,$v=NULL) { return DB_DataObject::staticGet('DataObjects_Liveuser_right_scopes',$k,$v); }

    /* the code above is auto generated do not remove the tag below */
    ###END_AUTOCODE
}
?>