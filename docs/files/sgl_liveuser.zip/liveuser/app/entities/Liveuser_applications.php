<?php
/**
 * Table Definition for liveuser_applications
 */
require_once 'DB/DataObject.php';

class DataObjects_Liveuser_applications extends DB_DataObject 
{

    ###START_AUTOCODE
    /* the code below is auto generated do not remove the above tag */

    var $__table = 'liveuser_applications';           // table name
    var $application_id;                  // int(10)  not_null primary_key unsigned
    var $application_define_name;         // string(20)  not_null unique_key

    /* ZE2 compatibility trick*/
    function __clone() { return $this;}

    /* Static get */
    function staticGet($k,$v=NULL) { return DB_DataObject::staticGet('DataObjects_Liveuser_applications',$k,$v); }

    /* the code above is auto generated do not remove the tag below */
    ###END_AUTOCODE
}
?>