<?php
/**
 * Table Definition for liveuser_groupusers
 */
require_once 'DB/DataObject.php';

class DataObjects_Liveuser_groupusers extends DB_DataObject 
{

    ###START_AUTOCODE
    /* the code below is auto generated do not remove the above tag */

    var $__table = 'liveuser_groupusers';             // table name
    var $perm_user_id;                    // int(20)  not_null primary_key
    var $group_id;                        // int(11)  not_null primary_key

    /* ZE2 compatibility trick*/
    function __clone() { return $this;}

    /* Static get */
    function staticGet($k,$v=NULL) { return DB_DataObject::staticGet('DataObjects_Liveuser_groupusers',$k,$v); }

    /* the code above is auto generated do not remove the tag below */
    ###END_AUTOCODE
    
    /**
     * Get user groups
     *
     */
    function getGroups($user_id)
    {
        $groups = array();
        $this->perm_user_id = $user_id;
        $this->find();
        while($this->fetch()) {
            $groups[$this->group_id] = $this->group_id;
        }
        return $groups;
    }
}
?>