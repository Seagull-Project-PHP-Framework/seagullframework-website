<?php
/**
 * Table Definition for liveuser_grouprights
 */
require_once 'DB/DataObject.php';

class DataObjects_Liveuser_grouprights extends DB_DataObject 
{

    ###START_AUTOCODE
    /* the code below is auto generated do not remove the above tag */

    var $__table = 'liveuser_grouprights';            // table name
    var $group_id;                        // int(11)  not_null primary_key
    var $right_id;                        // int(11)  not_null primary_key
    var $right_level;                     // int(3)  unsigned

    /* ZE2 compatibility trick*/
    function __clone() { return $this;}

    /* Static get */
    function staticGet($k,$v=NULL) { return DB_DataObject::staticGet('DataObjects_Liveuser_grouprights',$k,$v); }

    /* the code above is auto generated do not remove the tag below */
    ###END_AUTOCODE
}
?>