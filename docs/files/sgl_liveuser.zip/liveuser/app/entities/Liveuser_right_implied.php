<?php
/**
 * Table Definition for liveuser_right_implied
 */
require_once 'DB/DataObject.php';

class DataObjects_Liveuser_right_implied extends DB_DataObject 
{

    ###START_AUTOCODE
    /* the code below is auto generated do not remove the above tag */

    var $__table = 'liveuser_right_implied';          // table name
    var $right_id;                        // int(11)  not_null primary_key
    var $implied_right_id;                // int(11)  not_null primary_key

    /* ZE2 compatibility trick*/
    function __clone() { return $this;}

    /* Static get */
    function staticGet($k,$v=NULL) { return DB_DataObject::staticGet('DataObjects_Liveuser_right_implied',$k,$v); }

    /* the code above is auto generated do not remove the tag below */
    ###END_AUTOCODE
}
?>