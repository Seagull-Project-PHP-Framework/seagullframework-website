<?php

/**
 * Admin right
 */
define('SGL_RIGHT_ADMIN',              1); // implied everything

/**
 * Right to grant rights
 */
define('SGL_RIGHT_GRANT_RIGHTS',       2);

/**
 * Managing groups
 */
define('SGL_RIGHT_MANAGE_USER_GROUPS', 3);

/**
 * Managing users
 */
define('SGL_RIGHT_MANAGE_USERS',       4);

?>