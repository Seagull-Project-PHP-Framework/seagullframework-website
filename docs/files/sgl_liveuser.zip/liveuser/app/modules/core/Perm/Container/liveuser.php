<?php

require_once 'LiveUser/LiveUser.php';

class Perm_LiveUser
{
    var $container;
    
    function Perm_LiveUser($options)
    {
          
        $dbh = & Base::DB();
        
        $LUOptions = array('autoInit'       => true,
                           'login'          => array('force' => true),
                           'authContainers' => array(array(
                                                        'type'    => 'SGL_Auth',
                                                        'loginTimeout'  => $options['sessionTimeout'],
                                                        'expireTime'    => $options['sessionMaxLifetime'],
                                                        'idleTime'      => 1800,
                                                        'allowDuplicateHandles' => 0,
                                                        'authTable'     => $options['authTable'],
                                                        'authTableCols' => array('user_id'  => 'id',
                                                                                 'handle'   => 'username',
                                                                                 'passwd'   => 'passwd',
                                                                                 //'lastlogin' => 'lastlogin'
                                                                             )
                                                    )
                                              ),
                           'permContainer'  => array('type' => 'DB_Complex',
                                               'connection' => $dbh,
                                               'prefix'     => 'liveuser_'),
                           'session'        => array('name' => session_name()),
                    );   

        $this->container =& LiveUser::factory($LUOptions);
        $this->container->tryLogin($options['handle']);
    }
      
    function &readRights() 
    {
        if(method_exists($this->container, 'readRights')) {
            return $this->container->readRights();
        } else {
            return array();
        }
    }
      
    function checkRight($right_id)
    {
        $has_right = $this->container->checkRight($right_id);
        return $has_right;
    }
    
    function listUsers(&$output)
    {
        // change template
        $output->pluginTemplateDir = 'liveuser';
        $output->template = 'liveuserManager.html';
        
        // get all groups
        require_once SGL_ENT_DIR . '/Liveuser_groups.php';
        $Groups =& new DataObjects_Liveuser_groups();
        $users_groups = $Groups->getGroups();
        
        require_once SGL_ENT_DIR . '/Liveuser_groupusers.php';
        $groupUsers =& new DataObjects_Liveuser_groupusers();
        
        foreach($output->results as $id => $result) {
            $currentGroupUser = $groupUsers->__clone();
            $user_groups = $currentGroupUser->getGroups($result->id);
            $output->results[$id]->groups = '';
            foreach ($user_groups as $user_group) {
                $output->results[$id]->groups .= $users_groups[$user_group].'<br/>';
            }
        }
    }
    
}

?>