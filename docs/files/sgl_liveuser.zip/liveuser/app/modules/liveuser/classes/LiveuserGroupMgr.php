<?php
/* Reminder: always indent with 4 spaces (no tabs). */
// +---------------------------------------------------------------------------+
// | Seagull 0.3                                                               |
// +---------------------------------------------------------------------------+
// | LiveuserGroupMgr.php                                                      |
// +---------------------------------------------------------------------------+
// | Copyright (C) 2004 Radek Maciaszek                                        |
// |                                                                           |
// | Author: Radek Maciaszek <chief@php.net>                                   |
// +---------------------------------------------------------------------------+
// |                                                                           |
// | This library is free software; you can redistribute it and/or             |
// | modify it under the terms of the GNU Library General Public               |
// | License as published by the Free Software Foundation; either              |
// | version 2 of the License, or (at your option) any later version.          |
// |                                                                           |
// | This library is distributed in the hope that it will be useful,           |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of            |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU         |
// | Library General Public License for more details.                          |
// |                                                                           |
// | You should have received a copy of the GNU Library General Public         |
// | License along with this library; if not, write to the Free                |
// | Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA |
// |                                                                           |
// +---------------------------------------------------------------------------+
//

require_once SGL_CORE_DIR . '/Util.php';
require_once SGL_CORE_DIR . '/Manager.php';
require_once 'DB/Pager.php';

require_once SGL_ENT_DIR . '/Liveuser_groups.php';
require_once SGL_ENT_DIR . '/Liveuser_grouprights.php';
require_once SGL_ENT_DIR . '/Liveuser_rights.php';

/**
 * add to group flag
 */
define('SGL_GROUP_ADD',     1);

/**
 * remove from group flag
 */
define('SGL_GROUP_REMOVE',  2);

/**
 * GroupMgr class, for managing Group objects.
 *
 * @package User
 * @author  Demian Turner <demian@phpkitchen.com>
 * @copyright Demian Turner 2003
 * @version 0.3
 * @since   PHP 4.0
 * @todo    move methods out of process()
 */
class LiveuserGroupMgr extends Manager
{
    //  by default, sort results on group id
    var $sortBy = 'group_id';
    var $module = 'liveuser';

    /**
     * Constructor.
     *
     * @access  public
     * @return  void
     */
    function LiveuserGroupMgr()
    {
        Base::logMessage(__CLASS__ . '::' . __FUNCTION__ ,
            null, null, PEAR_LOG_DEBUG);
            
        parent::Manager();
            
        $this->pageTitle    = 'Group Manager';
        $this->template     = 'liveuserGroupManager.html';
        
        $this->allowedActions = array('edit', 'update', 'delete', 'add', 'insert', 'list');
    }

    function validate($req, $input)
    {
        Base::logMessage(__CLASS__ . '::' . __FUNCTION__ ,
            null, null, PEAR_LOG_DEBUG);
        //  if user doesn't have access, kick out
        if (!Session::checkRight(SGL_RIGHT_ADMIN)) {
            Output::msgSet('insufficient rights');
            Response::redirect('index.php');
        }
        $this->validated        = true;
        $input->error           = array();
        $input->submit          = $req->get('submitted');
        $input->pageTitle       = $this->pageTitle;
        $input->template        = $this->template;
        $input->action          = $req->get('action') ? $req->get('action') : 'list';
        $input->from            = ($req->get('frmFrom')) ? $req->get('frmFrom'):0;
        $input->sortBy          = $req->get('frmSortBy');
        $input->sortOrder       = $this->getSortOrder($req->get('frmSortOrder'));
        $input->groupID         = $req->get('frmGroupID');
        $input->group           = (object) $req->get('group');
        $input->right           = $req->get('right');
        $input->aDelete         = $req->get('frmDelete');
        $input->usersToAdd      = $req->get('AddfrmGroupUsers');
        $input->usersToRemove   = $req->get('RemovefrmGroupUsers');

        //  check for blank field in 'add group'
        if ($input->submit != '') {
            $aErrors = array();
            if ($input->group->group_define_name == '') {
                $aErrors['group_define_name'] = Output::translate('You must enter a group name', 'user');
                $this->validated = false;
            }
            //  if submitted and there are errors
            if (is_array($aErrors) && count($aErrors)) {
                Output::msgSet('Please fill in the indicated fields');
                $input->error = $aErrors;
                $input->template = 'groupLiveUserManager.html';
                $input->rights = $this->_getRights();
            }
        }
        return $input;
    }

    function process($input, $output)
    {
        Base::logMessage(__CLASS__ . '::' . __FUNCTION__ ,
            null, null, PEAR_LOG_DEBUG);

        //  send new sort order, sort by to output
        $output->sortOrder = $input->sortOrder;
        $output->sortBy = $input->sortBy;
        
        $methodName = '_' . $input->action;
        if (in_array($input->action, $this->allowedActions) && method_exists($this, $methodName)) {
            $ret = $this->$methodName($input, $output);
            Base::inherit($ret, $output);
        } else {
            Base::raiseError('The specified method, ' . $methodName . 
                ' does not exist', SGL_ERROR_NOMETHOD, PEAR_ERROR_DIE);
        }
        return $output;
    }

    function display($output)
    {
        Base::logMessage(__CLASS__ . '::' . __FUNCTION__ ,
            null, null, PEAR_LOG_DEBUG);
        return $output;
    }

    function _edit($input)
    {
        Base::logMessage(__CLASS__ . '::' . __FUNCTION__ ,
            null, null, PEAR_LOG_DEBUG);
        $output->template = 'groupLiveUserManager.html';
        $output->edit = true;
        $group = & new DataObjects_Liveuser_groups();
        $group->get($input->groupID);
        $output->group =& $group;
        $output->action = 'update';
        $output->pageTitle = Output::translate($this->pageTitle . ' :: Edit', 'user');
        $output->rights = $this->_getRights($input->groupID);
        return $output;
    }

    function _checkGroupRights($group_id = null, &$rights)
    {
        $group_rights =& new DataObjects_Liveuser_grouprights();
        if($group_id !== null) {
            $group_rights->group_id = $group_id;
        }
        $group_rights->find();
        if(!empty($group_rights->N)) {
            while($group_rights->fetch()) {
                $rights[$group_rights->right_id]->checked = 'checked';
            }
        }
    }
    
    function _getRights($group_id = null)
    {
        $liveuser_rights =& new DataObjects_Liveuser_rights();
        //$liveuser_rights->orderBy('right_define_name');
        if($group_id !== null) {
            $liveuser_rights->group_id = $group_id;
        }
        $liveuser_rights->orderBy('right_id');
        $liveuser_rights->find();
        $rights = null;
        if(!empty($liveuser_rights->N)) {
            while($liveuser_rights->fetch()) {
                $rights[$liveuser_rights->right_id]->name = $liveuser_rights->right_define_name;
                $rights[$liveuser_rights->right_id]->checked = '';
            }
        }
        if($group_id !== null) {
            $this->_checkGroupRights($group_id, $rights);
        }
        return $rights;
    }
    
    function _update($input)
    {
        Base::logMessage(__CLASS__ . '::' . __FUNCTION__ ,
            null, null, PEAR_LOG_DEBUG);
        $group =& new DataObjects_Liveuser_groups();
        $group->get($input->groupID);
        $original = $group->__clone();
        $group->setFrom($input->group);
        $group->description = Util::checkWords($group->description);
        //DB_DataObject::debugLevel(4);
        $ret_update = $group->update($original);
        $this->_checkGroupRights($input->groupID, $rights = array());
        $group_rights =& new DataObjects_Liveuser_grouprights();
        // delete removed rights
        foreach ($rights as $right_id => $val) {
            if(!isset($input->right[$right_id])) {
                $group_right = $group_rights->__clone();
                $group_right->group_id = $input->groupID;
                $group_right->right_id = $right_id;
                $group_right->delete();
                unset($group_right);
            } else {
                unset($input->right[$right_id]);
            }
        }
        // insert new
        if(!empty($input->right)) {
            foreach ($input->right as $right_id => $val) {
                $group_right = $group_rights->__clone();
                $group_right->group_id = $input->groupID;
                $group_right->right_id = $right_id;
                $group_right->right_level = 1;
                $group_right->insert();
            }
        }
        Output::msgSet('The group has successfully been updated');
        Response::redirect('liveuserGroupMgr.php', array('action'=> 'edit', 'frmGroupID' => $input->groupID));
    }

    function _delete($input)
    {
        Base::logMessage(__CLASS__ . '::' . __FUNCTION__ ,
            null, null, PEAR_LOG_DEBUG);
        foreach ($input->aDelete as $index => $groupID) {
            $group = & new DataObjects_Liveuser_groups();
            $group->get($groupID);
            $group->delete();
            unset($group);
        }
        //  redirect on success
        Output::msgSet('The selected group(s) have successfully been deleted');
        Response::redirect('liveuserGroupMgr.php', array('action'=> 'list'));
    }

    function &_add(&$input, &$output)
    {
        Base::logMessage(__CLASS__ . '::' . __FUNCTION__ ,
            null, null, PEAR_LOG_DEBUG);
        $output->template = 'groupLiveUserManager.html';
        $output->action = 'insert';
        $output->add = true;
        $output->pageTitle = Output::translate($this->pageTitle . ' :: Edit', 'user');
        $output->rights = $this->_getRights();
        return $output;
    }

    function _insert($input)
    {
        Base::logMessage(__CLASS__ . '::' . __FUNCTION__ ,
            null, null, PEAR_LOG_DEBUG);
        $newGroup = & new DataObjects_Liveuser_groups();
        $newGroup->setFrom($input->group);
        $dbh = $newGroup->getDatabaseConnection();
        $group_id = $newGroup->group_id = $dbh->nextId('liveuser_groups');
        $newGroup->is_active = 'Y';
        $newGroup->owner_group_id = 0;
        $newGroup->owner_perm_user_id = 1;
        $ret = $newGroup->insert();
        
        // add rights
        if($ret && !PEAR::isError($ret)) {
            $group_rights =& new DataObjects_Liveuser_grouprights();
            if(!empty($input->right)) {
                foreach ($input->right as $right_id => $val) {
                    $group_right = $group_rights->__clone();
                    $group_right->group_id = $group_id;
                    $group_right->right_id = $right_id;
                    $group_right->right_level = 1;
                    $group_right->insert();
                }
            }
        }
        Output::msgSet('Group was added.');
        Response::redirect('liveuserGroupMgr.php', array('action'=> 'list'));
    }

    function _list($input)
    {
        Base::logMessage(__CLASS__ . '::' . __FUNCTION__ ,
            null, null, PEAR_LOG_DEBUG);
        $conf = & $GLOBALS['_SGL']['CONF'];
        $groupList = & new DataObjects_Liveuser_groups();
        $totalNumRows = $groupList->count();
        $limit = $conf['site']['resPerPage'];
        if(empty($input->sortBy)) {
            $input->sortBy = 'group_define_name';
        }
        $groupList->orderBy($input->sortBy . ' ' . $input->sortOrder);
        $groupList->limit($input->from, $limit);
        //  execute query
        $result = $groupList->find();
        $aGroups = array();
        if ($result > 0) {
            while ($groupList->fetch()) {
                $aGroups[] = $groupList->__clone();
            }
            //  don't show pager if less than a pagefull
            if ($totalNumRows <= $limit) {
                $output->pager = false;
            } else {
                $data = DB_Pager::getData($input->from, $limit, $totalNumRows);
                $output->pager = (object)$data;
            }
        }
        $output->groups = $aGroups;
        $output->pageTitle = Output::translate($this->pageTitle . ' :: Browse', 'user');
        return $output;
    }

    /**
     * Returns assoc array of all users per given group.
     *
     * @access  public
     * @param   int     $gid            id of target group
     * @return  array   $aGroupUsers    array of users returned
     * @see     retrieveAllOthers()
     */
    function retrieveAllUsersPerGroup($gid)
    {
        Base::logMessage(__CLASS__ . '::' . __FUNCTION__ ,
            null, null, PEAR_LOG_DEBUG);
        $conf = & $GLOBALS['_SGL']['CONF'];
        $query = "
            SELECT  id, username
            FROM    " . $conf['table']['user'] . "
            WHERE   gid = $gid
                    ";
        $dbh = & Base::DB();
        $aGroupUsers = $dbh->getAssoc($query);
        return $aGroupUsers;
    }

    /**
     * Like a 'difference' operation, returns the balance of retrieveAllUsersPerGroup
     *
     * returns an assoc array of all users who are not in retrieveAllUsersPerGroup()
     * build WHERE clause of group members to exclude
     * only create NOT IN clause if group is non-empty
     *
     * @access  public
     * @param   array   $aGroupMembers  hash of members to exclude
     * @return  array   $aAllUsers      array of users returned
     * @see     retrieveAllUsersPerGroup()
     */
    function retrieveAllOthers($aGroupMembers)
    {
        Base::logMessage(__CLASS__ . '::' . __FUNCTION__ ,
            null, null, PEAR_LOG_DEBUG);
        $conf = & $GLOBALS['_SGL']['CONF'];
        if (count($aGroupMembers) > 0) {
            $whereClause = '';
            foreach ($aGroupMembers as $key => $value) {
                $whereClause .= " $key NOT IN (id) AND ";
            }
            $whereClause = substr($whereClause, 0, -4);
        }
        $query = "
            SELECT  id, username
            FROM    " . $conf['table']['user'] . "
            WHERE   gid <> " . SGL_ADMIN;
        if (count($aGroupMembers) > 0)
            $query .= " AND $whereClause";
        $dbh = & Base::DB();
        $aAllUsers = $dbh->getAssoc($query);
        return $aAllUsers;
    }

    /**
     * Returns an assoc array of all groups.
     *
     * @access  public
     * @param   boolean $bExcludeAdmin  whether admin should be excluded
     * @return  array   $aAllGroups     array of groups returned
     */
    function retrieveAllGroups($bExcludeAdmin = false)
    {
        Base::logMessage(__CLASS__ . '::' . __FUNCTION__ ,
            null, null, PEAR_LOG_DEBUG);
        $conf = & $GLOBALS['_SGL']['CONF'];
        $dbh = & Base::DB();
        $whereClause = ($bExcludeAdmin)? ' AND id <> ' . SGL_ADMIN : '';
        //  exclude -1 as well which is 'unassigned' group
        $query = "
            SELECT id, name
            FROM    " . $conf['table']['userGroup'] . "
            WHERE id <> " . SGL_UNASSIGNED . 
            $whereClause;
        $aAllGroups = $dbh->getAssoc($query);
        return $aAllGroups;
    }

    /**
     * Returns a string of all emails per given group.
     *
     * @access  public
     * @param   int     $gid            id of target group
     * @return  string  $emailList      groups's emails
     */
    function getEmailsByGroup($gid)
    {
        Base::logMessage(__CLASS__ . '::' . __FUNCTION__ ,
            null, null, PEAR_LOG_DEBUG);
        $conf = & $GLOBALS['_SGL']['CONF'];
        $dbh = & Base::DB();
        $query = "
            SELECT  id, email
            FROM    " . $conf['table']['user'] . "
            WHERE   gid = $gid
                ";
        $emailList = implode(';', $dbh->getAssoc($query));
        return $emailList;
    }
}
?>