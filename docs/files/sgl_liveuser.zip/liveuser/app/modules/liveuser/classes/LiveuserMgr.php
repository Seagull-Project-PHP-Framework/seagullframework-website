<?php                             
/* Reminder: always indent with 4 spaces (no tabs). */
// +---------------------------------------------------------------------------+
// | Seagull 0.3                                                               |
// +---------------------------------------------------------------------------+
// | LiveuserMgr.php                                                           |
// +---------------------------------------------------------------------------+
// | Copyright (C) 2004 Radek Maciaszek                                        |
// |                                                                           |
// | Author: Radek Maciaszek <chief@php.net>                                   |
// +---------------------------------------------------------------------------+
// |                                                                           |
// | This library is free software; you can redistribute it and/or             |
// | modify it under the terms of the GNU Library General Public               |
// | License as published by the Free Software Foundation; either              |
// | version 2 of the License, or (at your option) any later version.          |
// |                                                                           |
// | This library is distributed in the hope that it will be useful,           |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of            |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU         |
// | Library General Public License for more details.                          |
// |                                                                           |
// | You should have received a copy of the GNU Library General Public         |
// | License along with this library; if not, write to the Free                |
// | Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA |
// |                                                                           |
// +---------------------------------------------------------------------------+
//

require_once SGL_CORE_DIR . '/Manager.php';
require_once SGL_ENT_DIR . '/Usr.php';
require_once 'Validate.php';

require_once SGL_ENT_DIR . '/Liveuser_groups.php';
require_once SGL_ENT_DIR . '/Liveuser_groupusers.php';

/**
 * Manages (live)User objects.
 *
 * @package liveuser
 * @author  Radek Maciaszek <chief@php.net>
 * @version 0.1
 */
class LiveuserMgr extends Manager
{
    var $module = 'liveuser';
    var $sortBy = 'id';
    
    function LiveuserMgr()
    {
        Base::logMessage(__CLASS__ . '::' . __FUNCTION__ ,
            null, null, PEAR_LOG_DEBUG);
        
        $this->pageTitle    = 'User Manager';
        $this->allowedActions = array('editGroups', 'updateGroups');
    }

    function &validate(&$req, &$input)
    {
        Base::logMessage(__CLASS__ . '::' . __FUNCTION__ ,
            null, null, PEAR_LOG_DEBUG);
            
        $this->validated = true;
        
        //  if user doesn't have access, kick out
        if (!Session::checkRight(SGL_RIGHT_MANAGE_USERS)) {
            Output::msgSet('insufficient rights');
            Response::redirect('index.php');
        }
        parent::validate($req, $input);
        $input->action = $req->get('action');
        $input->userID = $req->get('frmUserID');
        
        $input->group = $req->get('group');
        $input->groupID = $req->get('groupID');
        
        return $input;
    }

    function process(&$input, &$output)
    {
        Base::logMessage(__CLASS__ . '::' . __FUNCTION__ ,
            null, null, PEAR_LOG_DEBUG);

        //  invoke method specified by action parameter
        $methodName = '_' . $input->action;
        if (in_array($input->action, $this->allowedActions) && method_exists($this, $methodName)) {
            $ret = $this->$methodName($input, $output);
            Base::inherit($ret, $output);
        } else {
            Base::raiseError('The specified method, ' . $methodName . 
                ' does not exist', SGL_ERROR_NOMETHOD, PEAR_ERROR_DIE);
        }
       return $output;
    }

    function display(&$output)
    {
        Base::logMessage(__CLASS__ . '::' . __FUNCTION__ ,
            null, null, PEAR_LOG_DEBUG);
        
        parent::display($output);
        return $output;
    }

    function _editGroups(&$input, &$output)
    {
        Base::logMessage(__CLASS__ . '::' . __FUNCTION__ ,
            null, null, PEAR_LOG_DEBUG);
        $output->pageTitle = $this->pageTitle . ' :: Edit';
        $output->template = 'userEditGroups.html';
        $output->action = 'updateGroups';
        $oUser = & new DataObjects_Usr();
        $oUser->get($input->userID);
        $output->user = $oUser;
        $output->groups = $this->_getGroups($input->userID);
        
        return $output;
    }

    /**
     * Check proper groups as checked for user
     *
     * @param integer $user_id
     * @param array $groups (format: $group_id => array($name, $checked))
     */
    function _checkGroups($user_id, &$groups)
    {
        $group_users =& new DataObjects_Liveuser_groupusers();
        $group_users->perm_user_id = $user_id;
        $group_users->find();
        if(!empty($group_users->N)) {
            while($group_users->fetch()) {
                $groups[$group_users->group_id]->checked = 'checked';
            }
        }
    }
    
    /**
     * Return all available grups for user ans also check prope groups as checked
     * for user with id = $user_id
     *
     * @return array format: $group_id => array($name, $checked)
     */
    function _getGroups($user_id)
    {        
        $liveuser_groups =& new DataObjects_Liveuser_groups();
        $liveuser_groups->find();
        $groups = null;
        if(!empty($liveuser_groups->N)) {
            while($liveuser_groups->fetch()) {
                $groups[$liveuser_groups->group_id]->name = $liveuser_groups->group_define_name;
                $groups[$liveuser_groups->group_id]->checked = '';
            }
        }
        $this->_checkGroups($user_id, $groups);
        return $groups;
    }
    
    function _updateGroups($input)
    {
        Base::logMessage(__CLASS__ . '::' . __FUNCTION__ ,
            null, null, PEAR_LOG_DEBUG);
        
        // read already saved groups into $groups
        $this->_checkGroups($input->userID, $groups = array());
        
        $group_users =& new DataObjects_Liveuser_groupusers();
        
        // del removed groups
        foreach ($groups as $group_id => $val) {
            if(!isset($input->group[$group_id])) {
                $group = $group_users->__clone();
                $group->perm_user_id = $input->userID;
                $group->group_id = $group_id;
                $group->delete();
                unset($group);
            } else {
                unset($input->group[$group_id]);
            }
        }
        // add as new
        if(!empty($input->group)) {
            foreach ($input->group as $group_id => $val) {
                $group = $group_users->__clone();
                $group->perm_user_id = $input->userID;
                $group->group_id = $group_id;
                $group->insert();
                unset($group);
            }
        }
        Output::msgSet('details successfully updated');
        
        Response::redirect('liveuserMgr.php', array('action'=> 'editGroups', 'frmUserID' => $input->userID));
    }
}

?>