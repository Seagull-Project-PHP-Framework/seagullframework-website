<?php
    $words = array(
        'add group' => 'dodaj grup�',
        'manage users' => 'zarz�dzaj u�ytkownikami',
        'Select' => 'Wybierz',
        'Group ID' => 'ID',
        'Group Name' => 'Nazwa',
        'delete' => 'kasuj',
        'Group' => 'Grupa',
        'Group was added.' => 'Grupa zosta�a dodana',
        'The group has successfully been updated' => 'Dane grupy zosta�y zapisane',
        'The selected group(s) have successfully been deleted' => 'Wybrane grupy zosta�y usuni�te',
    );
?>