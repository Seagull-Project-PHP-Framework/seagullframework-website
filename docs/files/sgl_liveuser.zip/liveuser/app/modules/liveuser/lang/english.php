<?php
    $words = array(
        'add group' => 'create new group',
        'manage users' => 'manage users',
        'Select' => 'Select',
        'Group ID' => 'Group ID',
        'Group Name' => 'Group Name',
        'delete' => 'delete',
        'Group' => 'Group',
        'Group was added.' => 'Group was added.',
        'The group has successfully been updated' => 'The group has successfully been updated',
        'The selected group(s) have successfully been deleted' => 'The selected group(s) have successfully been deleted',
    );
?>