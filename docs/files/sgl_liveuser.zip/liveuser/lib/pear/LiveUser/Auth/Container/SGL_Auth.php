<?php
// LiveUser: A framework for authentication and authorization in PHP applications
// Copyright (C) 2002-2003 Markus Wolff
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

/**
 * SGL_Auth container for Authentication
 *
 * @package  LiveUser
 * @category authentication
 */

/**
 * Require parent class definition and Seagull::Session class.
 */
require_once 'LiveUser/Auth/Common.php';
require_once SGL_CORE_DIR . '/Base.php';

/**
 * Class LiveUser_Auth_Container_PEAR_Auth
 *
 * Description:
 * This is a Seagull::Session backend driver for the LiveUser class.
 *
 * @author  Radek Maciaszek <chief@php.net>
 * @version $Id: SGL_Auth.php,v 1.1 2004/01/18 19:28:40 chief Exp $
 * @package LiveUser
 * @category authentication
 */
class LiveUser_Auth_Container_SGL_Auth extends LiveUser_Auth_Common
{
    /**
     * Contains the Seagull::sessUser object.
     *
     * @var object
     */
    var $user = null;

    /**
     * LiveUser_Auth_Container_SGL_Auth::LiveUser_Auth_Container_SGL_Auth()
     *
     * Class constructor.
     *
     * @param  mixed
     */
    function &LiveUser_Auth_Container_SGL_Auth(&$connectOptions)
    {
        $this->user =& Session::singletonUsr($init = false);
    }

    /**
     * LiveUser_Auth_Container_SGL_Auth::unfreeze()
     *
     * @param mixed $connectOptions
     * @access public
     */
    function unfreeze(&$connectOptions)
    {
        $this->user =& Session::singletonUsr($init = false);
    }

    /**
     * LiveUser_Auth_Container_SGL_Auth::freeze()
     *
     * @access public
     */
    function freeze()
    {
        return true;
    }

    /**
     * LiveUser_Auth_Container_SGL_Auth::readUserData()
     *
     * @return boolean
     */
    function readUserData()
    {
        $success = false;

        // If a user was found, read data into class variables and set
        // return value to true
        if (is_object($this->user) && is_a($this->user, 'DataObjects_Usr')) {
            $this->handle       = $this->user->username;
            $this->passwd       = $this->encryptPW($this->user->passwd);
            $this->isActive     = $this->user->is_acct_active;
            $this->authUserId   = $this->user->id;
            $this->lastLogin    = '';

            $success = true;
        }
        return $success;
    }

    /**
     * LiveUser_Auth_Container_SGL_Auth::updateUserData()
     *
     * @return boolean
     */
    function updateUserData()
    {
        return true;
    }
    
    function login()
    {
        $this->loggedIn = true;
        $this->authUserId = Session::getUid();
        return true;
    }

}
?>