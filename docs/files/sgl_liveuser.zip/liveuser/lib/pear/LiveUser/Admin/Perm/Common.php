<?php
// LiveUser: A framework for authentication and authorization in PHP applications
// Copyright (C) 2002-2003 Markus Wolff
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

/**
 * Base class for administration of permissions
 *
 * @package  LiveUser
 */

/**
 * Require permission handling common class
 *
 * used to get the constants defined there. This class is small, being
 * mostly abstract so the performance impact is very light.
 */
require_once 'LiveUser/Perm/Common.php';

/**#@+
 * Section types
 *
 * @var integer
 */
define('LIVEUSER_SECTION_APPLICATION',  1);
define('LIVEUSER_SECTION_AREA',         2);
define('LIVEUSER_SECTION_GROUP',        3);
define('LIVEUSER_SECTION_LANGUAGE',     4);
define('LIVEUSER_SECTION_RIGHT',        5);
/**#@-*/

/**
 * This class provides a set of functions for implementing a user
 * permission management system on live websites. All authorisation
 * backends/containers must be extensions of this base class.
 *
 * @author  Markus Wolff <wolff@21st.de>
 * @author  Bjoern Kraus <krausbn@php.net>
 * @version $Id: Common.php,v 1.1 2004/01/18 19:27:35 chief Exp $
 * @package LiveUser
 */
class LiveUser_Admin_Perm_Common
{
    /**
     * Indicates if backend module initialized correctly. If yes,
     * TRUE, if not false. Backend module won't initialize if the
     * init value (usually an object or resource handle that
     * identifies the backend to be used) is not of the required
     * type.
     *
     * @var    boolean
     * @access private
     */
    var $init_ok = false;

    /**
     * Table prefix 
     *
     * @access public
     * @var    string
     */
    var $prefix = 'liveuser_';
    
    /**
     * Associative array of all available languages
     * (short name (i.e. "DE", "EN"...) as key, database id AS value)
     *
     * @access private
     * @var    array
     */
    var $_langs = array();

    /**
     * Current language (short name (i.e. "DE", "EN"...) being used
     *
     * @access private
     * @var    string
     */
    var $_language = '';

    /**
     * Class constructor. Feel free to override in backend subclasses.
     *
     * @access protected
     */
    function LiveUser_Admin_Perm_Common()
    {
        // I do nothing here, override me plenty ;-)
    }

    /**
     * Function returns the inquired value if it exists in the class.
     *
     * @param  string   Name of the property to be returned.
     * @return mixed    NULL, a value or an array.
     */
    function getProperty($what)
    {
        $that = null;
        if (isset($this->$what)) {
            $that = $this->$what;
        }
        return $that;
    }

    /**
     * Adds a new user to Perm.
     *
     * @access  public
     * @param   string   $authId    Auth user ID of the user that should be added.
     * @param   int      $type      User type (constants defined in Perm/Common.php) (optional).
     * @param   mixed    $permId    If specificed no new ID will be automatically generated instead
     * @return mixed   string (perm_user_id) or PEAR Error object
     */
    function addUser($authId, $type = LIVEUSER_USER_TYPE_ID, $permId = null)
    {
        return PEAR::raiseError(null, LIVEUSER_NOT_SUPPORTED, null, E_USER_WARNING,
            'Method not supported by this container', 'LiveUser', true);
    }

    /**
     * Removes an existing user from Perm.
     *
     * @access  public
     * @param   string   Auth user ID of the user that should be removed.
     * @return  mixed    True on success, error object if not.
     */
    function removeUser($authId)
    {
        return PEAR::raiseError(null, LIVEUSER_NOT_SUPPORTED, null, E_USER_WARNING,
            'Method not supported by this container', 'LiveUser', true);
    }

    /**
     * Adds rights for a single user.
     *
     * @access  public
     * @param   string  Auth user ID.
     * @param   array   Array of right IDs to add.
     * @return  mixed   True on success, error object if not.
     */
    function addRights($authId, $rights)
    {
        return PEAR::raiseError(null, LIVEUSER_NOT_SUPPORTED, null, E_USER_WARNING,
            'Method not supported by this container', 'LiveUser', true);
    }

    /**
     * Removes rights for a single user.
     *
     * @access  public
     * @param   string  Auth user ID.
     * @param   array   Array of right IDs to remove or empty to
     *                           remove all.
     * @return  mixed   True on success, error object if not.
     */
    function removeRights($authId, $rights = null)
    {
        return PEAR::raiseError(null, LIVEUSER_NOT_SUPPORTED, null, E_USER_WARNING,
            'Method not supported by this container', 'LiveUser', true);
    }

    /**
     * Shortcut to delete all existing rights of a user and add the given.
     *
     * @access  public
     * @param   string  Auth user ID.
     * @param   array   Array of right IDs to add.
     * @return  mixed   True or error object if not.
     */
    function updateRights($authId, $rights)
    {
        $this->removeRights($authId);
        $this->addRights($authId, $rights);
        return true;
    }

    /**
     * Gets all perm_user_id, type, container and rights
     *
     * The array will look like this:
     * <code>
     * $userData[0]['perm_user_id'] = 1;
     *             ['type']         = 1;
     *             ['container']    = '';
     *             ['rights'][0]    = 1;
     *             ['rights'][1]    = 4;
     *             ['rights'][2]    = 5;
     * </code>
     *
     * @access  public
     * @param   boolean  If true the rights for each user will be retrieved.
     * @return  mixed    Array with user data or error object.
     */
    function getUsers($withRights = false)
    {
        return PEAR::raiseError(null, LIVEUSER_NOT_SUPPORTED, null, E_USER_WARNING,
            'Method not supported by this container', 'LiveUser', true);
    }

    /**
     * Updates user type.
     *
     * @access  public
     * @param   string  Auth user ID.
     * @param   int     User type (constants defined in Perm/Common.php).
     * @return  mixed   True on success, error object if not.
     */
    function setUserType($authId, $type)
    {
        return PEAR::raiseError(null, LIVEUSER_NOT_SUPPORTED, null, E_USER_WARNING,
            'Method not supported by this container', 'LiveUser', true);
    }
}
?>