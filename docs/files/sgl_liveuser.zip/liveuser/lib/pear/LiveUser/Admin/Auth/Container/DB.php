<?php
// LiveUser: A framework for authentication and authorization in PHP applications
// Copyright (C) 2002-2003 Markus Wolff
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

/**
 * DB admin container for maintaining Auth/DB
 *
 *
 * @package  LiveUser
 * @category authentication
 */

/**
 * Require parent class definition and PEAR::DB class.
 */
require_once 'LiveUser/Admin/Auth/Common.php';
require_once 'DB.php';

/**
 * Class LiveUser_Admin_Auth_DB
 *
 * Simple DB-based complexity driver for LiveUser.
 *
 * Description:
 * This admin class provides the following functionalities
 * - adding users
 * - removing users
 * - update user data (auth related: username, pwd, active)
 * - adding rights
 * - removing rights
 * - get all users
 *
 * ATTENTION:
 * This class is only experimental. API may change. Use it at your own risk.
 *
 * @author  Bj?rn Kraus <krausbn@php.net>
 * @version $Id: DB.php,v 1.1 2004/01/18 19:26:03 chief Exp $
 * @package LiveUser
 * @category authentication
 */
class LiveUser_Admin_Auth_Container_DB extends LiveUser_Admin_Auth_Common
{
    /**
     * The DSN that was used to connect to the database (set only if no
     * existing connection object has been reused).
     *
     * @access private
     * @var    string
     */
    var $dsn = null;

    /**
     * PEAR::DB connection object.
     *
     * @access private
     * @var    object
     */
    var $dbc = null;

    /**
     * Auth table
     * Table where the auth data is stored.
     *
     * @access public
     * @var    string
     */
    var $authTable = 'liveuser_users';

    /**
     * Columns of the auth table.
     * Associative array with the names of the auth table columns.
     * The 'user_id', 'handle' and 'passwd' fields have to be set.
     * 'lastlogin' and 'is_active' are optional.
     * It doesn't make sense to set only one of the time columns without the
     * other.
     *
     * @access public
     * @var    array
     */
    var $authTableCols = array('user_id'    => 'auth_user_id',
                               'handle'    => 'handle',
                               'passwd'  => 'passwd',
                               'lastlogin' => 'lastlogin',
                               'is_active'  => 'is_active');

    /**
     * Constructor
     *
     * The second parameters expects an array containing the parameters
     * for the given container.
     *
     * Say you have a conf array like that
     * <code>
     * 'authContainers' => array(
     *     array(
     *         'type'          => 'DB',
     *         'loginTimeout'  => 0,
     *         'expireTime'    => 3600,
     *         'idleTime'      => 1800,
     *         'allowDuplicateHandles' => 0,
     *         'authTable'     => 'users',
     *         'authTableCols' => array(
     *             'user_id'       => 'auth_user_id',
     *             'handle'       => 'handle',
     *             'passwd'     => 'passwd',
     *             'lastlogin'    => 'lastlogin',
     *             'is_active'     => 'is_active'
     *         )
     *     )
     * ),
     * </code>
     *
     * This class expects only the array containing
     * configuration options of the auth container you wish
     * to administrate. This is done in case you have several
     * DB based auth containers.
     *
     * See PEAR::DB documentation for DSN specifications.
     *
     * <code>
     * $conf =
     *     array(
     *         'type'          => 'DB',
     *         'loginTimeout'  => 0,
     *         'expireTime'    => 3600,
     *         'idleTime'      => 1800,
     *         'passwordEncryptionMode' => 'MD5',
     *         'allowDuplicateHandles' => 0,
     *         'authTable'     => 'users',
     *         'dsn'           => 'type://user:pass@host/database',
     *         'authTableCols' => array(
     *             'user_id'    => 'auth_user_id',
     *             'handle'     => 'handle',
     *             'passwd'     => 'passwd',
     *             'lastlogin'  => 'lastlogin',
     *             'is_active'  => 'is_active'
     *         )
     *     );
     *
     * $obj = new LiveUser_Admin_Auth_Container_DB($conf);
     * </code>
     *
     * @access protected
     * @param  array  full liveuser conf array
     * @return void
     */
    function LiveUser_Admin_Auth_Container_DB(&$connectOptions)
    {
        if (is_array($connectOptions)) {
            foreach ($connectOptions as $key => $value) {
                if (isset($this->$key)) {
                    $this->$key = $value;
                }
            }
            if (isset($connectOptions['connection'])  &&
                    DB::isConnection($connectOptions['connection'])
            ) {
                $this->dbc     = &$connectOptions['connection'];
                $this->init_ok = true;
            } elseif (isset($connectOptions['dsn'])) {
                $this->dsn = $connectOptions['dsn'];
                $this->dbc =& DB::connect($connectOptions['dsn']);

                if (!DB::isError($this->dbc)) {
                    $this->init_ok = true;
                }
            }
        }
    }

    /**
     * Adds a new user to Auth/DB.
     *
     * @access  public
     * @param   string  Handle (username).
     * @param   string  Password.
     * @param   boolean Sets the user active (1) or not (0).
     * @param   boolean Sets the user active (1) or not (0).
     * @param   mixed   If specificed no new ID will be automatically generated instead
     * @return  mixed   Users auth ID on success, DB error if not, false if not initialized
     */
    function addUser($handle, $password = '', $active = true, $authId = null)
    {
        if (!$this->init_ok) {
            return false;
        }

        // Generate new user ID
        if (is_null($authId)) {
            $authId = $this->dbc->nextId($this->authTable);
        }

        if ($active == true) {
            $active = 'Y';
        } else {
            $active = 'N';
        }

        // Register new user in auth table
        $query = '
            INSERT INTO
                ' . $this->authTable . '
                (
                ' . $this->authTableCols['user_id'] . ',
                ' . $this->authTableCols['handle'] . ',
                ' . $this->authTableCols['passwd'] . ',
                ' . $this->authTableCols['is_active'] . '
                )
            VALUES
                (
                ' . $this->dbc->quote($authId) . ',
                ' . $this->dbc->quote($handle) . ',
                ' . $this->dbc->quote($this->encryptPW($password)) . ',
                ' . $this->dbc->quote($active) . '
                )';

        $result = $this->dbc->query($query);

        if (DB::isError($result)) {
            return $result;
        }

        return $authId;
    } // end func addUser

    /**
     * Removes an existing user from Auth/DB.
     *
     * @access  public
     * @param   string   Auth user ID of the user that should be removed.
     * @return  mixed    True on success, DB error if not.
     */
    function removeUser($authId)
    {
        if (!$this->init_ok) {
            return false;
        }

        // Delete user from auth table (DB/Auth)
        $query = '
            DELETE FROM
                ' . $this->authTable . '
            WHERE
                auth_user_id = '.$this->dbc->quote($authId);

        $result = $this->dbc->query($query);

        if (DB::isError($result)) {
            return $result;
        }

        return true;
    } // end func removeUser

    /**
     * Changes user data in auth table.
     *
     * @access  public
     * @param   string   Auth user ID.
     * @param   string   Handle (username) (optional).
     * @param   string   Password (optional).
     * @param   boolean  Sets the user active (1) or not (0) (optional).
     * @return  mixed    True on success, DB error if not.
     */
    function updateUser($authId, $handle = '', $password = '', $active = null)
    {
        if (!$this->init_ok) {
            return false;
        }

        // Create query.
        $query = '
            UPDATE
                ' . $this->authTable . '
            SET ';

        if (!empty($handle)) {
            $updateValues[] =
                $this->authTableCols['handle'] . '=' . $this->dbc->quote($handle);
        }

        if (!empty($password)) {
            $updateValues[] =
                $this->authTableCols['passwd'] . ' = '
                    . $this->dbc->quote($this->encryptPW($password));
        }

        if (isset($active)) {
            if ($active == true) {
                $active = 'Y';
            } else {
                $active = 'N';
            }
            $updateValues[] =
                $this->authTableCols['is_active'] . ' = ' . $this->dbc->quote($active);
        }

        if (count($updateValues) >= 1) {
            $query .= implode(', ', $updateValues);
        } else {
            return false;
        }

        $query .= ' WHERE
            ' . $this->authTableCols['user_id'] . '=' . $this->dbc->quote($authId);

        $result = $this->dbc->query($query);

        if (DB::isError($result)) {
            return $result;
        }

        return true;
    }

    /**
     * Gets all users with handle, passwd, auth_user_id
     * lastlogin, is_active and individual rights.
     *
     * The array will look like this:
     * <code>
     * $userData[0]['auth_user_id'] = 'wujha433gawefawfwfiuj2ou9823r98h';
     *             ['handle']       = 'myLogin';
     *             ['passwd']       = 'd346gs2gwaeiuhaeiuuweijfjuwaefhj';
     *             ['lastlogin']    = 1254801292; (Unix timestamp)
     *             ['is_active']    = 1; (1 = yes, 0 = no)
     * </code>
     *
     * Filters can be either complex or simple.
     *
     * In their simple form you just need to pass an associative array
     * with key/value, the key will be the table field name and value the value
     * you are searching. It will consider that you want an do to do a
     * field=value comparison, every additinnal filter will be appended with AND
     *
     * The complicated form of filters is to pass an array such as
     *
     * array(
     * array('fieldname' => array('op' => '>', 'value' => 'dummy', 'cond' => ''),
     * array('fieldname' => array('op' => '<', 'value' => 'dummy2', 'cond' => 'OR'),
     * );
     *
     * It can then build relatively complex queries. If you need joins or more
     * complicated queries than that please consider using an alternative
     * solution such as PEAR::DB_DataObject
     *
     * Any aditional field will be returned. The array key will be of the same
     * case it is given.
     *
     * e.g.: getUsers(null, array('myField') will return
     *
     * <code>
     * $userData[0]['auth_user_id'] = 'wujha433gawefawfwfiuj2ou9823r98h';
     *             ['handle']       = 'myLogin';
     *             ['passwd']       = 'd346gs2gwaeiuhaeiuuweijfjuwaefhj';
     *             ['lastlogin']    = 1254801292; (Unix timestamp);
     *             ['is_active']    = 1; (1 = yes, 0 = no);
     *             ['myField']      = 'value';
     * </code>
     *
     * @access  public
     * @param   array   filters to apply to fetched data
     * @param   array   custom fields you want to be returned. If not specified
     *                  the basic set of fields is returned
     * @param   boolean will return an associative array with the auth_user_id
     *                  as the key by using DB::getAssoc() instead of DB::getAll()
     * @return  mixed   Array with user data or DB error.
     */
    function getUsers($filters = array(), $customFields = array(), $reykey = false)
    {
        if (!$this->init_ok) {
            return false;
        }

        $fields = $where ='';

        if (sizeof($customFields) > 0) {
            $fields  = ',';
            $fields .= implode(',', $customFields);
        }

        if (sizeof($filters) > 0) {
            $where = 'WHERE ';
            foreach ($filters as $f => $v) {
                if (is_array($v)) {
                    $where .= $v['cond'] . " $f" . $v['op'] . $this->dbc->quote($v['value']);
                } else {
                    $where .= "$f=$v AND";
                }
            }
            $where = substr($where, 0, -3);
        }

        // First: Get all data from auth table.
        $query = "
            SELECT
                {$this->authTableCols['user_id']}   AS auth_user_id,
                {$this->authTableCols['handle']}    AS handle,
                {$this->authTableCols['passwd']}    AS passwd,
                {$this->authTableCols['lastlogin']} AS lastlogin,
           CASE {$this->authTableCols['is_active']}
           WHEN 'Y' THEN 1
           WHEN 'N' THEN 0 END
                                                    AS is_active
                $fields
            FROM
                {$this->authTable}
            $where";

        if ($reykey) {
            $res = $this->dbc->getAssoc($query, false, array(), DB_FETCHMODE_ASSOC);
        } else {
            $res = $this->dbc->getAll($query, array(), DB_FETCHMODE_ASSOC);
        }
        return $res;
    }
}