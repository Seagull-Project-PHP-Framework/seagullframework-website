<?php
// LiveUser: A framework for authentication and authorization in PHP applications
// Copyright (C) 2002-2003 Markus Wolff
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

/**
 * MDB_Simple admin container for maintaining Perm/MDB_Simple
 *
 *
 * @package  LiveUser
 * @category authentication
 */

/**
 * Require parent class definition and PEAR::MDB class.
 */
require_once 'LiveUser/Admin/Perm/MDB_Common.php';
require_once 'MDB.php';

/**
 * Class LiveUser_Admin_Perm_MDB_Simple
 *
 * Simple MDB-based complexity driver for LiveUser.
 *
 * Description:
 * This admin class provides the following functionalities
 * - adding users
 * - removing users
 * - changing user data (auth related: username, pwd, active)
 * - adding rights
 * - removing rights
 * - get all users
 *
 * ATTENTION:
 * This class is only experimental. API may change. Use it at your own risk.
 *
 * @author  Bj�rn Kraus <krausbn@php.net>
 * @version $Id: MDB_Simple.php,v 1.1 2004/01/18 19:27:06 chief Exp $
 * @package LiveUser
 * @category authentication
 */
class LiveUser_Admin_Perm_Container_MDB_Simple extends LiveUser_Admin_Perm_MDB_Common
{
    /**
     * Constructor
     *
     * The second parameters expects the smae array as you use
     * when instantiating LiveUser::factory()
     *
     * @access protected
     * @param  array  full liveuser conf array
     * @return void
     */
    function LiveUser_Admin_Perm_Container_MDB_Simple(&$connectOptions)
    {
        $this->LiveUser_Admin_Perm_Container_MDB($connectOptions);
    }
}
?>