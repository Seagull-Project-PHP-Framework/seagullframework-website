<?php
// LiveUser: A framework for authentication and authorization in PHP applications
// Copyright (C) 2002-2003 Markus Wolff
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

/**
 * MDB admin container for maintaining Auth/MDB
 *
 * @package  LiveUser
 * @category authentication
 */

/**
 * Require parent class definition and PEAR::MDB class.
 */
require_once 'LiveUser/Admin/Auth/Common.php';
require_once 'MDB.php';

/**
 * Class LiveUser_Admin_Auth_MDB
 *
 * Simple MDB-based complexity driver for LiveUser.
 *
 * Description:
 * This admin class provides the following functionalities
 * - adding users
 * - removing users
 * - update user data (auth related: username, pwd, active)
 * - adding rights
 * - removing rights
 * - get all users
 *
 * ATTENTION:
 * This class is only experimental. API may change. Use it at your own risk.
 *
 * @author  Bj?rn Kraus <krausbn@php.net>
 * @version $Id: MDB.php,v 1.1 2004/01/18 19:26:03 chief Exp $
 * @package LiveUser
 */
class LiveUser_Admin_Auth_Container_MDB extends LiveUser_Admin_Auth_Common
{
    /**
     * The DSN that was used to connect to the database (set only if no
     * existing connection object has been reused).
     *
     * @access private
     * @var    string
     */
    var $dsn = null;

    /**
     * PEAR::MDB connection object.
     *
     * @access private
     * @var    object
     */
    var $dbc = null;

    /**
     * Auth table
     * Table where the auth data is stored.
     *
     * @access public
     * @var    string
     */
    var $authTable = 'liveuser_users';

    /**
     * Columns of the auth table.
     * Associative array with the names of the auth table columns.
     * The 'user_id', 'handle' and 'passwd' fields have to be set.
     * 'lastlogin' and 'is_active' are optional.
     * It doesn't make sense to set only one of the time columns without the
     * other.
     *
     * @access public
     * @var    array
     */
    var $authTableCols = array('user_id'       => array('name' => 'auth_user_id', 'type' => 'text'),
                               'handle'       => array('name' => 'handle', 'type' => 'text'),
                               'passwd'     => array('name' => 'passwd', 'type' => 'text'),
                               'lastlogin'    => array('name' => 'lastlogin', 'type' => 'timestamp'),
                               'is_active'     => array('name' => 'is_active', 'type' => 'boolean'));

    /**
     * Constructor
     *
     * The second parameters expects an array containing the parameters
     * for the given container.
     *
     * Say you have a conf array like that
     * <code>
     * 'authContainers' => array(
     *     array(
     *         'type'          => 'MDB',
     *         'loginTimeout'  => 0,
     *         'expireTime'    => 3600,
     *         'idleTime'      => 1800,
     *         'allowDuplicateHandles' => 0,
     *         'authTable'     => 'users',
     *         'authTableCols' => array(
     *             'user_id'       => 'auth_user_id',
     *             'handle'       => 'handle',
     *             'passwd'     => 'passwd',
     *             'lastlogin'    => 'lastlogin',
     *             'is_active'     => 'is_active'
     *         )
     *     )
     * ),
     * </code>
     *
     * This class expectsonly the array concerning the authcontainer you which
     * to do the administration on. This way if you have several MDB based
     * auth container you can specify which one you are acting on.
     *
     * <code>
     * $dsn = array('dsn' => "type://user:pass@host/database");
     *
     * $conf =
     *     array(
     *         'type'          => 'MDB',
     *         'loginTimeout'  => 0,
     *         'expireTime'    => 3600,
     *         'idleTime'      => 1800,
     *         'allowDuplicateHandles' => 0,
     *         'authTable'     => 'users',
     *         'authTableCols' => array(
     *             'user_id'       => 'auth_user_id',
     *             'handle'       => 'handle',
     *             'passwd'     => 'passwd',
     *             'lastlogin'    => 'lastlogin',
     *             'is_active'     => 'is_active'
     *         )
     *     );
     *
     * $obj = new LiveUser_Admin_Auth_Container_DB($dsn);
     * </code>
     *
     * @access protected
     * @param  mixed  Array or PEAR::MDB object.
     * @param  array  configuration array
     * @return void
     */
    function LiveUser_Admin_Auth_Container_MDB(&$connectOptions)
    {
        if (is_array($connectOptions)) {
            $function = 'connect';
            if (isset($connectOptions['function'])) {
                $function = $connectOptions['function'];
            }
            foreach ($connectOptions as $key => $value) {
                if (isset($this->$key)) {
                    $this->$key = $value;
                }
            }
            $this->dbc = MDB::$function($connectOptions['dsn']);

            if (!MDB::isError($this->dbc)) {
                $this->init_ok = true;
            }
        }
    } // end func LiveUser_Admin_Auth_MDB

    /**
     * Adds a new user to Auth/MDB.
     *
     * @access  public
     * @param   string  Handle (username).
     * @param   string  Password.
     * @param   boolean Sets the user active (1) or not (0).
     * @param   mixed   If specificed no new ID will be automatically generated instead
     * @return  mixed   Users auth ID on success, MDB error if not, false if not initialized
     */
    function addUser($handle, $password = '', $active = true, $authId = null)
    {
        if (!$this->init_ok) {
            return false;
        }

        // Generate new user ID
        if (is_null($authId)) {
            $authId = $this->dbc->nextId($this->authTable);
        }

        // Register new user in auth table
        $query = '
            INSERT INTO
                ' . $this->authTable . '

                (
                ' . $this->authTableCols['user_id']['name'] . ',
                ' . $this->authTableCols['handle']['name'] . ',
                ' . $this->authTableCols['passwd']['name'] . ',
                ' . $this->authTableCols['is_active']['name'] . '
                )

            VALUES
                (
                ' . $this->dbc->getValue($this->authTableCols['user_id']['type'], $authId) . ',
                ' . $this->dbc->getValue($this->authTableCols['handle']['type'], $handle) . ',
                ' . $this->dbc->getValue($this->authTableCols['passwd']['type'], $this->encryptPW($password)) . ',
                ' . $this->dbc->getValue($this->authTableCols['is_active']['type'], $active) . '
                )';

        $result = $this->dbc->query($query);

        if (MDB::isError($result)) {
            return $result;
        }

        return $authId;
    } // end func addUser

    /**
     * Removes an existing user from Auth/MDB.
     *
     * @access  public
     * @param   string   Auth user ID of the user that should be removed.
     * @return  mixed    True on success, MDB error if not.
     */
    function removeUser($authId)
    {
        if (!$this->init_ok) {
            return false;
        }

        // Delete user from auth table (MDB/Auth)
        $query = '
            DELETE FROM
                ' . $this->authTable . '
            WHERE
                auth_user_id = ' . $this->dbc->getValue($this->authTableCols['user_id']['type'], $authId);

        $result = $this->dbc->query($query);

        if (MDB::isError($result)) {
            return $result;
        }

        return true;
    } // end func removeUser

    /**
     * Changes user data in auth table.
     *
     * @access  public
     * @param   string   Auth user ID.
     * @param   string   Handle (username) (optional).
     * @param   string   Password (optional).
     * @param   boolean  Sets the user active (1) or not (0) (optional).
     * @return  mixed    True on success, MDB error if not.
     */
    function updateUser($authId, $handle = '', $password = '', $active = null)
    {
        if (!$this->init_ok) {
            return false;
        }

        // Create query.
        $query = '
            UPDATE
                ' . $this->authTable . '
            SET ';

        if (!empty($handle)) {
            $updateValues[] =
                $this->authTableCols['handle']['name'] . '=' . $this->dbc->getValue($this->authTableCols['handle']['type'], $handle);
        }
        if (!empty($password)) {
            $updateValues[] =
                $this->authTableCols['passwd']['name'] . ' = ' . $this->dbc->getValue($this->authTableCols['passwd']['type'], $this->encryptPW($password));
        }
        if (isset($active)) {
            $updateValues[] =
                $this->authTableCols['is_active']['name'] . ' = ' . $this->dbc->getValue($this->authTableCols['is_active']['type'], $active);
        }

        if (count($updateValues) >= 1) {
            $query .= implode(', ', $updateValues);
        } else {
            return false;
        }

        $query .= ' WHERE
            ' . $this->authTableCols['user_id']['name'] . '=' . $this->dbc->getValue($this->authTableCols['user_id']['type'], $authId);

        $result = $this->dbc->query($query);

        if (MDB::isError($result)) {
            return $result;
        }

        return true;
    }

    /**
     * Gets all users with handle, passwd, auth_user_id
     * lastlogin, is_active and individual rights.
     *
     * The array will look like this:
     * <code>
     * $userData[0]['auth_user_id'] = 'wujha433gawefawfwfiuj2ou9823r98h';
     *             ['handle']       = 'myLogin';
     *             ['passwd']       = 'd346gs2gwaeiuhaeiuuweijfjuwaefhj';
     *             ['lastlogin']    = 1254801292; (Unix timestamp)
     *             ['is_active']    = 1; (1 = yes, 0 = no)
     * </code>
     *
     * Any aditional field will be returned in the same case as it is given.
     * Since MDB abtracts datatypes the passed array is a bit different than
     * the DB one.
     * e.g.:
     * <code>
     * $admin->getUsers(
     *  null,
     *  array(
     *      array('type' => 'fieldtype', 'name' => 'myField'),
     *      array('type' => 'fieldtype', 'name' => 'myField')
     *  );
     * </code>
     *
     *  will return
     *
     * <code>
     * $userData[0]['auth_user_id'] = 'wujha433gawefawfwfiuj2ou9823r98h';
     *             ['handle']       = 'myLogin';
     *             ['passwd']       = 'd346gs2gwaeiuhaeiuuweijfjuwaefhj';
     *             ['lastlogin']    = 1254801292; (Unix timestamp);
     *             ['is_active']    = 1; (1 = yes, 0 = no);
     *             ['myField']      = 'value';
     * </code>
     *
     * @access  public
     * @param   array  filters to apply to fetched data
     * @param   array  custom fields you want to be returned. If not specified
     *                 the basic set of fields is returned
     * @return  mixed  Array with user data or DB error.
     */
    function getUsers($filters = array(), $customFields = array())
    {
        if (!$this->init_ok) {
            return false;
        }

        $fields            = '';
        $customFieldsTypes = array();
        if (sizeof($customFields) > 0) {
            foreach ($customFields as $k => $v) {
                $fields              .= ',' . $v['name'];
                $customFieldsTypes[]  = $v['type'];
            }
        }

        // First: Get all data from auth table.
        $query = '
            SELECT
                ' . $this->authTableCols['user_id']   . ' AS auth_user_id,
                ' . $this->authTableCols['handle']    . ' AS handle,
                ' . $this->authTableCols['passwd']    . ' AS passwd,
                ' . $this->authTableCols['lastlogin'] . ' AS lastlogin,
                ' . $this->authTableCols['is_active'] . ' AS is_active
                ' . $fields . '
            FROM
                ' . $this->authTable;

        $baseFieldsTypes = array('text', 'text', 'text', 'timestamp', 'boolean');
        $types = array_merge($baseFieldsTypes, $customFieldsTypes);

        $userData = $this->dbc->queryAll($query, $types, MDB_FETCHMODE_ASSOC, true);

        if (MDB::isError($userData)) {
            return $userData;
        }

        if (!is_array($userData)) {
            return null;
        }
        return $userData = array_change_key_case($userData);
    }
}
?>