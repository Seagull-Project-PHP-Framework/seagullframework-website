<?php
// LiveUser: A framework for authentication and authorization in PHP applications
// Copyright (C) 2002-2003 Markus Wolff
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

/**
 * Attempt at a unified admin class
 *
 * Simple usage:
 *
 * <code>
 * $conf = array(
 *  'autoInit' => false/true,
 *  'session'  => array(
 *      'name'    => 'liveuser session name',
 *      'varname' => 'liveuser session var name'
 *  ),
 *  'login' => array(
 *      'method'   => 'get or post',
 *      'username' => 'Form input containing user handle',
 *      'password' => 'Form input containing password',
 *      'remember' => '(optional) Form checkbox containing <Remember Me> info',
 *      'function' => '(optional) Function to be called when accessing a page without logging in first',
 *      'force'    => 'Should the user be forced to login'
 *  ),
 *  'logout' => array(
 *      'trigger'  => 'GET or POST var that triggers the logout process',
 *      'redirect' => 'Page path to be redirected to after logout',
 *      'function' => '(optional) Function to be called when accessing a page without logging in first',
 *      'destroy'  => 'Whether to destroy the session on logout'
 *  ),
 * // The cookie options are optional. If they are specified, the Remember Me
 * // feature is activated.
 *  'cookie' => array(
 *      'name'     => 'Name of Remember Me cookie',
 *      'lifetime' => 'Cookie lifetime in days',
 *      'path'     => 'Cookie path',
 *      'domain'   => 'Cookie domain',
 *      'secret'   => 'Secret key used for cookie value encryption'
 *  ),
 *  'authContainers' => array(
 *      'name' => array(
 *            'type' => 'DB',
 *            'connection'    => 'db connection object, use this or dsn',
 *            'dsn'           => 'database dsn, use this or connection',
 *            'loginTimeout'  => 0,
 *            'expireTime'    => 3600,
 *            'idleTime'      => 1800,
 *            'allowDuplicateHandles' => 0,
 *            'authTable'     => 'liveuser_users',
 *            'authTableCols' => array('user_id'   => 'auth_user_id',
 *                                     'handle'    => 'handle',
 *                                     'passwd'    => 'passwd',
 *                                     'lastlogin' => 'lastlogin'
 *            )
 *      )
 *  ),
 *  'permContainer' => array(
 *      'type'       => 'DB_Complex',
 *      'connection' => 'db connection object, use this or dsn',
 *      'dsn'        => 'database dsn, use this or connection',
 *      'prefix'     => 'liveuser_'
 *  )
 *
 * $admin = new LiveUser_Admin($conf, 'FR');
 * $found = $admin->searchUser(3);
 *
 * if ($found) {
 *  var_dump($admin->perm->getRights());
 * }
 * </code>
 *
 * @author  Lukas Smith
 * @author  Arnaud Limbourg
 * @version $Id: Admin.php,v 1.1 2004/01/18 19:27:59 chief Exp $
 * @package LiveUser
 */
class LiveUser_Admin
{
    /**
     * Array containing the auth objects.
     *
     * @access private
     * @var    array
     */
    var $_authContainers = array();

    /**
     * Admin perm object
     *
     * @access public
     * @var    object
     */
    var $perm = null;

    /**
     * Auth admin object
     *
     * @access public
     * @var    object
     */
    var $auth = null;

    /**
     * Configuration array
     *
     * @access private
     * @var    array
     */
     var $_conf = array();

     /**
      * Language to be used
      *
      * @access public
      * @var    string
      */
     var $lang = '';

    /**
     * Constructor
     *
     * @access protected
     * @param  array  liveuser conf array
     * @param  string two letters language code
     * @return void
     */
    function LiveUser_Admin($conf, $lang)
    {
        if (is_array($conf)) {
            $this->_conf = $conf;
        }
        $this->lang = $lang;
    }

    /**
     * creates an instance of an auth object
     *
     * @access private
     * @param  mixed    Name of array containing the configuration.
     * @return object   Returns an object of an auth container
     */
    function &_authFactory($conf)
    {
        $classname = 'LiveUser_Admin_Auth_Container_' . $conf['type'];
        $filename = 'LiveUser/Admin/Auth/Container/' . $conf['type'] . '.php';
        @include_once($filename);
        if (!class_exists($classname)) {
            $this->_error = true;
            $error = PEAR::raiseError(null, LIVEUSER_NOT_SUPPORTED, null, E_USER_WARNING,
                'Missing file: '.$filename, 'LiveUser', true);
            return $error;
        }
        $auth = &new $classname($conf);
        return $auth;
    }

    /**
     * creates an instance of an perm object
     *
     * @access private
     * @param  mixed    Name of array containing the configuration.
     * @return object   Returns an object of a perm container
     */
    function &_permFactory($conf)
    {
        $classname = 'LiveUser_Admin_Perm_Container_' . $conf['type'];
        $filename = 'LiveUser/Admin/Perm/Container/' . $conf['type'] . '.php';
        @include_once($filename);
        if (!class_exists($classname)) {
            $this->_error = true;
            $error = PEAR::raiseError(null, LIVEUSER_NOT_SUPPORTED, null, E_USER_WARNING,
                'Missing file: '.$filename, 'LiveUser', true);
            return $error;
        }
        $perm = &new $classname($conf);
        return $perm;
    }

    /**
     * Tries to find a user in any of the auth container.
     *
     * Upon success it will return true. You can then
     * access the backend container by using the auth
     * and perm properties of this class.
     *
     * e.g.: $admin->perm->updateAuthUserId();
     *
     * @param  mixed   user auth id
     * @return boolean true upon success, false otherwise
     */
    function searchAuthUser($authId)
    {
        foreach ($this->_conf['authContainers'] as $k => $v) {
            if (!isset($this->_authContainers[$k])
                    ||!is_object($this->_authContainers[$k])) {
                $this->_authContainers[$k] = &$this->_authFactory($v);
            }

            $match = $this->_authContainers[$k]->getUsers("where_auth_user_id=$authId");

            if (is_array($match) && sizeof($match) > 0) {
                $this->perm = &$this->_permFactory($this->_conf['permContainer']);
                $this->perm->setCurrentLanguage($this->lang);
                $this->auth = &$this->_authContainers[$k];
                return true;
            }
        }
        return false;
    }
}