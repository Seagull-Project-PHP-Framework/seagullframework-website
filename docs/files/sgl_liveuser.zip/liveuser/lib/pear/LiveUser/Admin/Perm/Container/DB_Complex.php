<?php
// LiveUser: A framework for authentication and authorization in PHP applications
// Copyright (C) 2002-2003 Markus Wolff
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

/**
 * DB_Complex permission administration class
 *
 * @package  LiveUser
 * @category authentication
 */

/**
 * Require the parent class definition
 */
require_once 'LiveUser/Admin/Perm/Container/DB_Medium.php';

/**
 * This is a PEAR::DB admin class for the LiveUser package.
 *
 * It takes care of managing the permission part of the package.
 *
 * A PEAR::DB connection object can be passed to the constructor to reuse an
 * existing connection. Alternatively, a DSN can be passed to open a new one.
 *
 * Requirements:
 * - Files "common.php", "Container/DB_Complex.php" in directory "Perm"
 * - Array of connection options must be passed to the constructor.
 *   Example: array("server" => "localhost", "user" => "root",
 *   "password" => "pwd", "database" => "AllMyPreciousData")
 *
 * @author  Christian Dickmann <dickmann@php.net>
 * @author  Markus Wolff <wolff@21st.de>
 * @author  Matt Scifo <mscifo@php.net>
 * @version $Id: DB_Complex.php,v 1.1 2004/01/18 19:27:06 chief Exp $
 * @package LiveUser
 */
class LiveUser_Admin_Perm_Container_DB_Complex extends LiveUser_Admin_Perm_Container_DB_Medium
{
    /**
     * Constructor
     *
     * @access protected
     * @param  mixed  Array or PEAR::DB object.
     * @param  array  configuration array not used atm
     * @return void
     */
    function LiveUser_Admin_Perm_Container_DB_Complex(&$connectOptions)
    {
        $this->LiveUser_Admin_Perm_Container_DB_Medium($connectOptions);
    }

    /**
     * Add a group to the database
     *
     * @access public
     * @param  string  name of group constant
     * @param  string  name of group
     * @param  boolean description of group
     * @param  boolean activate group?
     * @param  integer owner_perm_user_id of group
     * @param  integer owner_group_id of group
     * @return mixed integer (group_id) or DB Error object
     */
    function addGroup($define_name, $group_name, $group_comment = null, $active = false, $owner_user = null, $owner_group = null)
    {
        // Get next group ID
        $group_id = $this->dbc->nextId($this->prefix . 'groups');
        if (DB::isError($group_id)) {
            return $group_id;
        };

        // Insert Group into Groupstable
        $query = 'INSERT INTO
                  ' . $this->prefix . 'groups
                  (group_id, group_define_name, owner_perm_user_id, owner_group_id, is_active)
                VALUES
                  (
                    ' . (int)$group_id . ',
                    ' . $this->dbc->quote($define_name) . ',
                    ' . (($owner_user  === null) ? 'null' : $this->dbc->quote($owner_user)) . ',
                    ' . (($owner_group === null) ? 'null' : (int)$owner_group) . ',
                    \'' . ($active ? 'Y' : 'N') . '\'
                  )';

        $result = $this->dbc->query($query);

        if (DB::isError($result)) {
            return $result;
        };

        // Insert Group tranlation into Tranlastions table
        $result = $this->addTranslation(
            $group_id,
            LIVEUSER_SECTION_GROUP,
            $this->getCurrentLanguage(),
            $group_name,
            $group_comment
        );
        if (DB::isError($result)) {
            return $result;
        };

        return $group_id;
    }

    /**
     * Assign subgroup to parent group.
     *
     * First checks that the child group does not have a parent group
     * already assigned to it. If so it returns an error object
     *
     * @access public
     * @param  integer id of parent group
     * @param  integer id of child group
     * @return mixed boolean, DB Error object or LiveUser Error Object
     */
    function assignSubgroup($group_id, $subgroup_id)
    {
        $query = 'SELECT subgroup_id FROM
                  ' . $this->prefix . 'group_subgroups
                  WHERE subgroup_id=' . $this->dbc->quote($subgroup_id);

        if (!is_null($this->dbc->getOne($query))) {
            return PEAR::raiseError(null, LIVEUSER_ERROR, null, E_USER_WARNING,
                'Child group already has a parent group', 'LiveUser', true);
        }

        $query = 'INSERT INTO
                  ' . $this->prefix . 'group_subgroups
                  (group_id, subgroup_id)
                VALUES
                  (
                    ' . (int)$group_id . ',
                    ' . (int)$subgroup_id . '
                  )';

        $result = $this->dbc->query($query);

        return $result;
    }

    /**
     * Deletes a group from the database
     *
     *
     * @access public
     * @param  integer id of deleted group
     * @param  boolean recursive delete of all subgroups
     * @return mixed   boolean or DB Error object
     */
    function removeGroup($group_id, $recursive = false)
    {
        // Recursive delete groups
        if ($recursive) {
            // Get all subgroups
            $query = 'SELECT
                      subgroup_id
                    FROM
                      ' . $this->prefix . 'group_subgroups
                    WHERE
                      group_id = ' . (int)$group_id;

            $result = $this->dbc->getCol($query);

            if (DB::isError($result)) {
                return $result;
            };

            // Recursive removeGroup() call for every subgroup
            foreach ($result as $subgroup_id) {
                $res = $this->removeGroup($subgroup_id, true);
                if (DB::isError($res)) {
                    return $res;
                };
            };
        };

        Parent::removegroup($group_id);

        // Delete Subgroup assignments
        $query = 'DELETE FROM
                  ' . $this->prefix . 'group_subgroups
                WHERE
                  group_id = ' . (int)$group_id . ' OR
                  subgroup_id = ' . (int)$group_id;

        $result = $this->dbc->query($query);

        if (DB::isError($result)) {
            return $result;
        };

        // sets owner_group_id to null
        $query = 'UPDATE
                  ' . $this->prefix . 'groups
                SET
                  owner_group_id = NULL
                WHERE
                  owner_group_id = ' . $group_id;

        $result = $this->dbc->query($query);

        if (DB::isError($result)) {
            return $result;
        };

        return true;
    }

    /**
     * Update group
     *
     * @access public
     * @param  string  id of group
     * @param  string  name of group
     * @param  boolean description of group
     * @param  boolean activate group?
     * @param  integer owner_perm_user_id of group
     * @param  integer owner_group_id of group
     * @return mixed   boolean or DB Error object
     */
    function updateGroup($group_id, $group_name, $group_comment = null, $active = null, $owner_user = null, $owner_group = null)
    {
        $query = 'UPDATE
                  ' . $this->prefix . 'groups
                SET
                  owner_perm_user_id  = ' . (($owner_user  !== null) ? $this->dbc->quote($owner_user) : 'null') . ',
                  owner_group_id = ' . (($owner_group !== null) ? (int)$owner_group : 'null');
        if ($active !== null) {
            $query .= ', is_active = ' . ($active ? '\'Y\'' : '\'N\'');
        }
        $query .= ' WHERE
                  group_id = ' . (int)$group_id;
        $result = $this->dbc->query($query);
        if (DB::isError($result)) {
            return $result;
        };

        // Update Group tranlation into Tranlastions table
        $result = $this->updateTranslation(
            $group_id,
            LIVEUSER_SECTION_GROUP,
            $this->getCurrentLanguage(),
            $group_name,
            $group_comment
        );
        if (DB::isError($result)) {
            return $result;
        };

        return true;
    }

    /**
     * Imply right
     *
     * @access public
     * @param  integer id of right
     * @param  string  id of implied right
     * @return mixed   boolean or DB Error object
     */
    function implyRight($right_id, $implied_right_id)
    {
        // Imply Right
        $query = 'INSERT INTO
                  ' . $this->prefix . 'right_implied
                  (right_id, implied_right_id)
                VALUES
                  (
                    ' . (int) $right_id . ',
                    ' . (int) $implied_right_id . '
                  )';

        $result = $this->dbc->query($query);

        if (DB::isError($result)) {
            return $result;
        };

        // Update implied status
        $res = $this->_updateImpliedStatus($right_id);

        if (DB::isError($res)) {
            return $res;
        };

        // Job done ...
        return true;
    }

    /**
     * Unimply right
     *
     * @access public
     * @param  integer id of right
     * @param  string  id of implied right
     * @return mixed   boolean or DB Error object
     */
    function unimplyRight($right_id, $implied_right_id)
    {
        // Unimply right
        $query = 'DELETE FROM
                  ' . $this->prefix . 'right_implied
                WHERE
                  right_id         = ' . (int)$right_id . ' AND
                  implied_right_id = ' . (int)$implied_right_id;
        $result = $this->dbc->query($query);
        if (DB::isError($result)) {
            return $result;
        };

        // Update implied status
        $res = $this->_updateImpliedStatus($right_id);

        if (DB::isError($res)) {
            return $res;
        };

        // Job done ...
        return true;
    }

    /**
     * Update implied status of right
     *
     * @access private
     * @param  integer id of right
     * @return mixed   boolean or DB Error object
     */
    function _updateImpliedStatus($right_id)
    {
        // Are there any implied rights?
        $query = 'SELECT
                  Count(*)
                FROM
                  ' . $this->prefix . 'right_implied
                WHERE
                  right_id = ' . (int)$right_id;

        $count = $this->dbc->getOne($query);

        if (DB::isError($count)) {
            return $count;
        };

        $query = 'UPDATE
                  ' . $this->prefix . 'rights
                SET
                  has_implied = \'' . (((int)$count > 0) ? 'Y' : 'N') . '\'
                WHERE
                  right_id = ' . (int)$right_id;

        $result = $this->dbc->query($query);

        if (DB::isError($result)) {
            return $result;
        };

        // Job done ...
        return true;
    }

    /**
     * Overriden method to delete implied rights mapping
     * as well as the right.
     *
     * @access public
     * @param  int   right identifier
     * @return mixed true on success or DB error
     */
    function removeRight($right_id)
    {
        Parent::removeRight($right_id);

        // delete from implied_rights unimply rights
        $query = 'DELETE FROM
                  ' . $this->prefix . 'right_implied
                WHERE
                  right_id         = ' . (int)$right_id;

        $result = $this->dbc->query($query);

        if (DB::isError($result)) {
            return $result;
        };

        // Update implied status
        $res = $this->_updateImpliedStatus($right_id);

        if (DB::isError($res)) {
            return $res;
        };

        return true;
    }


    /**
     * Add User to Group
     *
     * @access public
     * @param  string  id of user
     * @param  integer id of group
     * @return mixed   boolean or DB Error object
     */
    function addUserToGroup($authId, $group_id)
    {
        $query = 'INSERT INTO
                  ' . $this->prefix . 'groupusers
                  (group_id, perm_user_id)
                VALUES
                  (
                    ' . (int)$group_id . ',
                    ' . $this->_getPermUserId($authId) . '
                  )';
        $result = $this->dbc->query($query);
        if (DB::isError($result)) {
            return $result;
        };

        // Job done ...
        return true;
    }

    /**
     * Remove User from Group
     *
     * @access public
     * @param  string  id of user
     * @param  integer id of group
     * @return mixed   boolean or DB Error object
     */
    function removeUserFromGroup($authId, $group_id)
    {
        $query = 'DELETE FROM
                  ' . $this->prefix . 'groupusers
                WHERE
                  perm_user_id  = ' . $this->_getPermUserId($authId) . ' AND
                  group_id = ' . (int) $group_id;

        $result = $this->dbc->query($query);

        if (DB::isError($result)) {
            return $result;
        };

        // Job done ...
        return true;
    }

    /**
     * Get list of all groups
     *
     * This method accepts the following options...
     * <code>
     *  'where_user_id' = [PERM_USER_ID],
     *  'where_group_id' = [GROUP_ID],
     *  'where_owner_user_id' = [OWNER_USER_ID],
     *  'where_owner_group_id' = [OWNER_GROUP_ID],
     *  'where_is_active' = [BOOLEAN],
     *  'with_rights' = [BOOLEAN]
     * </code>
     *
     * @access public
     * @param  array  an array determining which fields and conditions to use
     * @param  mixed  do not use this parameter. Its for internal (recursive) use only
     * @return mixed array or DB Error object
     */
    function getGroups($options = null, $parentgroup = null)
    {
        static $groups;
        static $subgroups;
        $result = array();

        if ($parentgroup === null) {
            $query = 'SELECT
                      groups.group_id           AS group_id,
                      groups.owner_perm_user_id AS owner_user_id,
                      groups.owner_group_id     AS owner_group_id,
                      translations.name         AS name,
                      translations.comments     AS "comment",
                      groups.is_active          AS is_active
                    FROM';

            if (isset($options['where_user_id'])
                    && is_numeric($options['where_user_id'])) {
                $query .= ' ' . $this->prefix . 'groupusers groupusers,';
            }

            $query .= ' ' . $this->prefix . 'groups groups,
                      ' . $this->prefix . 'translations translations
                    WHERE';

            if (isset($options['where_user_id'])
                    && is_numeric($options['where_user_id'])) {
                $query .= ' groupusers.perm_user_id = ' . (int)$options['where_user_id'] . ' AND
                          groupusers.group_id = groups.group_id AND';
            }

            if (isset($options['where_group_id'])
                     && is_numeric($options['where_group_id'])) {
                $query .= ' groups.group_id = ' . (int)$options['where_group_id'] . ' AND';
            }

            if (isset($options['where_owner_user_id'])
                    && is_numeric($options['where_owner_user_id'])) {
                $query .= ' groups.owner_user_id = ' . (int)$options['where_owner_user_id'] . ' AND';
            }

            if (isset($options['where_owner_group_id'])
                    && is_numeric($options['where_owner_group_id'])) {
                $query .= ' groups.owner_group_id = ' . (int)$options['where_owner_group_id'] . ' AND';
            }

            if (isset($options['where_is_active'])
                    && is_string($options['where_is_active'])) {
                $query .= ' groups.is_active = ' . $options['where_is_active'] . ' AND';
            }

            $query .= ' translations.section_id = groups.group_id AND
                      translations.section_type = ' . LIVEUSER_SECTION_GROUP . ' AND
                      translations.language_id = ' . (int)$this->_langs[$this->getCurrentLanguage()];

            $groups = $this->dbc->getAll($query, null, DB_FETCHMODE_ASSOC);

            if (DB::isError($groups)) {
                return $groups;
            };

            $_groups = array();
            if (is_array($groups)) {
                foreach($groups as $key => $value) {
                    if (isset($options['with_rights'])) {
                        $_options = $options;
                        $_options['where_group_id'] = $value['group_id'];
                        $value['rights'] = $this->getRights($_options);
                    };
                    $_groups[$value['group_id']] = $value;
                };
            };

            $query = 'SELECT
                      subgroups.group_id as group_id,
                      subgroups.subgroup_id as subgroup_id
                    FROM
                      ' . $this->prefix . 'group_subgroups subgroups';

            $subgroups = $this->dbc->getAll($query, null, DB_FETCHMODE_ASSOC);

            if (DB::isError($subgroups)) {
                return $subgroups;
            };

            foreach($_groups as $id => $group) {
                $in_array = false;
                if (is_array($subgroups)) {
                    foreach($subgroups as $subgroup) {
                        if ($id == $subgroup['subgroup_id']) {
                            $in_array = true;
                            break;
                        };
                    };
                };
                if (!$in_array) {
                    $result[$id] = $group;
                    $result[$id]['subgroups'] = $this->getGroups($options, $id);
                };
            };
        } else {
            if (is_array($subgroups)) {
                foreach($subgroups as $subgroup) {
                    if ($subgroup['group_id'] == $parentgroup) {
                        $result[$subgroup['subgroup_id']] = $_groups[$subgroup['subgroup_id']];
                        $result[$subgroup['subgroup_id']]['subgroups'] = $this->getGroups($options, $subgroup['subgroup_id']);
                    };
                };
            };
        };

        return $result;
    }

    /*
     * Delete a user.
     *
     * @access public
     * @param  string  auth_user_id
     * @return mixed   boolean or DB Error object
     */
    function removeUser($authId)
    {
        Parent::removeUser($authId);

        // sets owner_perm_user_id to null
        $query = 'UPDATE
                  ' . $this->prefix . 'groups
                SET
                  owner_perm_user_id = NULL
                WHERE
                  owner_perm_user_id=' . $permId;

        $result = $this->dbc->query($query);

        if (DB::isError($result)) {
            return $result;
        };

        return true;
    }
}
?>