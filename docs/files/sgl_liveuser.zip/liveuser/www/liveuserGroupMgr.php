<?php
//	initialise
	require_once '../init.php';
	require_once SGL_MOD_DIR . '/liveuser/classes/LiveuserGroupMgr.php';
	require_once SGL_CORE_DIR . '/Controller.php';
	error_log('###############	NEW PAGE RUN - LIVEUSER GROUP MGR	###############');
    $process = & new Controller();
    $process->page = & new LiveuserGroupMgr();
    $process->go(new Request());
?>