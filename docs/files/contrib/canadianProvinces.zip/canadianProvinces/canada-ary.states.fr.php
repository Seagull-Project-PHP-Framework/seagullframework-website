<?php
    $states = array(
        ''  =>'',
        'En dehors du Canada'=>'En dehors du Canada',
        'AB'=>'Alberta',
        'BC'=>'Colombie-Britannique',
        'MB'=>'Manitoba',
        'NB'=>'Nouveau-Brunswick',
        'NL'=>'Terre-Neuve et Labrador',
        'NS'=>'Nouvelle-Ecosse',
        'NT'=>'Territoires du Nord-Ouest',
        'NU'=>'Nunavut',
        'ON'=>'Ontario',
        'PE'=>'Ile-du-Prince-Edouard',
        'QC'=>'Quebec',
        'SK'=>'Saskatchewan',
        'YT'=>'Yukon'
    );
?>