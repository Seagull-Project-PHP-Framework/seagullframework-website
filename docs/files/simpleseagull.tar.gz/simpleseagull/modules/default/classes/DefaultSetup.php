<?php

require_once SGL_CORE_DIR . '/Setup.php';

class DefaultSetup extends SGL_Setup
{
    var $removable = false;
    var $module = 'default';

    function getTitle()
    {
        return 'Default';
    }

    function getDescription()
    {
        return 'This is a default module';
    }

    function isInstalled()
    {
        return true;
    }
}

?>