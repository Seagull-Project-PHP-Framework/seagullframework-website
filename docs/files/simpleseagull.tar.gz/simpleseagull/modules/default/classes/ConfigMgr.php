<?php
/* Reminder: always indent with 4 spaces (no tabs). */
// +---------------------------------------------------------------------------+
// | Copyright (c) 2004, Demian Turner                                         |
// | All rights reserved.                                                      |
// |                                                                           |
// | Redistribution and use in source and binary forms, with or without        |
// | modification, are permitted provided that the following conditions        |
// | are met:                                                                  |
// |                                                                           |
// | o Redistributions of source code must retain the above copyright          |
// |   notice, this list of conditions and the following disclaimer.           |
// | o Redistributions in binary form must reproduce the above copyright       |
// |   notice, this list of conditions and the following disclaimer in the     |
// |   documentation and/or other materials provided with the distribution.    |
// | o The names of the authors may not be used to endorse or promote          |
// |   products derived from this software without specific prior written      |
// |   permission.                                                             |
// |                                                                           |
// | THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       |
// | "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         |
// | LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR     |
// | A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT      |
// | OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     |
// | SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          |
// | LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     |
// | DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     |
// | THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       |
// | (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     |
// | OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      |
// |                                                                           |
// +---------------------------------------------------------------------------+
// | Seagull 0.4                                                               |
// +---------------------------------------------------------------------------+
// | ConfigMgr.php                                                             |
// +---------------------------------------------------------------------------+
// | Author:   Demian Turner <demian@phpkitchen.com>                           |
// +---------------------------------------------------------------------------+
// $Id: ConfigMgr.php,v 1.27 2005/01/23 02:30:19 demian Exp $

require_once 'Config.php';
require_once 'Validate.php';

/**
 * To manage administering global config file.
 *
 * @package default
 * @author  Demian Turner <demian@phpkitchen.com>
 * @version $Revision: 1.27 $
 * @since   PHP 4.1
 */
class ConfigMgr extends SGL_Manager
{
    var $aDbTypes;
    var $aLogTypes;
    var $aLogNames;
    var $aCensorModes;
    var $aNavDrivers;

    function ConfigMgr()
    {
        SGL::logMessage(null, PEAR_LOG_DEBUG);
        $this->module = 'default';
        $this->pageTitle = 'Config Manager';
        $this->template = 'configEdit.html';
        $this->aDbTypes = array(
            'mysql' => 'mysql',
            );
        $this->aLogTypes = array(
            'file' => 'file',
            'mcal' => 'mcal',
            'sql' => 'sql',
            'syslog' => 'syslog',
            );
        //  any files where the last 3 letters are 'Nav' in the modules/navigation/classes will be returned
        $this->aSessHandlers = array('file' => 'file');

        $this->_aActionsMapping =  array(
            'edit'   => array('edit'), 
            'insert' => array('insert', 'redirectToDefault'), 
        );
    }

    function validate($req, &$input)
    {
        SGL::logMessage(null, PEAR_LOG_DEBUG);

        $this->validated    = true;
        $input->pageTitle   = $this->pageTitle;
        $input->masterTemplate = $this->masterTemplate;
        $input->template    = $this->template;
        $input->action      = ($req->get('action')) ? $req->get('action') : 'edit';
        $input->aDelete     = $req->get('frmDelete');
        $input->submit      = $req->get('submitted');
        $input->conf        = $req->get('conf');

        $aErrors = array();
        if ($input->submit) {
            $v = & new Validate();
            if (empty($input->conf['site']['baseUrl']) || 
                !preg_match('/^https?:\/\/[a-z0-9]+/i', $input->conf['site']['baseUrl'])) {
                $aErrors['baseUrl'] = 'Please enter a valid URI';
            }
        }
        //  if errors have occured
        if (isset($aErrors) && count($aErrors)) {
            SGL::raiseMsg('Please fill in the indicated fields');
            $input->error = $aErrors;
            $input->template = 'configEdit.html';
            $this->validated = false;
        }
    }

    function display(&$output)
    {
        SGL::logMessage(null, PEAR_LOG_DEBUG);

        require_once SGL_DAT_DIR . '/ary.logLevels.php';
        $output->conf = $GLOBALS['_SGL']['CONF'];
        $output->aDbTypes = $this->aDbTypes;
        $output->aLogTypes = $this->aLogTypes;
        $output->aLogPriorities = $aLogLevels;
        $output->aEmailThresholds = $aLogLevels;
        $output->aSessHandlers = $this->aSessHandlers;
    }

    function _edit(&$input, &$output)
    {
        SGL::logMessage(null, PEAR_LOG_DEBUG);
    }

    function _insert(&$input, &$output)
    {
        SGL::logMessage(null, PEAR_LOG_DEBUG);
        $c = new Config();
        //  read configuration data and get reference to root
        $root = & $c->parseConfig($input->conf, 'phparray');
        //  write configuration to file
        $result = $c->writeConfig(SGL_PATH . '/var/' . SGL_SERVER_NAME . '.default.conf.ini', 'inifile');
        if (!is_a($result, 'PEAR_Error')) {
            SGL::raiseMsg('config info successfully updated');
        } else {
            SGL::raiseError('There was a problem saving your configuration, make sure /var is writable', 
                SGL_ERROR_FILEUNWRITABLE);
        }
    }
}
?>