<?php
/* Reminder: always indent with 4 spaces (no tabs). */
// +---------------------------------------------------------------------------+
// | Copyright (c) 2004, Demian Turner                                         |
// | All rights reserved.                                                      |
// |                                                                           |
// | Redistribution and use in source and binary forms, with or without        |
// | modification, are permitted provided that the following conditions        |
// | are met:                                                                  |
// |                                                                           |
// | o Redistributions of source code must retain the above copyright          |
// |   notice, this list of conditions and the following disclaimer.           |
// | o Redistributions in binary form must reproduce the above copyright       |
// |   notice, this list of conditions and the following disclaimer in the     |
// |   documentation and/or other materials provided with the distribution.    |
// | o The names of the authors may not be used to endorse or promote          |
// |   products derived from this software without specific prior written      |
// |   permission.                                                             |
// |                                                                           |
// | THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       |
// | "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         |
// | LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR     |
// | A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT      |
// | OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     |
// | SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          |
// | LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     |
// | DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     |
// | THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       |
// | (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     |
// | OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      |
// |                                                                           |
// +---------------------------------------------------------------------------+
// | Seagull 0.4                                                               |
// +---------------------------------------------------------------------------+
// | ModuleMgr.php                                                             |
// +---------------------------------------------------------------------------+
// | Authors:   Demian Turner <demian@phpkitchen.com>                          |
// |            Michael Willemot <michael@sotto.be>                            |
// +---------------------------------------------------------------------------+
// $Id: ModuleMgr.php,v 1.33 2005/01/23 02:30:19 demian Exp $

require_once SGL_CORE_DIR . '/Manager.php';
require_once 'DB/DataObject.php';

define('SGL_ICONS_PER_ROW', 3);

/**
 * Will manage loading of modules.
 *
 * @package default
 * @author  Demian Turner <demian@phpkitchen.com>
 * @version $Revision: 1.33 $
 * @since   PHP 4.1
 */
class ModuleMgr extends SGL_Manager
{
    function ModuleMgr()
    {
        SGL::logMessage(null, PEAR_LOG_DEBUG);
        $this->module       = 'default';
        $this->pageTitle    = 'Module Manager';
        $this->template     = 'moduleOverview.html';

        $this->_aActionsMapping =  array(
            'edit'      => array('edit'), 
            'update'    => array('update', 'redirectToDefault'), 
            'list'      => array('list'), 
            'overview'  => array('overview'), 
            'install'  => array('install'),
            'uninstall'  => array('uninstall'),
        );
    }

    function validate($req, &$input)
    {
        SGL::logMessage(null, PEAR_LOG_DEBUG);

        $this->validated        = true;
        $input->pageTitle       = $this->pageTitle;
        $input->masterTemplate  = 'master.html';
        $input->template        = $this->template;

        $input->action = ($req->get('action')) ? $req->get('action') : 'overview';
        
        $input->moduleName      = $req->get('moduleName');
        $input->module          = (object)$req->get('module');
        $input->module->is_configurable = (isset($input->module->is_configurable)) ? 1 : 0;
        $input->submit          = $req->get('submitted');

        //  validate fields
        $aErrors = array();
        if ($input->submit && $input->action == 'update') {
            $aFields = array(
                'title' => 'Please, specify a title',
                'description' => 'Please, specify a description',
            );
            foreach ($aFields as $field => $errorMsg) {
                if (empty($input->module->$field)) {
                    $aErrors[$field] = $errorMsg;
                }
            }
        }

        //  if errors have occured
        if (isset($aErrors) && count($aErrors)) {
            SGL::raiseMsg('Please fill in the indicated fields');
            $input->error = $aErrors;
            $input->template = 'moduleEdit.html';
            $input->isConfigurable = ($input->module->is_configurable) ? 'checked' : '';
            $this->validated = false;
        }
    }

    function display(&$output)
    {
        SGL::logMessage(null, PEAR_LOG_DEBUG);
        $output->aAdminUris = ModuleMgr::getStartFiles();
    }

    function _overview(&$input, &$output)
    {
        SGL::logMessage(null, PEAR_LOG_DEBUG);
        $conf = & $GLOBALS['_SGL']['CONF'];
        $dbh = & SGL_DB::singleton();
        $query = '  SELECT *
                    FROM module
                    ORDER BY name';
        $aModules = $dbh->getAll($query);
        if (!DB::isError($aModules)) {
            $ret = array();
            foreach ($aModules as $k => $aVal) {
                $aVal->bgnd = ($aVal->is_configurable) ? 'bgnd' : 'outline';
                $aVal->breakRow = !((count($ret)+1) % SGL_ICONS_PER_ROW);
                $ret[]= clone($aVal);
            }
            $output->aModules = $ret;
        } else {
            SGL::raiseError('module manager failed', SGL_ERROR_NODATA);
        }
    }

    function _edit(&$input, &$output)
    {
        SGL::logMessage(null, PEAR_LOG_DEBUG);
        $output->pageTitle = $this->pageTitle . ' :: Edit';
        $output->action = 'update';
        $output->template  = 'moduleEdit.html';
        
        $oModule = DB_DataObject::factory('module');
        $oModule->get($input->moduleId);
        $output->module = $oModule;
        $output->isConfigurable = ($oModule->is_configurable) ? ' checked' : '';
    }

    function _update(&$input, &$output)
    {
        SGL::logMessage(null, PEAR_LOG_DEBUG);
        $output->template = 'moduleList.html';
        
        $newEntry = DB_DataObject::factory('module');
        $newEntry->get($input->module->module_id);
        $newEntry->setFrom($input->module);
        $success = $newEntry->update();

        if ($success) {
            SGL::raiseMsg('module successfully updated');
        } else {
           SGL::raiseError('There was a problem inserting the record', 
                SGL_ERROR_NOAFFECTEDROWS);
        }
    }

    function _uninstall(&$input, &$output)
    {
        SGL::logMessage(null, PEAR_LOG_DEBUG);

        $moduleSetup = ModuleMgr::factorySetup($input->moduleName);
        
        if($moduleSetup && $moduleSetup->uninstall() && $this->updateModulesIni()) {
            SGL::raiseMsg('Module successfully removed');
        } else {
            SGL::raiseError('There were some errors while uninstalling the module, see the log file for details', SGL_ERROR_NOAFFECTEDROWS);
        }
        
        SGL_HTTP::redirect('moduleMgr.php', array('action' => 'list'));
    }

    function _install(&$input, &$output)
    {
        SGL::logMessage(null, PEAR_LOG_DEBUG);
        
        $moduleSetup = ModuleMgr::factorySetup($input->moduleName);

        if($moduleSetup->install() && $this->updateModulesIni()) {
            SGL::raiseMsg('Module successfully installed');
        } else {
            SGL::raiseError('There were some errors while installing the module, see the log');
        }
        
        SGL_HTTP::redirect('moduleMgr.php', array('action' => 'list'));
    }
    
    function updateModulesIni()
    {
        $modules = &ModuleMgr::scanAndRetrieveModulesSetups();
        $modulesIni = array();
        foreach ($modules as $moduleName => $moduleSetup) {
            $modulesIni['modules'][$moduleName] = $moduleSetup->isInstalled();
        }
        
        require_once 'Config.php';
        $c = new Config();
        //  read configuration data and get reference to root
        $root = & $c->parseConfig($modulesIni, 'phparray');
        //  write configuration to file
        $result = $c->writeConfig(SGL_PATH . '/var/modules.ini', 'inifile');
        if (is_a($result, 'PEAR_Error')) {
            SGL::raiseError('There was a problem saving your configuration, make sure /var is writable', 
                SGL_ERROR_FILEUNWRITABLE);
            return false;
        } else {
            return true;
        }
    }

    function _list(&$input, &$output)
    {
        SGL::logMessage(null, PEAR_LOG_DEBUG);
        $output->template = 'moduleList.html';
        
        $modules = &ModuleMgr::scanAndRetrieveModulesSetups();
        $output->modules = array();
        foreach ($modules as $moduleName => $moduleSetup) {
            $output->modules[$moduleName] = new stdClass();
            $output->modules[$moduleName]->name = $moduleName;
            $output->modules[$moduleName]->title = $moduleSetup->title;
            $output->modules[$moduleName]->description = $moduleSetup->description;
            $output->modules[$moduleName]->isInstalled = $moduleSetup->isInstalled();
            $output->modules[$moduleName]->removable = $moduleSetup->removable;
        }
    }
    
    function factorySetup($moduleName)
    {
        $path = SGL_MOD_DIR . '/' . $moduleName . '/classes/'. ucfirst($moduleName) . 'Setup.php';
        $conf = & $GLOBALS['_SGL']['CONF'];
        if($conf['debug']['production']) {
            @include_once $path;
        } else {
            include_once $path;
        }
        $classname = ucfirst($moduleName). 'Setup';

        if (!class_exists($classname)) {
            SGL::raiseError("Unable to include the ".$path." file", SGL_ERROR_NOCLASS);
            return false;
        } else {
            @$obj = &new $classname;
            return $obj;
        }
    }

    function &scanAndRetrieveModulesSetups()
    {
        SGL::logMessage(null, PEAR_LOG_DEBUG);
        
        require_once 'File/Util.php';
        
        $aFiles = File_Util::listDir(SGL_MOD_DIR, FILE_LIST_DIRS, FILE_SORT_NAME);
        $modulesSetups = array();
        foreach ($aFiles as $oFile) {
            // include module setup file
            $moduleSetup = $this->factorySetup($oFile->name);
            if($moduleSetup) {
                $modulesSetups[$oFile->name] = clone($moduleSetup);
            }
        }
        
        return $modulesSetups;
    }

    function retrieveAllModules($type = '')
    {
        SGL::logMessage(null, PEAR_LOG_DEBUG);
        $dbh = & SGL_DB::singleton();
        
        $aMods = array();

        switch ($type) {
        case SGL_RET_ID_VALUE:
            $query = '  SELECT module_id, title
                        FROM module
                        ORDER BY module_id';
            $aMods = $dbh->getAssoc($query);
            break;

        case SGL_RET_NAME_VALUE:
        default:
            $query = '  SELECT name, title 
                        FROM module 
                        ORDER BY name';
            $aModules = $dbh->getAll($query);
            foreach ($aModules as $k => $oVal) {
                if ($oVal->name == 'documentor') {
                    continue;
                }
                $aMods[$oVal->name] = $oVal->title;
            }
            break;
        }
        return $aMods;
    }

    function getStartFiles()
    {
        SGL::logMessage(null, PEAR_LOG_DEBUG);

        require_once 'File/Util.php';

        //  match files with php extension
        $ret = ModuleMgr::listDir(SGL_WEB_ROOT, FILE_LIST_FILES, $sort = FILE_SORT_NONE, 
                create_function('$a', 'return preg_match("/.*\.php/", $a);'));
        return $ret;
    }
    
    /**
     * Wrapper for the File_Util::listDir method.
     * 
     * Instead of returning an array of objects, it returns an array of
     * strings (filenames).
     * 
     * The final argument, $cb, is a callback that either evaluates to true or
     * false and performs a filter operation, or it can also modify the 
     * directory/file names returned.  To achieve the latter effect use as 
     * follows:
     * 
     * <code>
     * function uc(&$filename) {
     *     $filename = strtoupper($filename);
     *     return true;
     * }
     * $entries = File_Util::listDir('.', FILE_LIST_ALL, FILE_SORT_NONE, 'uc');
     * foreach ($entries as $e) {
     *     echo $e->name, "\n";
     * }
     * </code>
     * 
     * @static
     * @access  public
     * @return  array
     * @param   string  $path
     * @param   int     $list
     * @param   int     $sort
     * @param   mixed   $cb
     */
    function listDir($path, $list = FILE_LIST_ALL, $sort = FILE_SORT_NONE, $cb = null)
    {
        $aFiles = File_Util::listDir($path, $list, $sort, $cb);
        $aRet = array();
        foreach ($aFiles as $oFile) {
            $aRet[$oFile->name] = $oFile->name;
        }
        return $aRet;
    }
}
?>