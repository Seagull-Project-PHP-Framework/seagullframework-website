<?php
/* Reminder: always indent with 4 spaces (no tabs). */
// +---------------------------------------------------------------------------+
// | Copyright (c) 2004, Demian Turner                                         |
// | All rights reserved.                                                      |
// |                                                                           |
// | Redistribution and use in source and binary forms, with or without        |
// | modification, are permitted provided that the following conditions        |
// | are met:                                                                  |
// |                                                                           |
// | o Redistributions of source code must retain the above copyright          |
// |   notice, this list of conditions and the following disclaimer.           |
// | o Redistributions in binary form must reproduce the above copyright       |
// |   notice, this list of conditions and the following disclaimer in the     |
// |   documentation and/or other materials provided with the distribution.    |
// | o The names of the authors may not be used to endorse or promote          |
// |   products derived from this software without specific prior written      |
// |   permission.                                                             |
// |                                                                           |
// | THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       |
// | "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         |
// | LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR     |
// | A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT      |
// | OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     |
// | SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          |
// | LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     |
// | DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     |
// | THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       |
// | (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     |
// | OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      |
// |                                                                           |
// +---------------------------------------------------------------------------+
// | Seagull 0.4                                                               |
// +---------------------------------------------------------------------------+
// | MaintenanceMgr.php                                                        |
// +---------------------------------------------------------------------------+
// | Author:   Demian Turner <demian@phpkitchen.com>                           |
// +---------------------------------------------------------------------------+
// $Id: MaintenanceMgr.php,v 1.44 2005/02/07 10:13:08 demian Exp $

require_once 'Config.php';

/**
 * Provides tools to manage translations and mtce tasks.
 *
 * @package maintenance
 * @author  Demian Turner <demian@phpkitchen.com>
 * @version $Revision: 1.44 $
 * @since   PHP 4.1
 */
class MaintenanceMgr extends SGL_Manager
{
    function MaintenanceMgr()
    {
        SGL::logMessage(null, PEAR_LOG_DEBUG);
        $this->module       = 'maintenance';
        $this->pageTitle    = 'Maintenance';
        $this->template     = 'langList.html';
        $this->redirect     = true;

        $this->_aActionsMapping =  array(
            'dbgen'     => array('dbgen'), 
            'rebuildSequences' => array('rebuildSequences', 'redirectToDefault'), 
            'createModule' => array('createModule', 'redirectToDefault'),
            'list'      => array('list'), 
        );
    }

    function validate($req, &$input)
    {
        SGL::logMessage(null, PEAR_LOG_DEBUG);

        $this->validated    = true;
        $input->pageTitle   = $this->pageTitle;
        $input->masterTemplate = $this->masterTemplate;
        $input->template    = $this->template;
        $input->submit      = $req->get('submitted');
        $input->action      = ($req->get('action')) ? $req->get('action') : 'list';
        $input->createModule = (object)$req->get('frmCreateModule');

        if ($input->submit) {
            if ($req->get('action') =='') {
                $aErrors['noSelection'] = 'please specify an option';
            }

            //  checks for creating modules
            if ($input->action == 'createModule') {
                if (empty($input->createModule->moduleName)) {
                    $aErrors['moduleName'] = 'please enter module name';
                }
                if (empty($input->createModule->managerName)) {
                    $aErrors['managerName'] = 'please enter manager name';
                }
            }
        }
        //  if errors have occured
        if (isset($aErrors) && count($aErrors)) {
            SGL::raiseMsg('Please fill in the indicated fields');
            $input->error = $aErrors;
            $this->validated = false;
        }
    }

    function display(&$output)
    {
        SGL::logMessage(null, PEAR_LOG_DEBUG);

        //  get hash of all modules
        require_once SGL_MOD_DIR . '/default/classes/ModuleMgr.php';
        $output->aModules = ModuleMgr::retrieveAllModules(SGL_RET_NAME_VALUE);
    }

    //    regenerate dataobject entity files
    function _dbgen(&$input, &$output)
    {
        require_once SGL_CORE_DIR . '/Sql.php';
        $res = SGL_Sql::generateDataObjectEntities();
        SGL::raiseMsg('Data Objects rebuilt successfully');
        SGL::logMessage($res, null, null, PEAR_LOG_DEBUG);
    }

    function _rebuildSequences(&$input, &$output)
    {
        SGL::logMessage(null, PEAR_LOG_DEBUG);
        require_once SGL_CORE_DIR . '/Sql.php';
        $res = SGL_Sql::rebuildSequences();
        if (PEAR::isError($res)) {
            return $res;
        } else {
            SGL::raiseMsg('Sequences rebuilt successfully');
        }
    }

    function _createModule(&$input, &$output)
    {
        SGL::logMessage(null, PEAR_LOG_DEBUG);

        $modName = strtolower($input->createModule->moduleName);
        $mgrName = strtolower($input->createModule->managerName);

        //  strip final 'mgr' if necessary
        if (substr($mgrName, -3) == 'mgr') {
            $mgrName = preg_replace("/mgr/", '', $mgrName);
        }

        //  set mod/mgr details
        $output->moduleName = $modName;
        $output->templatePrefix = $mgrName;
        $output->managerName = ucfirst($mgrName);

        $aMethods = array('add', 'insert', 'edit', 'update', 'list', 'delete');
        $methods = '';
        foreach ($aMethods as $method) {
            if (isset($input->createModule->$method)) {
                $methods .= <<< EOF

    function _$method(&\$input, &\$output)
    {
        SGL::logMessage(null, PEAR_LOG_DEBUG);
    }

EOF;
            }
        }

        $output->methods = $methods;

        //  initialise template engine
        $options = &PEAR::getStaticProperty('HTML_Template_Flexy','options');
        $options = array(
            'templateDir'       => SGL_MOD_DIR . '/maintenance/classes/',
            'compileDir'        => SGL_TMP_DIR,
            'forceCompile'      => SGL_FLEXY_FORCE_COMPILE,
            'filters'           => array('SimpleTags','Mail'),
            'compiler'          => 'Regex',
            'flexyIgnore'       => SGL_FLEXY_IGNORE,
            'globals'           => true,
            'globalfunctions'   => SGL_FLEXY_GLOBAL_FNS,
        );

        $templ = & new HTML_Template_Flexy();
        $templ->compile('ManagerTemplate.html');
        $data = $templ->bufferedOutputObject($output, array());
        $data = preg_replace("/\&amp;/s", '&', $data);
        $mgrTemplate = "<?php\n" . $data . "\n?>";

        //  setup target directory
        $targetDir = SGL_MOD_DIR . '/' . $output->moduleName . '/classes';

        if (is_writable(SGL_MOD_DIR)) {
            include_once 'System.php';

            //  pass path as array to avoid widows space parsing prob
            $success = System::mkDir(array('-p', $targetDir));
        } else {
            SGL::raiseError('The modules directory does not appear to be writable, please give the
                webserver permissions to write to it', SGL_ERROR_FILEUNWRITABLE);
            return false;
        }

        //  write new manager to appropriate module
        $targetMgrName = $targetDir . '/' . $output->managerName . 'Mgr.php';
        $success = file_put_contents($targetMgrName, $mgrTemplate);

        if (!$success) {
            SGL::raiseError('There was a problem creating the files', 
                SGL_ERROR_FILEUNWRITABLE);
        } else {
            SGL::raiseMsg('Module files successfully created');
        }
    }

    function _list(&$input, &$output)
    {
        SGL::logMessage(null, PEAR_LOG_DEBUG);
    }

    function _redirectToDefault(&$input, &$output)
    {
        SGL::logMessage(null, PEAR_LOG_DEBUG);

        //  if no errors have occured, redirect
        if (!(count($GLOBALS['_SGL']['ERRORS']))) {
            if (!($this->redirect)) {
                return;
            } else {
                SGL_HTTP::redirect();
            }

        //  else display error with blank template
        } else {
            $output->template = 'docBlank.html';
        }
    }
}

if (!(function_exists('file_put_contents'))) {
    function file_put_contents($location, $data)
    {
        if (file_exists($location)) {
            unlink($location);
        }
        $fileHandler = fopen ($location, "w");
        fwrite ($fileHandler, $data);
        fclose ($fileHandler);
        return true;
    }
}
?>