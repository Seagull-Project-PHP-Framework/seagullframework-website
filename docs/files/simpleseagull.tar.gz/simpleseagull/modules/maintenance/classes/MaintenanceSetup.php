<?php

require_once SGL_CORE_DIR . '/Setup.php';

class MaintenanceSetup extends SGL_Setup
{
    var $removable = false;
    
    var $title = 'Maintenance';
    var $description = 'Maintenance DataObjects and creating new modules';

    function isInstalled()
    {
        return true;
    }
}

?>