<?php

require_once SGL_CORE_DIR . '/Setup.php';

class FaqSetup extends SGL_Setup
{
    var $removable = true;
    var $module = 'faq';
    var $isConfigurable = 1;
    
    var $title = 'FAQ';
    var $description = 'FAQ - Frequently asked questions';
    var $adminUri = 'faq.php?action=listAdmin';

    function isInstalled()
    {
        // first check if record exists in module table
        if(!parent::isInstalled()) {
            return false;
        }
        
        // table faq have to exists in db
        $db =& SGL_DB::singleton();
        $aTables = $db->getListOf('tables');
        if(!in_array('faq', $aTables)) {
            return false;
        }
        
        // entity have to exists
        $faq = DB_DataObject::factory('faq');
        if(PEAR::isError($faq)) {
            return false;
        }
        
        return true;
    }
}

?>