<?php

class SimpleAuth
{
    
}

?>