<?php

require_once SGL_CORE_DIR . '/Setup.php';

class UserSetup extends SGL_Setup
{
    var $removable = true;
    var $module = 'user';
    var $isConfigurable = 0;
    
    var $title = 'User Management';
    var $description = 'Only login at the moment';

    function isInstalled()
    {
        // check if record exists in module table
        if(!parent::isInstalled()) {
            return false;
        }
        return true;
    }
}

?>