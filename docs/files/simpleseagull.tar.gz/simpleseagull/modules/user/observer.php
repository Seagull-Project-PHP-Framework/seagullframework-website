<?php

class SimpleAuth
{
    function checkAuth(&$notification)
    {
        $controller = &$notification->getNotificationObject();
        $conf = & $GLOBALS['_SGL']['CONF'];
        $pageName = SGL::caseFix(get_class($controller->page));
        if(!empty($conf[$pageName]['requiresAuth'])) {
            // check if user is logged
            if(!SGL_HTTP_Session::get('authorized')) {
                // redirect to login page
                SGL_HTTP::redirect('login.php');
            }
        }
    }
}

require_once 'Event/Dispatcher.php';

$dispatcher = &Event_Dispatcher::getInstance('SEAGULL');
$dispatcher->addObserver(array('SimpleAuth', 'checkAuth'), 'sgl_controller::init', 'sgl_controller');

?>