<?php
//    initialise
    require_once '../init.php';
    require_once SGL_CORE_DIR . '/Controller.php';
    require_once SGL_MOD_DIR . '/default/classes/ConfigMgr.php';
    error_log('###############    NEW PAGE RUN - CONFIG MGR ###############');
    $process = & new SGL_Controller();
    $process->page = & new ConfigMgr();
    $process->go();
?>