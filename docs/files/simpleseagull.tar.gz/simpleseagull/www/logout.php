<?php
//    initialise
    require_once '../init.php';
    error_log('###############        NEW PAGE RUN - LOGOUT        ###############');
    require_once SGL_CORE_DIR . '/Controller.php';
    $process = & new SGL_Controller();
    $process->init(new SGL_HTTP_Request());
    //  clean up any cached content that might have changed in blocks
    SGL_HTTP_Session::destroy();
    //  redirect
    SGL::raiseMsg('You have been successfully logged out');
    SGL_HTTP::redirect('login.php');
?>
