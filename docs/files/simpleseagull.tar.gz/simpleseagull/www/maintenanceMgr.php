<?php
//    initialise
    require_once '../init.php';
    require_once SGL_CORE_DIR . '/Controller.php';
    require_once SGL_MOD_DIR . '/maintenance/classes/MaintenanceMgr.php';
    error_log('###############    NEW PAGE RUN - MAINTENANCE MANAGER    ###############');
    $process = & new SGL_Controller();
    $process->page = & new MaintenanceMgr();
    $process->go();
?>