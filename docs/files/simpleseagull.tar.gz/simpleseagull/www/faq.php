<?php
//    initialise
    require_once '../init.php';
    require_once SGL_CORE_DIR . '/Controller.php';
    require_once SGL_MOD_DIR . '/faq/classes/FaqMgr.php';
    error_log('###############    NEW PAGE RUN - FAQ    ###############');
    $process = & new SGL_Controller();
    $process->page = & new FaqMgr();
    $process->go();
?>