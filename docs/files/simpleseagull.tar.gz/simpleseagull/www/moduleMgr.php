<?php
//    initialise
    require_once '../init.php';
    require_once SGL_CORE_DIR . '/Controller.php';
    require_once SGL_MOD_DIR . '/default/classes/ModuleMgr.php';
    error_log('###############    NEW PAGE RUN - MODULE MANAGER    ###############');
    $process = & new SGL_Controller();
    $process->page = & new ModuleMgr();
    $process->go();
?>