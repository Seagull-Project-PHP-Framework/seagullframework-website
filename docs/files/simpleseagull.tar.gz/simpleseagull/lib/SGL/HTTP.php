<?php
/* Reminder: always indent with 4 spaces (no tabs). */
// +---------------------------------------------------------------------------+
// | Copyright (c) 2004, Demian Turner                                         |
// | All rights reserved.                                                      |
// |                                                                           |
// | Redistribution and use in source and binary forms, with or without        |
// | modification, are permitted provided that the following conditions        |
// | are met:                                                                  |
// |                                                                           |
// | o Redistributions of source code must retain the above copyright          |
// |   notice, this list of conditions and the following disclaimer.           |
// | o Redistributions in binary form must reproduce the above copyright       |
// |   notice, this list of conditions and the following disclaimer in the     |
// |   documentation and/or other materials provided with the distribution.    |
// | o The names of the authors may not be used to endorse or promote          |
// |   products derived from this software without specific prior written      |
// |   permission.                                                             |
// |                                                                           |
// | THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       |
// | "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         |
// | LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR     |
// | A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT      |
// | OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     |
// | SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          |
// | LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     |
// | DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     |
// | THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       |
// | (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     |
// | OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      |
// |                                                                           |
// +---------------------------------------------------------------------------+
// | Seagull 0.4                                                               |
// +---------------------------------------------------------------------------+
// | HTTP.php                                                                  |
// +---------------------------------------------------------------------------+
// | Author:   Demian Turner <demian@phpkitchen.com>                           |
// +---------------------------------------------------------------------------+
// $Id: HTTP.php,v 1.22 2005/02/17 03:09:43 demian Exp $

require_once SGL_CORE_DIR . '/Manager.php';
require_once SGL_LIB_DIR . '/SGL.php';

/**
 * Class for HTTP functionality including redirects.
 *
 * @package SGL
 * @author  Demian Turner <demian@phpkitchen.com>
 * @version $Revision: 1.22 $
 * @since   PHP 4.1
 */
class SGL_HTTP
{
    /**
     * Wrapper for PHP header() redirects.
     *
     * Simplified version of Wolfram's HTTP_Header class
     *
     * @access  public
     * @static
     * @param   mixed   $url    target URL
     * @param   array   $param  params to be appended to URL
     * @return  void
     * @author  Wolfram Kriesing <wk@visionp.de>
     */
    function redirect($url = null, $param = false)
    {
        SGL::logMessage(null, PEAR_LOG_DEBUG);
        
        $conf = & $GLOBALS['_SGL']['CONF'];

        //  get a reference to the request object
        $req = & SGL_HTTP_Request::singleton();

        if ($url === null) {
            $url = array_pop(explode('/', $_SERVER['PHP_SELF']));
        }
        //  add some other vars
        if (is_array($param) && count($param)) {
            $aParams = array();
            foreach ($param as $key => $value) {
                if (is_string($key)) {
                    $aParams[] = urlencode($key).'='.urlencode($value);
                }
            }
            $url .= '?' . implode('&', $aParams);
        }
        //  check for absolute uri as specified in RFC 2616
        $aUrl = parse_url($url);
        if (!(isset($aUrl['scheme']))) {
            $url = SGL_BASE_URL . '/' . $url;
        }

        header('Location: ' . $url);
        exit;
    }
}

/**
 * Request wraps all $_GET $_POST $_FILES arrays into a Request object.
 *
 * @package SGL
 * @author  Demian Turner <demian@phpkitchen.com>
 * @version $Revision: 1.22 $
 * @since   PHP 4.1
 */
class SGL_HTTP_Request
{
    /**
     * Sets GET/POST/FILES to gpcVars attribute.
     *
     * @access  public
     * @return  void
     */
    function SGL_HTTP_Request()
    {
        //  merge REQUEST AND FILES superglobal arrays
        $GLOBALS['_SGL']['REQUEST'] = array_merge($_REQUEST, $_FILES);

        //  remove slashes if necessary
        SGL_String::dispelMagicQuotes($GLOBALS['_SGL']['REQUEST']);
    }

    /**
     * Returns a singleton Request instance.
     *
     * example usage: 
     * $req = & SGL_HTTP_Request::singleton();
     * warning: in order to work correctly, the request
     * singleton must be instantiated statically and
     * by reference
     *
     * @access  public
     * @static
     * @return  mixed           reference to Request object
     */
    function &singleton()
    {
        static $instance;

        // If the instance is not there, create one
        if (!isset($instance)) {
            $instance = new SGL_HTTP_Request();
        }
        return $instance;
    }

    /**
     * Retrieves values from Request object.
     *
     * @access  public
     * @param   mixed   $paramName  Request param name
     * @param   boolean $allowTags  If html/php tags are allowed or not
     * @return  mixed               Request param value or null if not exists
     */
    function get($paramName, $allowTags = false)
    {
        $req = & $GLOBALS['_SGL']['REQUEST'];
        if (isset($req[$paramName])) {

            //  if html not allowed, run an enhanced strip_tags()
            if (!$allowTags) {
                SGL_String::clean($req[$paramName]);

            //  if html is allowed, at least remove javascript
            } else {
                SGL_String::removeJs($req[$paramName]);
            }
            return $req[$paramName];
        } else {
            return null;
        }
    }

    /**
     * Set a value for Request object.
     *
     * @access  public
     * @param   mixed   $name   Request param name
     * @param   mixed   $value  Request param value
     * @return  void
     */
    function set($name, $value)
    {
       $GLOBALS['_SGL']['REQUEST'][$name] = $value;
    }

    function debug()
    {
        $GLOBALS['_SGL']['site']['blocksEnabled'] = 0;
        print '<pre>';
        print_r($GLOBALS['_SGL']['REQUEST']);
    }
}

/**
 * Handles session management.
 *
 * @package SGL
 * @author  Demian Turner <demian@phpkitchen.com>
 * @version $Revision: 1.22 $
 * @since   PHP 4.1
 */
class SGL_HTTP_Session
{
    /**
     * Session timeout configurable in preferences.
     *
     * @access  private
     * @var     int
     */
    var $_timeout;

    /**
     * Setup session.
     *
     *  o custimise session name
     *  o configure custom cookie params
     *  o setup session backed, ie, file or DB
     *  o start session
     *  o persist user object in session
     *
     * @access  public
     * @param   int $uid    user id if present
     * @return  void
     */
    function SGL_HTTP_Session()
    {
        SGL::logMessage(null, PEAR_LOG_DEBUG);
        $conf = & $GLOBALS['_SGL']['CONF'];

        //  customise session
        $sessName = isset($conf['cookie']['name']) ? $conf['cookie']['name'] : 'SGLSESSID';
        session_name($sessName);

        //  set session timeout to 0 (until the browser is closed) initially,
        //  then use user timeout in isTimedOut() method
        session_set_cookie_params(
            0, 
            $conf['cookie']['path'],
            $conf['cookie']['domain'],
            $conf['cookie']['secure']);

        session_save_path(SGL_TMP_DIR);
        
        //  start PHP session handler
        @session_start();
        $this->_timeout = $conf['site']['sessionTimeOut'];
        
        $this->_init();
    }

    /**
     * Initialises session, sets some default values.
     *
     * @access  private
     * @param   object  $oUser  user object if present
     * @return  boolean true on successful initialisation
     */
    function _init()
    {
        SGL::logMessage(null, PEAR_LOG_DEBUG);

        //  set secure session key
        $startTime = mktime();
        $acceptLang = @$_SERVER['HTTP_ACCEPT_LANGUAGE'];
        $userAgent = $_SERVER['HTTP_USER_AGENT'];

        //  initialise session with some default values
        $aSessVars = array(
            'startTime'         => $startTime,
            'lastRefreshed'     => $startTime,
            'key'               => md5($startTime . $acceptLang . $userAgent),
        );
        //  set vars in session
        if (isset($_SESSION)) {
            foreach ($aSessVars as $k => $v) {
                $_SESSION[$k] = $v;
            }
        }
        
        if(!isset($_SESSION['aPrefs'])) {
            $conf = &$GLOBALS['_SGL']['CONF'];
            foreach($conf['preferences'] as $prefName => $prefValue) {
                $_SESSION['aPrefs'][$prefName] = $prefValue;
            }
        }

        //  make session more secure if possible
        if  (function_exists('session_regenerate_id')) {
            session_regenerate_id();
        }
        return true;
    }

    /**
     * Determines whether a session currently exists.
     *
     * @access  public
     * @static
     * @return  boolean true if session exists and has 1 or more elements
     */
    function exists()
    {
        SGL::logMessage(null, PEAR_LOG_DEBUG);
        return isset($_SESSION) && count($_SESSION);
    }

    /**
     * Determines whether the current session is valid.
     *
     * @access  public
     * @static
     * @return  boolean true if session is valid
     */
    function isValid()
    {
        SGL::logMessage(null, PEAR_LOG_DEBUG);
        $acceptLang = @$_SERVER['HTTP_ACCEPT_LANGUAGE'];
        $userAgent = $_SERVER['HTTP_USER_AGENT'];
        $currentKey = md5($_SESSION['username'] . $_SESSION['startTime'] . 
            $acceptLang . $userAgent);

        //  compare actual key with session key, and that UID is not 0 (guest)
        return  ($currentKey == $_SESSION['key']) && $_SESSION['uid'];
    }

    /**
     * Determines whether the current session is timed out.
     *
     * @access  public
     * @return  boolean true if session is timed out
     */
    function isTimedOut()
     {
        SGL::logMessage(null, PEAR_LOG_DEBUG);

        //  check for session timeout
        $currentTime = mktime();
        $lastPageRefreshTime = $_SESSION['lastRefreshed'];
        if ($currentTime - $lastPageRefreshTime > $this->_timeout) {
            return true;
        } else {
            $_SESSION['lastRefreshed'] = mktime();
            return false;
        }
    }

    /**
     * Removes specified var from session.
     *
     * @access  public
     * @static
     * @param   string  $sessVarName   name of session var
     * @return  boolean
     */
    function remove($sessVarName)
    {
        SGL::logMessage(null, PEAR_LOG_DEBUG);
        if (isset($_SESSION[$sessVarName])) {
            unset($_SESSION[$sessVarName]);
            return true;
        } else {
            return false;
        }
    }

    /**
     * Gets specified var from session.
     *
     * @access  public
     * @static
     * @param   string  $sessVarName    name of session var
     * @return  string                  value of session variable
     */
    function get($sessVarName)
    {
        if (isset($sessVarName)) {
            return is_array($_SESSION) 
                ? (array_key_exists($sessVarName, $_SESSION) ? $_SESSION[$sessVarName] : '')
                : ''; 
        }
    }

    /**
     * Sets specified var in session.
     *
     * @access  public
     * @static
     * @param   string  $sessVarName   name of session var
     * @param   mixed   $sessVarValue  value of session var
     * @return  void
     */
    function set($sessVarName, $sessVarValue)
    {
        $_SESSION[$sessVarName] = $sessVarValue;
    }

    /**
     * Dumps session contents.
     *
     * @access  public
     * @static
     * @return  void
     */
    function debug()
    {
        SGL::logMessage(null, PEAR_LOG_DEBUG);
        $ret = '';
        foreach ($_SESSION as $sessVarName => $sessVarValue) {
            $ret .= "$sessVarName => $sessVarValue<br />\n";
        }
        return $ret;
    }

    /**
     * Destroys current session.
     *
     * @access  public
     * @static
     * @return  void
     */
    function destroy()
    {
        SGL::logMessage(null, PEAR_LOG_DEBUG);

        $conf = & $GLOBALS['_SGL']['CONF'];

        foreach ($_SESSION as $sessVarName => $sessVarValue) {
            if (isset($_SESSION)) {
                unset($sessVarName);
            }
        }
        session_destroy();
        $_SESSION = array();

        //  clear session cookie so theme comes from DB and not session
        setcookie(  $conf['cookie']['name'], null, 0, $conf['cookie']['path'], 
                    $conf['cookie']['domain'], $conf['cookie']['secure']);

        $sess = & new SGL_HTTP_Session();
    }

}
?>