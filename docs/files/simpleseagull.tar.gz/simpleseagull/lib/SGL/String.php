<?php
/* Reminder: always indent with 4 spaces (no tabs). */
// +---------------------------------------------------------------------------+
// | Copyright (c) 2004, Demian Turner                                         |
// | All rights reserved.                                                      |
// |                                                                           |
// | Redistribution and use in source and binary forms, with or without        |
// | modification, are permitted provided that the following conditions        |
// | are met:                                                                  |
// |                                                                           |
// | o Redistributions of source code must retain the above copyright          |
// |   notice, this list of conditions and the following disclaimer.           |
// | o Redistributions in binary form must reproduce the above copyright       |
// |   notice, this list of conditions and the following disclaimer in the     |
// |   documentation and/or other materials provided with the distribution.    |
// | o The names of the authors may not be used to endorse or promote          |
// |   products derived from this software without specific prior written      |
// |   permission.                                                             |
// |                                                                           |
// | THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       |
// | "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         |
// | LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR     |
// | A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT      |
// | OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     |
// | SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          |
// | LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     |
// | DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     |
// | THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       |
// | (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     |
// | OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      |
// |                                                                           |
// +---------------------------------------------------------------------------+
// | Seagull 0.4                                                               |
// +---------------------------------------------------------------------------+
// | String.php                                                                |
// +---------------------------------------------------------------------------+
// | Author:   Demian Turner <demian@phpkitchen.com>                           |
// +---------------------------------------------------------------------------+
// $Id: String.php,v 1.5 2005/01/29 11:34:28 demian Exp $

/**
 * Various string related methods.
 *
 * @package SGL
 * @author  Demian Turner <demian@phpkitchen.com>
 * @version $Revision: 1.5 $
 * @since   PHP 4.1
 */
class SGL_String
{

    /**
     * Trim all the variables in the given array
     *
     * @static 
     * @access  public
     * @param   array  Array with variables to trim
     * @return  array  Array with "trimmed" variables
     * @author  Chuck Hagenbuch <chuck@horde.org>
     */
    function trimWhitespace(&$var)
    {
        if (!is_array($var)) {
            $var = trim($var);
        } else {
            array_walk($var, array('SGL_String', 'trimWhitespace'));
        }
        return $var;
    }

    /**
     * If magic_quotes_gpc is in use, run stripslashes() on $var.
     *
     * @access  public
     * @param   string $var  The string to un-quote, if necessary.
     * @return  string       $var, minus any magic quotes.
     * @author  Chuck Hagenbuch <chuck@horde.org>
     */
    function dispelMagicQuotes(&$var)
    {
        static $magicQuotes;
        if (!isset($magicQuotes)) {
            $magicQuotes = get_magic_quotes_gpc();
        }
        if ($magicQuotes) {
            if (!is_array($var)) {
                $var = stripslashes($var);
            } else {
                array_walk($var, array('SGL_String', 'dispelMagicQuotes'));
            }
        }
    }

    /**
     * Returns cleaned user input.
     *
     * Instead of addslashing potential ' and " chars, let's remove them and get 
     * rid of any magic quoting which is enabled by default.  Also removes any 
     * html tags and ASCII zeros
     *
     * @access  public
     * @param   string $var  The string to clean.
     * @return  string       $cleaned result.
     */
    function clean(&$var)
    {
        if (isset($var)) {
            if (!is_array($var)) {
                $var = strip_tags($var);
            } else {
                array_walk($var, array('SGL_String', 'clean'));
            }
        }
        SGL_String::trimWhitespace($var);
    }

    /**
     * Remove all the javascript sections from given string
     *
     * @static 
     * @access  public
     * @param   string $var  The string to clean.
     * @return  string       $cleaned result.
     */
    function removeJs(&$html)
    {
        SGL::logMessage(null, PEAR_LOG_DEBUG);
        $search = "/<script[^>]*?>.*?<\/script>/i";
        $replace = '';
        $html = preg_replace($search, $replace, $html);
        SGL_String::trimWhitespace($html);
    }

    /**
     * Return an obfuscated string (very useful for emails addresses)
     *
     * @static 
     * @param string $str  String to obfuscate
     * @return string      Obfuscated string (eg: email)
     */
    function obfuscate($str)
    {
        $encoded = bin2hex($str);
        $encoded = chunk_split($encoded, 2, '%');
        $encoded = '%' . substr($encoded, 0, strlen($encoded) - 1);
        return $encoded;
    }

    /**
     * Returns a shortened version of text string.
     *
     * @access  public
     * @param   string  $str    Text to be shortened
     * @param   integer $limit  Number of characters to cut to
     * @param   string  $appendString  Trailing string to be appended
     * @return  string  $processedString    Correctly shortened text
     * @author  Lukas Feiler <lukas.feiler@endlos.at>
     */
    function summarise($str, $limit=50, $appendString=' ...')
    {
         if (strlen($str) > $limit) {
            $str = substr($str, 0, $limit) . $appendString;
         }
         return $str;
    }

    //  from http://kalsey.com/2004/07/dirify_in_php/
    function dirify($s)
    {
         $s = SGL_String::convert_high_ascii($s);   ## convert high-ASCII chars to 7bit.
         $s = strtolower($s);                       ## lower-case.
         $s = strip_tags($s);                       ## remove HTML tags.
         $s = preg_replace('!&[^;\s]+;!','',$s);    ## remove HTML entities.
         $s = preg_replace('![^\w\s]!','',$s);      ## remove non-word/space chars.
         $s = preg_replace('!\s+!','_',$s);         ## change space chars to underscores.
         return $s;    
    }

    function convert_high_ascii($s)
    {
     	$HighASCII = array(
     		"!\xc0!" => 'A',    # A`
     		"!\xe0!" => 'a',    # a`
     		"!\xc1!" => 'A',    # A'
     		"!\xe1!" => 'a',    # a'
     		"!\xc2!" => 'A',    # A^
     		"!\xe2!" => 'a',    # a^
     		"!\xc4!" => 'Ae',   # A:
     		"!\xe4!" => 'ae',   # a:
     		"!\xc3!" => 'A',    # A~
     		"!\xe3!" => 'a',    # a~
     		"!\xc8!" => 'E',    # E`
     		"!\xe8!" => 'e',    # e`
     		"!\xc9!" => 'E',    # E'
     		"!\xe9!" => 'e',    # e'
     		"!\xca!" => 'E',    # E^
     		"!\xea!" => 'e',    # e^
     		"!\xcb!" => 'Ee',   # E:
     		"!\xeb!" => 'ee',   # e:
     		"!\xcc!" => 'I',    # I`
     		"!\xec!" => 'i',    # i`
     		"!\xcd!" => 'I',    # I'
     		"!\xed!" => 'i',    # i'
     		"!\xce!" => 'I',    # I^
     		"!\xee!" => 'i',    # i^
     		"!\xcf!" => 'Ie',   # I:
     		"!\xef!" => 'ie',   # i:
     		"!\xd2!" => 'O',    # O`
     		"!\xf2!" => 'o',    # o`
     		"!\xd3!" => 'O',    # O'
     		"!\xf3!" => 'o',    # o'
     		"!\xd4!" => 'O',    # O^
     		"!\xf4!" => 'o',    # o^
     		"!\xd6!" => 'Oe',   # O:
     		"!\xf6!" => 'oe',   # o:
     		"!\xd5!" => 'O',    # O~
     		"!\xf5!" => 'o',    # o~
     		"!\xd8!" => 'Oe',   # O/
     		"!\xf8!" => 'oe',   # o/
     		"!\xd9!" => 'U',    # U`
     		"!\xf9!" => 'u',    # u`
     		"!\xda!" => 'U',    # U'
     		"!\xfa!" => 'u',    # u'
     		"!\xdb!" => 'U',    # U^
     		"!\xfb!" => 'u',    # u^
     		"!\xdc!" => 'Ue',   # U:
     		"!\xfc!" => 'ue',   # u:
     		"!\xc7!" => 'C',    # ,C
     		"!\xe7!" => 'c',    # ,c
     		"!\xd1!" => 'N',    # N~
     		"!\xf1!" => 'n',    # n~
     		"!\xdf!" => 'ss'
     	);
     	$find = array_keys($HighASCII);
     	$replace = array_values($HighASCII);
     	$s = preg_replace($find,$replace,$s);
         return $s;
    }
}

/**
 * Various date related methods.
 *
 * @package SGL
 * @author  Demian Turner <demian@phpkitchen.com>
 * @version $Revision: 1.5 $
 * @since   PHP 4.1
 */
class SGL_Date
{
    /**
     * Converts date array into MySQL datetime format.
     *
     * @access  public
     * @param   array   $aDate
     * @return  string  MySQL datetime format
     * @see     publisher::ArticleMgr::process/edit
     */
    function arrayToString($aDate)
    {
        SGL::logMessage(null, PEAR_LOG_DEBUG);
        if (is_array($aDate)) {
            $month  = $aDate['month'];
            $day    = $aDate['day'];
            $year   = $aDate['year'];
            $hour   = (array_key_exists('hour',$aDate))? $aDate['hour'] : '00';
            $minute = (array_key_exists('minute',$aDate))? $aDate['minute'] : '00';
            $second = (array_key_exists('second',$aDate))? $aDate['second'] : '00';
            return $year . '-' . $month . '-' . $day .' ' . $hour . ':' . $minute . ':' . $second;
        }
    }

    /**
     * Converts date into date array.
     *
     * @access  public
     * @param   string  $sDate date (may be in the ISO, TIMESTAMP or UNIXTIME format) format
     * @return  array   $aDate
     * @see     publisher::ArticleMgr::process/edit
     */
    function stringToArray($sDate)
    {
        SGL::logMessage(null, PEAR_LOG_DEBUG);
        if (is_scalar($sDate)) {
            include_once 'Date.php';
            $date = & new Date($sDate);
            $aDate =      array('day'    => $date->getDay(),
                                'month'  => $date->getMonth(),
                                'year'   => $date->getYear(),
                                'hour'   => $date->getHour(),
                                'minute' => $date->getMinute(),
                                'second' => $date->getSecond());
            return $aDate;
        }
    }

    /**
     * Converts date (may be in the ISO, TIMESTAMP or UNIXTIME format) into dd.mm.yyyy.
     *
     * @access  public
     * @param   string  $input  date (may be in the ISO, TIMESTAMP or UNIXTIME format) value
     * @return  string  $output user-friendly format (european)
     */
    function format($date)
    {
        if (is_string($date)) {
            include_once 'Date.php';
            $date = & new Date($date);
            if ($_SESSION['aPrefs']['dateFormat'] == 'UK') {
                $output = $date->format('%d/%m/%Y');
            } else {
                //  else display US format, MM.DD.YYYY
                $output = $date->format('%m.%d.%Y');
            }
            return $output;
        } else {
            SGL::raiseError('no input date passed to SGL_Date::format incorrect type',
                SGL_ERROR_INVALIDARGS);
        }
    }
}
?>