<?php
/* Reminder: always indent with 4 spaces (no tabs). */
// +---------------------------------------------------------------------------+
// | Copyright (c) 2004, Demian Turner                                         |
// | All rights reserved.                                                      |
// |                                                                           |
// | Redistribution and use in source and binary forms, with or without        |
// | modification, are permitted provided that the following conditions        |
// | are met:                                                                  |
// |                                                                           |
// | o Redistributions of source code must retain the above copyright          |
// |   notice, this list of conditions and the following disclaimer.           |
// | o Redistributions in binary form must reproduce the above copyright       |
// |   notice, this list of conditions and the following disclaimer in the     |
// |   documentation and/or other materials provided with the distribution.    |
// | o The names of the authors may not be used to endorse or promote          |
// |   products derived from this software without specific prior written      |
// |   permission.                                                             |
// |                                                                           |
// | THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       |
// | "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         |
// | LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR     |
// | A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT      |
// | OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     |
// | SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          |
// | LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     |
// | DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     |
// | THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       |
// | (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     |
// | OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      |
// |                                                                           |
// +---------------------------------------------------------------------------+
// | Seagull 0.4                                                               |
// +---------------------------------------------------------------------------+
// | Controller.php                                                            |
// +---------------------------------------------------------------------------+
// | Author:   Demian Turner <demian@phpkitchen.com>                           |
// +---------------------------------------------------------------------------+
// $Id: Controller.php,v 1.23 2005/02/14 15:35:15 demian Exp $

require_once SGL_LIB_DIR . '/SGL.php';
require_once SGL_CORE_DIR . '/Manager.php'; 
require_once SGL_CORE_DIR . '/Output.php';
require_once SGL_CORE_DIR . '/String.php';
require_once 'HTML/Template/Flexy.php';

/**
 * Single generic controller class for all model objects.
 *
 * @package SGL
 * @author  Demian Turner <demian@phpkitchen.com>
 * @version $Revision: 1.23 $
 * @since   PHP 4.1
 */
class SGL_Controller
{
    /**
     * Timer object for benchmarking.
     *
     * @access  public
     * @var     object
     */
    var $timer = null;

    /**
     * Model object passed in from start file, corresponds
     * to one of the module's manager classes.
     *
     * @access  public
     * @var     object
     */
    var $page = null;

    var $conf = array();

    /**
     * Constructor.
     *
     * @access  public
     * @return  void
     */
    function SGL_Controller()
    {
        //  pre PHP 4.3.x workaround
        if (!defined('__CLASS__')) {
            define('__CLASS__', null);
        }
        SGL::logMessage(null, PEAR_LOG_DEBUG);

        //  start session and output buffering
        $this->conf = & $GLOBALS['_SGL']['CONF'];
        if ($this->conf['site']['outputBuffering']) {
            ob_start();
        }
        //  starts session for page execution
        if (!is_writable(SGL_TMP_DIR)) {
            SGL::raiseError('The tmp directory does not appear to be writable, please give the
                            webserver permissions to write to it', SGL_ERROR_FILEUNWRITABLE, PEAR_ERROR_DIE);
        }
    }

    /**
     * Runs the application - main starting point for workflow.
     *
     *  Workflow as follows:
     *  o starts timer
     *  o session & language initialisation and access-control check
     *  o creates output object to which all output properties are added
     *  o initiates validation of request data
     *  o if request is valid, output is sent to process with inherited input
     *  o if not, output is sent to display
     *
     * @access  public
     * @return  void
     */
    function go()
    {
        SGL::logMessage(null, PEAR_LOG_DEBUG);
        
        // check if module is installed
        if(!SGL_Controller::isInstalled($this->page->module)) {
            SGL::raiseError('Module is not installed, exiting..', SGL_ERROR_INVALIDCALL, PEAR_ERROR_DIE);
        }

        //  get a reference to the request object
        $req = & SGL_HTTP_Request::singleton();

        //  do general session & language initialisation and access-control check
        $this->init();

        //  setup input/output objects
        $input = & new SGL_Output();
        
        //  validate the information posted from the browser
        $this->page->validate($req, $input);

        //  make a copy of $input for process
        $output = clone($input);

        //  if input is valid, copy data members from input to output
        //  and send to be processed
        if ($this->page->validated) {
            //  process the input, do workflow and add properties to output object
            $this->page->process($input, $output);
            $this->_displayPage($output);
        } else {
            //  otherwise, input validation failed, so input object 
            //  contains page data for try-again
            $this->_displayPage($input);
        }
    }
    
    /**
     * Method is checking if the module is installed
     *
     * @static 
     * @param string $moduleName  The name of the module to check
     * @return bool               True if record is not empty in modules.ini file else false
     */ 
    function isInstalled($moduleName)
    {
        static $modulesConf;
        if(isset($modulesConf)) {
            return !empty($modulesConf[$moduleName]) ? $modulesConf[$moduleName] : false;
        }
        // read events
        $path = SGL_PATH . '/var/modules.ini';
        $modules = $this->getConfigFile($path);
        $modulesConf = & $modules['modules'];
        
        return !empty($modulesConf[$moduleName]) ? $modulesConf[$moduleName] : false;
    }

    /**
     * Session & language initialisation and access-control check.
     *
     * @access  public
     * @param   object  $req    Request object
     * @return  void
     */
    function init()
    {
        SGL::logMessage(null, PEAR_LOG_DEBUG);

        //  get a reference to the request object
        $req = & SGL_HTTP_Request::singleton();

        $this->_initConfig();

        //  setup session
        $this->session = & new SGL_HTTP_Session();

        //  start clock 
        if ((bool)$_SESSION['aPrefs']['showExecutionTimes']) {
            include_once 'Benchmark/Timer.php';
            $this->timer = & new Benchmark_Timer();
            $this->timer->start();
        }
        $this->_setHeaders();
        $this->_setLocale();

        //  set debug session if allowed
        $debug = $req->get('debug');
        if ($debug && SGL::debugAllowed()) {
            $debug = ($debug == 'on') ? 1 : 0;
            SGL_HTTP_Session::set('debug', $debug);
        }
        
        SGL::makeEvent($this, 'init');
    }

    /**
     * Merges global Seagull and module config arrays.
     *
     * @access  private
     * @param   string  $moduleName    name of current module
     * @return  void
     */
    function _initConfig($moduleName = null)
    {
        SGL::logMessage(null, PEAR_LOG_DEBUG);

        //  ensure controller page attribute is a model object
        if (!is_object($this->page)) {
            SGL::raiseError('Please that controller has a model object', SGL_ERROR_NOCLASS, PEAR_ERROR_DIE);
        }
        //  parse mod config if exists
        $module = ($moduleName === null) ? $this->page->module : $moduleName;
        $path = SGL_MOD_DIR . '/' . $module . '/';
        $conf = $this->getConfigFile($path . 'conf.ini');
        //  merge module config with global config loaded in init.php
        if($conf) {
            $GLOBALS['_SGL']['CONF'] = array_merge_recursive($conf, $GLOBALS['_SGL']['CONF']);
        }

        // read events
        $path = SGL_PATH . '/var/events.conf.ini';
        $conf = $this->getConfigFile($path);
        if($conf) {
            $GLOBALS['_SGL']['CONF'] = array_merge_recursive($conf, $GLOBALS['_SGL']['CONF']);
        }
    }
    
    function getConfigFile($path)
    {
       if (is_readable($path)) {
            return parse_ini_file($path, true);
        } else {
            SGL::raiseError('Could not open module\'s '.$path.'.conf.ini file from ' .  
                __CLASS__ . '::' . __FUNCTION__, SGL_ERROR_NOFILE);
            return false;
        }
    }

    /**
     * Sets generic headers for page generation.
     *
     * Alternatively, headers can be suppressed if specified in module's config.
     *
     * @access  private
     * @return  void
     */
    function _setHeaders()
    {
        SGL::logMessage(null, PEAR_LOG_DEBUG);

        //  don't send headers according to config
        $currentMgr = SGL::caseFix(get_class($this->page));
        if (isset( $this->conf[$currentMgr]['setHeaders'])
                && $this->conf[$currentMgr]['setHeaders'] == false) {
            return false;
        }
        //  set compression as specified in init, can only be done here :-)
        @ini_set('zlib.output_compression', (int)$this->conf['site']['compression']);
        
        //  prepare headers during setup, can be overridden later
        header('Last-Modified: ' . gmdate("D, d M Y H:i:s") . ' GMT');
        header('Content-Type: text/html; charset="en-iso-8859-15"');
        header('X-Powered-By: Seagull ' . SGL_VERSION);
        return true;
    }

    /**
     * Sets current locale.
     *
     * @access  private
     * @return  void
     */
    function _setLocale()
    {
        SGL::logMessage(null, PEAR_LOG_DEBUG);
        
        $conf = & $GLOBALS['_SGL']['CONF'];
        $locale = $conf['preferences']['locale'];
        if (setlocale(LC_ALL, $locale) === false) {
            setlocale(LC_TIME, $locale);
        }
        @putenv('TZ=' . $locale);
        return true;
    }

    /**
     * Sends processed input to template engine.
     *
     *      o sends input to specified page/model display method
     *      o loads navigation driver and renders page navigation
     *      o renders page left/right blocks
     *      o adds generic info to output, required by templates
     *      o stops execution timer
     *      o sends final output data to template engine
     *
     * @access  private
     * @param   object  $input  processed data from process()
     * @return  void
     */
    function _displayPage(&$output)
    {
        SGL::logMessage(null, PEAR_LOG_DEBUG);

        //  process manager's display method
        $this->page->display($output);

        //  stop clock execution time
        if ($_SESSION['aPrefs']['showExecutionTimes']) {
            $this->timer->stop();
            $output->executionTime   = $this->timer->timeElapsed();
            $output->showTimes       = true;
        }
        //  send sitewide variables to page output
        $output->siteName         = $this->conf['site']['name'];
        $output->moduleName       = $this->page->module;
        $output->currUrl          = $_SERVER['PHP_SELF'];
        $output->theme            = $theme = $_SESSION['aPrefs']['theme'];
        $output->webRoot          = SGL_BASE_URL;
        $output->imagesDir        = SGL_BASE_URL . '/themes/' . $theme . '/images';
        $output->versionAPI       = SGL_VERSION;
        $output->sessID           = SID;
        $output->scriptOpen       = "\n<script type=\"text/javascript\"> <!--\n";
        $output->scriptClose      = "\n//--> </script>\n";

        //  get all html onLoad events
        $output->onLoad = $output->getAllOnLoadEvents();

        //  initialise template engine
        $options = &PEAR::getStaticProperty('HTML_Template_Flexy','options');
        $options = array(
            'templateDir'       =>  SGL_THEME_DIR . '/' . $theme . '/' . $this->page->module . PATH_SEPARATOR .
                                    SGL_THEME_DIR . '/default/' . $this->page->module . PATH_SEPARATOR .
                                    SGL_THEME_DIR . '/' . $theme . '/default'. PATH_SEPARATOR .
                                    SGL_THEME_DIR . '/default/default',
            'templateDirOrder'  => 'reverse',
            'multiSource'       => true,
            'compileDir'        => SGL_CACHE_DIR . '/tmpl/' . $theme,
            'forceCompile'      => SGL_FLEXY_FORCE_COMPILE,
            'debug'             => SGL_FLEXY_DEBUG,
            'allowPHP'          => SGL_FLEXY_ALLOW_PHP,
            'filters'           => SGL_FLEXY_FILTERS,
            'locale'            => SGL_FLEXY_LOCALE,
            'compiler'          => SGL_FLEXY_COMPILER,
            'valid_functions'   => SGL_FLEXY_VALID_FNS,
            'flexyIgnore'       => SGL_FLEXY_IGNORE,
            'globals'           => true,
            'globalfunctions'   => SGL_FLEXY_GLOBAL_FNS,
        );

        // Configure Flexy to use SGL ModuleOutput Plugin 
        // If an Output.php file exists in module's dir
        $customOutput = SGL_MOD_DIR . '/' . $this->page->module . '/classes/Output.php';
        if (is_readable($customOutput)) {
            $className = ucfirst($this->page->module) . 'Output';
            if (isset($options['plugins'])) {
                $options['plugins'] = $options['plugins'] + array($className => $customOutput);
            } else {
                $options['plugins'] = array($className => $customOutput);
            }
        }

        //  suppress notices in templates
        $GLOBALS['_SGL']['ERROR_OVERRIDE'] = true;
        $templ = & new HTML_Template_Flexy();
        $templ->compile($output->masterTemplate);

        //  if some Flexy 'elements' exist in the output object, send them as
        //  2nd arg to Flexy::bufferedOutputObject()
        $elements = (   isset($output->flexyElements) && 
                        is_array($output->flexyElements))
                ? $output->flexyElements 
                : array();

        //  send memory consumption to output
        if (SGL_PROFILING_ENABLED && function_exists('memory_get_usage')) {
            $output->memoryUsage = number_format(memory_get_usage());
        }

        $data = $templ->bufferedOutputObject($output, $elements);

        $GLOBALS['_SGL']['ERROR_OVERRIDE'] = false;
        unset($input, $output);
        
        echo $data;
        
        if ($this->conf['site']['outputBuffering']) {
            ob_end_flush();
        }
    }
}
?>