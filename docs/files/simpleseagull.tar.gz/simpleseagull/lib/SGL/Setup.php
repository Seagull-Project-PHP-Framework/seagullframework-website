<?php

require_once 'DB/DataObject.php';

class SGL_Setup
{
    var $removable;
    var $module;
    var $isConfigurable;
    var $adminUri;
    var $title;
    var $description;

    function isInstalled()
    {
        if(empty($this->module)) {
            SGL::raiseError('You have to specify the module name', SGL_ERROR_NODATA);
            return false;
        }
        // first check if record exists in module table
        $module = DB_DataObject::factory('module');
        $module->name = $this->module;
        return $module->count();
    }
    
    /**
     * This method execute sql files in database (install files and uninstall ones)
     *
     * @param string $type  install|uninstall
     * @param array  $files The array of files to execute
     * @return bool         True on success else false
     *
     */
    function runSql($type = 'install', $files = array())
    {
        require_once SGL_CORE_DIR . '/Sql.php';
        
        if(empty($files)) {
            $conf = & $GLOBALS['_SGL']['CONF'];
            // get the default
            if($type == 'install') {
                switch ($conf['db']['type']) {
                    // mysql
                    case 'mysql':
                        $dbType = 'mysql';
                        $files = array('schema.my.sql', 'data.default.my.sql', 'constraints.my.sql');
                        break;
                    default:
                        return false;
                }
            } else {
                switch ($conf['db']['type']) {
                    // mysql
                    case 'mysql':
                        $dbType = 'mysql';
                        $files = array('uninstall.my.sql');
                        break;
                    default:
                        return false;
                }
            }
        }
        foreach($files as $filename) {
            $sglPath = SGL_MOD_DIR . '/' . $this->module . '/data/' . $filename;
            if(file_exists($sglPath)) {
                $result = SGL_Sql::parseAndExecute($sglPath, 0);
                if (DB::isError($result)) {
                    SGL::raiseError('There is problem with creating the sql schema', SGL_ERROR_DBFAILURE);
                    return false;
                }
            }
        }
        return true;
    }
    
    function install()
    {
        // add schema and default data
        if(!$this->runSql('install')) {
            return false;
        }
        
        // regenerate entities
        SGL_Sql::generateDataObjectEntities();
        
        // add record to module table
        $module = DB_DataObject::factory('module');
        $module->name            = $this->module;
        $module->description     = $this->description;
        $module->title           = $this->title;
        $module->is_configurable = $this->isConfigurable;
        $module->admin_uri       = $this->adminUri;
        $ret = $module->insert();
        
        // give time to dataobjects and other stuff
        sleep(3);
        
        return $ret;
    }
    
    function uninstall()
    {
        // remove schema
        if(!$this->runSql('uninstall')) {
            return false;
        }
        
        // regenerate entities
        SGL_Sql::generateDataObjectEntities();
        
        // remove record from module table
        // add record to module table
        $module = DB_DataObject::factory('module');
        $module->get($this->module);
        $ret = $module->delete();
        
        // give time to dataobjects and other stuff
        sleep(3);

        return $ret;
    }
}

?>