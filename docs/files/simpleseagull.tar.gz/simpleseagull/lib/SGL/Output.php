<?php
/* Reminder: always indent with 4 spaces (no tabs). */
// +---------------------------------------------------------------------------+
// | Copyright (c) 2004, Demian Turner                                         |
// | All rights reserved.                                                      |
// |                                                                           |
// | Redistribution and use in source and binary forms, with or without        |
// | modification, are permitted provided that the following conditions        |
// | are met:                                                                  |
// |                                                                           |
// | o Redistributions of source code must retain the above copyright          |
// |   notice, this list of conditions and the following disclaimer.           |
// | o Redistributions in binary form must reproduce the above copyright       |
// |   notice, this list of conditions and the following disclaimer in the     |
// |   documentation and/or other materials provided with the distribution.    |
// | o The names of the authors may not be used to endorse or promote          |
// |   products derived from this software without specific prior written      |
// |   permission.                                                             |
// |                                                                           |
// | THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       |
// | "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         |
// | LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR     |
// | A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT      |
// | OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     |
// | SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          |
// | LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     |
// | DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     |
// | THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       |
// | (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     |
// | OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      |
// |                                                                           |
// +---------------------------------------------------------------------------+
// | Seagull 0.4                                                               |
// +---------------------------------------------------------------------------+
// | Output.php                                                                |
// +---------------------------------------------------------------------------+
// | Author:   Demian Turner <demian@phpkitchen.com>                           |
// +---------------------------------------------------------------------------+
// $Id: Output.php,v 1.14 2005/01/27 12:33:45 demian Exp $

/**
 * High level HTML transform methods. All of them can be used in flexy templates
 *
 * @package SGL
 * @author  Demian Turner <demian@phpkitchen.com>
 * @version $Revision: 1.14 $
 * @since   PHP 4.1
 * @todo    look at PEAR::Date to improve various date methods used here
 */
class SGL_Output
{
    var $onLoad = '';
    var $aOnLoadEvents = array();

    /**
     * Generates options for an HTML select object.
     *
     * @access  public
     * @param   array   $array      hash of select values
     * @param   mixed   $selected   default selected element, array for multiple elements
     * @param   boolean $multiple   true if multiple
     * @return  string  select options
     */
    function generateSelect($aValues, $selected = null, $multiple = false)
    {
        SGL::logMessage(null, PEAR_LOG_DEBUG);
        if (!is_array($aValues)) {
            SGL::raiseError('Incorrect param passed to ' . __CLASS__ . '::' .
                __FUNCTION__, SGL_ERROR_INVALIDARGS);
        }
        if (is_numeric($selected)) {
            $selected = (int) $selected;
        }
        $r = '';
        if ($multiple && is_array($selected)) {
            foreach ($aValues as $k => $v) {
                $isSelected = in_array($k, $selected) ? ' selected="selected"' : '';
                $r .= "\n<option value=\"$k\"" . $isSelected . ">$v</option>";
            }
        } else {
            //  ensure $selected is not the default null arg, allowing
            //  zeros to be selected array elements
            $r = '';
            foreach ($aValues as $k => $v) {
                $isSelected = ($k === $selected && !is_null($selected)) ? ' selected="selected"' : '';
                $r .= "\n<option value=\"$k\"". $isSelected .">$v</option>";
            }
        }
        return $r;
    }

    /**
     * Generates sequence checkboxes.
     *
     * @access  public
     * @param   array   $hElements  hash of checkbox values
     * @param   array   $aChecked   array of checked elements
     * @param   string  $groupName  usually an array name that will contain all elements
     * @return  string  html        list of checkboxes
     */
    function generateCheckboxList($hElements, $aChecked, $groupName)
    {
        SGL::logMessage(null, PEAR_LOG_DEBUG);
        if (!is_array($hElements) || !is_array($aChecked)) {
            SGL::raiseError('incorrect args passed to ' . __FILE__ . ',' . __LINE__,
                SGL_ERROR_INVALIDARGS);
            return false;
        }
        $html = '';
        foreach ($hElements as $k => $v) {
            $isChecked = (in_array($k, $aChecked)) ? ' checked' : '';
            $html .= "<input class='noBorder' type='checkbox' name='$groupName' " .
                     "id='$groupName-$k' value='$k' $isChecked><label for='$groupName-$k'>$v</label><br />\n";
        }
        return $html;
    }

    /**
     * Generate checkbox
     *
     * @access  public
     * @param   string   $name       element name
     * @param   string   $value      element value
     * @param   boolean  $checked    is checked
     * @return  string  html         checkbox tag w/label
     */
    function generateCheckbox($name, $value, $checked)
    {
        SGL::logMessage(null, PEAR_LOG_DEBUG);
        $isChecked = $checked ? ' checked' : '';
        $html = "<input class='noBorder' type='checkbox' name='$name' " .
            "id='$name' value='$value' $isChecked><label for='$name'>$value</label><br />\n";
        return $html;
    }
    
    function generateRadioPair($radioName, $checked)
    {
        SGL::logMessage(null, PEAR_LOG_DEBUG);
        $radioString = '';
        if ($checked) {
            $yesChecked = ' checked';
            $noChecked = '';
        } else {
            $yesChecked = '';
            $noChecked = ' checked';
        }
        $radioString .= "<input type='radio' name='$radioName' value='0' $noChecked>no\n";
        $radioString .= "<input type='radio' name='$radioName' value='1' $yesChecked>yes\n";
        return $radioString;
    }

    // +---------------------------------------+
    // | Date related methods                  |
    // +---------------------------------------+

    /**
     * Converts date (may be in the ISO, TIMESTAMP or UNIXTIME format) into dd.mm.yyyy.
     *
     * @access  public
     * @param   string  $input  date (may be in the ISO, TIMESTAMP or UNIXTIME format) value
     * @return  string  $output user-friendly format (european)
     */
    function formatDate($date)
    {
        return SGL_Date::format($date);
    }

    /**
     * Substring the given string (if the given string is longer than limit) and add to it
     * the $appendString
     *
     * @access  public
     * @param   string  $str           String to summarise
     * @param   string  $appendString  How many characters
     * @param   int     $limit         Append string
     * @return  string                 Summarised string
     */
    function summarise($str, $limit=50, $appendString=' ...')
    {
         return SGL_String::summarise($str, $limit, $appendString);
    }

    /**
     * Print the message (if there is any)
     *
     * @access  public
     */
    function msgGet()
    {
        SGL::logMessage(null, PEAR_LOG_DEBUG);
        $message = SGL_HTTP_Session::get('message');
        if (isset($message) && $message != '') {
            SGL_HTTP_Session::remove('message');
            echo '<div class="message">' . $message . '</div><br />';

            //  required to remove message that persists when register_globals = on
            unset($GLOBALS['message']);
        } elseif (count($GLOBALS['_SGL']['ERRORS'])) {

            //  for now get last message added to stack
            $msg = SGL::errorObjToString($GLOBALS['_SGL']['ERRORS'][0]);
            echo '  <div class="messageContainer">
                        <div class="messageErrorTitle">error</div>
                        <div class="messageError">' . $msg . '</div>
                    </div>';
        } else {
            return false;
        }
    }

    /**
     * Add an javascript command to <body onload="..
     *
     * @param string  Javascript command
     * @access  public
     */
    function addOnLoadEvent($event)
    {
        $this->aOnLoadEvents[] = $event;
    }

    /**
     * Return all the javascript commands
     *
     * @access  public
     * @return  string
     */
    function getAllOnLoadEvents()
    {
        //  check if html editor property set, if yes, init
        if (isset($this->wysiwyg) && $this->wysiwyg === true) {
            $this->addOnLoadEvent('HTMLArea.init()');
        }
        if (count($this->aOnLoadEvents)) {
            return implode(';', $this->aOnLoadEvents);
        }
    }

    /**
     * Compile and print the body template
     *
     * @access public
     */
    function outputBody()
    {
        $body = new HTML_Template_Flexy();
        $body->compile($this->template);
        $body->outputObject($this);
    }
}
?>