<?php
$aLogLevels = array(
    'PEAR_LOG_EMERG' => 'emergency',
    'PEAR_LOG_ALERT' => 'alert',
    'PEAR_LOG_CRIT' => 'critical',
    'PEAR_LOG_ERR' => 'error',
    'PEAR_LOG_WARNING' => 'warning',
    'PEAR_LOG_NOTICE' => 'notice',
    'PEAR_LOG_INFO' => 'info',
    'PEAR_LOG_DEBUG' => 'debug',
    );
?>