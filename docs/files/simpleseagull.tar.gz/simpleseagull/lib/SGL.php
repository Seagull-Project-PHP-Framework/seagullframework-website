<?php
/* Reminder: always indent with 4 spaces (no tabs). */
// +---------------------------------------------------------------------------+
// | Copyright (c) 2004, Demian Turner                                         |
// | All rights reserved.                                                      |
// |                                                                           |
// | Redistribution and use in source and binary forms, with or without        |
// | modification, are permitted provided that the following conditions        |
// | are met:                                                                  |
// |                                                                           |
// | o Redistributions of source code must retain the above copyright          |
// |   notice, this list of conditions and the following disclaimer.           |
// | o Redistributions in binary form must reproduce the above copyright       |
// |   notice, this list of conditions and the following disclaimer in the     |
// |   documentation and/or other materials provided with the distribution.    |
// | o The names of the authors may not be used to endorse or promote          |
// |   products derived from this software without specific prior written      |
// |   permission.                                                             |
// |                                                                           |
// | THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       |
// | "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         |
// | LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR     |
// | A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT      |
// | OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     |
// | SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          |
// | LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     |
// | DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     |
// | THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       |
// | (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     |
// | OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      |
// |                                                                           |
// +---------------------------------------------------------------------------+
// | Seagull 0.4                                                               |
// +---------------------------------------------------------------------------+
// | SGL.php                                                                   |
// +---------------------------------------------------------------------------+
// | Authors:   Demian Turner <demian@phpkitchen.com>                          |
// |            Gilles Laborderie <gillesl@users.sourceforge.net>              |
// +---------------------------------------------------------------------------+
// $Id: SGL.php,v 1.13 2005/02/12 09:32:09 demian Exp $

require_once 'PEAR.php';
require_once 'DB.php';
require_once SGL_CORE_DIR . '/DB.php';
require_once SGL_CORE_DIR . '/HTTP.php';

/**
 * Base class the Seagull framework.
 *
 * A set of utility methods used by most modules.
 *
 * @package SGL
 * @author  Demian Turner <demian@phpkitchen.com>
 * @copyright Demian Turner 2004
 * @version $Revision: 1.13 $
 * @since   PHP 4.1
 */
class SGL
{
    /**
     * Returns current time in YYYY-MM-DD HH:MM:SS format.
     * 
     * GMT format is best for logging system events, otherwise locale offset
     * will be most helpful to users.
     * 
     * @access public
     * @static
     * @param boolean $gmt       is time GMT or locale offset
     * @return string $instance  formatted current time
     * @todo factor out Cache and Lang methods into their own objects
     */
    function getTime($gmt = false)
    {
        SGL::logMessage(null, PEAR_LOG_DEBUG);
        static $instance;
        if (!isset($instance)) {
            $instance = ($gmt)  ? gmstrftime("%Y-%m-%d %H:%M:%S", time())
                                : strftime("%Y-%m-%d %H:%M:%S", time());
        }
        return $instance;
    }

    /**
     * Creates and posts a notification object
     *
     * Notifications are by default added to a pending notification list.
     * This way, if an observer is not registered by the time they are 
     * posted, it will still be notified when it is added as an observer.
     * This behaviour can be turned off in order to make sure that only
     * the registered observers will be notified.
     *
     * The info array serves as a container for any kind of useful 
     * information. It is added to the notification object and posted along.
     *
     * @access  public
     * @static 
     * @param   object      Notification associated object
     * @param   mixed|array Optional user information (array or any other type)
     * @param   bool        Whether the notification is pending
     * @param   bool        Whether you want the notification to bubble up
     * @return  object  The notification object
     */
    function makeEvent(&$caller, $additionalInfo = array(), $pending = false, $bubble = false)
    {
        // Obtain backtrace information, if supported by PHP
        if (version_compare(phpversion(), '4.3.0') >= 0) {      
            $bt = debug_backtrace();
            if (isset($bt[1]['class']) && isset($bt[1]['function'])) {
                $eventName = $bt[1]['class'] . '::' . $bt[1]['function'];
            } else {
                return false;
            }
            
            // check if any module is registered to this event
            $conf = &$GLOBALS['_SGL']['CONF'];
            if(isset($conf['events'][$eventName])) {
                // include all modules registered to this event
                SGL::includeObserversForEvent($eventName);
                
                // eventually post an event
                require_once 'Event/Dispatcher.php';
                $dispatcher = &Event_Dispatcher::getInstance('SEAGULL');
                return $dispatcher->post($caller, $eventName, $additionalInfo, $pending, $bubble);
            }
        } else {
            return false;
        }
    }
    
    /**
     * Include observers from registered modules
     *
     * @access  public
     * @static 
     * @param   string   Notification associated object
     */
    function includeObserversForEvent($eventName)
    {
        // $includedObserevers prevents from reincluding by include_once once again the observers files
        static $includedObserevers;
        if(!isset($includedObserevers)) {
            $includedObserevers = array();
        }
        
        $conf = &$GLOBALS['_SGL']['CONF'];
        $modulesStr = $conf['events'][$eventName];
        
        // get observers
        $modules = explode(':', $modulesStr);
        foreach($modules as $module) {
            // check if module is installed
            if(!SGL_Controller::isInstalled($module)) {
                continue;
            }
            
            // include specific module observers
            if(isset($includedObserevers[$module])) {
                continue;
            }
            $includedObserevers[$module] = true;
            // observers in this file should add themselves to seagull dispatcher
            if($conf['debug']['production']) {
                @include_once SGL_MOD_DIR . '/' . $module . '/observer.php';
            } else {
                // show errors
                include_once SGL_MOD_DIR . '/' . $module . '/observer.php';
            }
            // run method or observer should registry themselves (???)
        }
    }

    /**
     * Log a message to the global Seagull log backend.
     *
     * Note that the method can be safely called by simply omitting the deprecated
     * parameters (but doesn't have to be).
     *
     * @access public
     * @static
     * @param mixed $message     Either a string or a PEAR_Error object.
     * @param string $file       Deprecated.
     * @param integer $line      Deprecated.
     * @param integer $priority  The priority of the message. One of:
     *                           PEAR_LOG_EMERG, PEAR_LOG_ALERT, PEAR_LOG_CRIT
     *                           PEAR_LOG_ERR, PEAR_LOG_WARNING, PEAR_LOG_NOTICE
     *                           PEAR_LOG_INFO, PEAR_LOG_DEBUG
     * @return boolean           True on success or false on failure.
     * @author Andrew Hill <andrew@awarez.net>
     * @author Gilles Laborderie <gillesl@users.sourceforge.net>
     * @author Horde Group <http://www.horde.org>
     */
    function logMessage($message, $file = null, $line = null, $priority = PEAR_LOG_INFO)
    {
        $conf = & $GLOBALS['_SGL']['CONF'];

        // Logging is not activated
        if ($conf['log']['enabled'] == false) {
            return;
        }
        // Deal with the fact that logMessage may be called using the
        // deprecated method signature, or the new one
        if (is_int($file)) {
            $priority =& $file;
        }
        // Priority is under logging threshold level
        if ($priority > constant($conf['log']['priority'])) {
            return;
        }
        // Grab DSN if we are logging to a database
        $dsn = ($conf['log']['type'] == 'sql') ? SGL_DB::getDsn() : '';
        // Instantiate a logger object based on logging options
        $logger = & Log::singleton( $conf['log']['type'], 
                                    $conf['log']['name'],
                                    $conf['log']['ident'], 
                                    array(  $conf['log']['paramsUsername'],
                                            $conf['log']['paramsPassword'],
                                            'dsn' => $dsn
                                    ));
        // If log message is an error object, extract info
        if (is_a($message, 'PEAR_Error')) {
            $userinfo = $message->getUserInfo();
            $message = $message->getMessage();
            if (!empty($userinfo)) {
                if (is_array($userinfo)) {
                    $userinfo = implode(', ', $userinfo);
                }
            $message .= ' : ' . $userinfo;
            }
        }
        // Obtain backtrace information, if supported by PHP
        if (version_compare(phpversion(), '4.3.0') >= 0) {      
            $bt = debug_backtrace();
            if (isset($bt[1]['class']) && $bt[1]['type'] && isset($bt[1]['function'])) {
                $callInfo = $bt[1]['class'] . $bt[1]['type'] . $bt[1]['function'] . ': ';
                $message = $callInfo . $message;
            }
            if (SGL_DEBUG_SHOW_LINE_NUMBERS) {
                if (isset($bt[0]['file']) && isset($bt[0]['line'])) {
                    $message .=  "\n" . str_repeat(' ', 20 + strlen($conf['log']['ident']) + strlen($logger->priorityToString($priority)));
                    $message .= 'on line ' . $bt[0]['line'] . ' of "' . $bt[0]['file'] . '"';
                }
            }
        }
        // Log the message
        return $logger->log($message, $priority);
    }

    /**
     * Determines if a debug session is permittetd for the current authenticated user.
     *
     * @access  public
     * @static
     * @return boolean   true if debug session allowed
     */
    function debugAllowed()
    {
        $conf = & $GLOBALS['_SGL']['CONF'];
        return $conf['debug']['sessionDebugAllowed'] &&
            in_array($_SERVER['REMOTE_ADDR'], $GLOBALS['_SGL']['TRUSTED_IPS']);
    }

    /**
     * Converts error constants into equivalent strings.
     *
     * @access  public
     * @param   int     $errorCode  error code
     * @return  string              text representing error type
     */
    function errorConstantToString($errorCode)
    {
        $aErrorCodes = array(
            SGL_ERROR_INVALIDARGS       => 'invalid arguments',
            SGL_ERROR_INVALIDCONFIG     => 'invalid config',
            SGL_ERROR_NODATA            => 'no data',
            SGL_ERROR_NOCLASS           => 'no class',
            SGL_ERROR_NOMETHOD          => 'no method',
            SGL_ERROR_NOAFFECTEDROWS    => 'no affected rows',
            SGL_ERROR_NOTSUPPORTED      => 'not supported',
            SGL_ERROR_INVALIDCALL       => 'invalid call',
            SGL_ERROR_INVALIDAUTH       => 'invalid auth',
            SGL_ERROR_EMAILFAILURE      => 'email failure',
            SGL_ERROR_DBFAILURE         => 'db failure',
            SGL_ERROR_DBTRANSACTIONFAILURE => 'db transaction failure',
            SGL_ERROR_BANNEDUSER        => 'banned user',
            SGL_ERROR_NOFILE            => 'no file',
            SGL_ERROR_INVALIDFILEPERMS  => 'invalid file perms',
            SGL_ERROR_INVALIDSESSION    => 'invalid session',
            SGL_ERROR_INVALIDPOST       => 'invalid post',
            SGL_ERROR_INVALIDTRANSLATION => 'invalid translation',
            SGL_ERROR_FILEUNWRITABLE    => 'file unwritable',
            SGL_ERROR_INVALIDREQUEST    => 'invalid request',
            SGL_ERROR_INVALIDTYPE       => 'invalid type',
            SGL_ERROR_RECURSION         => 'recursion',
        );
        if (in_array($errorCode, array_keys($aErrorCodes))) {
            return strtoupper($aErrorCodes[$errorCode]);

        //  if not within this range, most likely a PEAR::DB error
        } else {
            return 'PEAR';
        }
    }

    function errorObjToString($oError)
    {
        $message = $oError->getMessage();
        $debugInfo = $oError->getDebugInfo();
        $level = $oError->getCode();
        $errorType = SGL::errorConstantToString($level);
        $output = <<<EOF
  <strong>MESSAGE</strong>: $message<br />
  <strong>TYPE:</strong> $errorType<br />
  <strong>DEBUG INFO:</strong> $debugInfo<br />
  <strong>CODE:</strong> $level<br />
EOF;
        return $output;
    }

    /**
     * A static method to invoke errors.
     *
     * @static
     * @access  public
     * @param   string  $message    the error message
     * @param   int     $type       custom message code
     * @param   int     $behaviour  behaviour (die or continue!);
     * @return  object  $error      PEAR error
     */
    function raiseError($message, $type = null, $behaviour = null)
    {
        SGL::logMessage(null, PEAR_LOG_DEBUG);
        $conf = & $GLOBALS['_SGL']['CONF'];
        //  if fatal
        if ($behaviour > 0) {
            if ($conf['debug']['production']) {
                die ('Sorry your request can not be processed now. Try again later');
            }
            //  must log fatal msgs here as execution stops after
            //  PEAR::raiseError(arg, arg, PEAR_ERROR_DIE)
            $errorType = SGL::errorConstantToString($type);
            SGL::logMessage($errorType . ' :: ' . $message, PEAR_LOG_EMERG);
        }
        $error = '';
        $error = PEAR::raiseError($message, $type, $behaviour);

        return $error;
    }

    function raiseMsg($msg, $getTranslation = true)
    {
        SGL::logMessage(null, PEAR_LOG_DEBUG);
        if (is_string($msg) && !empty($msg)) {
            SGL_HTTP_Session::set('message', $msg);
        } else {
            SGL::raiseError('supplied message not recognised', SGL_ERROR_INVALIDARGS);
        }
    }

    function isPhp5()
    {
        $phpVersion = PHP_VERSION;
        return ($phpVersion{0} == 5);
    }

    /**
     * Makes up for case insensitive classnames in php4 with get_class().
     *
     * @access   public
     * @static    
     * @param    string $str classname  
     * @return   mixed       either correct case classname or false
     */
    function caseFix($str)
    {
        if (SGL::isPhp5()) {
            return $str;
        }
        static $aConfValues;
        if (!isset($aConfValues)) {
            $conf = & $GLOBALS['_SGL']['CONF'];
            $aConfValues = array_keys($conf);
        }
        $aConfValuesLowerCase = array_map('strtolower', $aConfValues);
        $isFound = array_search(strtolower($str), $aConfValuesLowerCase);
        return ($isFound !== false) ? $aConfValues[$isFound] : false;
    }
}
?>