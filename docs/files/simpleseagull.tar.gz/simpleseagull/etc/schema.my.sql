-- phpMyAdmin SQL Dump
-- version 2.6.1-rc1
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Feb 25, 2005 at 02:19 PM
-- Server version: 4.1.8
-- PHP Version: 4.3.10
-- 
-- Database: `simpleseagull`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `module`
-- 

CREATE TABLE `module` (
  `is_configurable` smallint(1) NOT NULL default '0',
  `name` varchar(255) NOT NULL default '',
  `title` varchar(255) default NULL,
  `description` text,
  `admin_uri` varchar(255) default NULL,
  PRIMARY KEY  (`name`)
) ENGINE=InnoDB;

-- 
-- Dumping data for table `module`
-- 

INSERT INTO `module` VALUES (0, 'default', 'Default', 'The ''Default'' module includes functionality that is needed in \r\nevery install, for example, configuration and interface language manangement, and module management.', NULL);
INSERT INTO `module` VALUES (1, 'maintenance', 'Maintenance', 'The ''Maintenance'' module lets you take care of \r\nseveral application maintenance tasks, like cleaning up temporary files, managing interface language translations, \r\nrebuilding DataObjects files, etc.', 'maintenanceMgr.php');

-- --------------------------------------------------------

-- 
-- Table structure for table `sequence`
-- 

CREATE TABLE `sequence` (
  `name` varchar(64) NOT NULL default '',
  `id` bigint(20) default NULL,
  PRIMARY KEY  (`name`)
) ENGINE=InnoDB;

-- 
-- Dumping data for table `sequence`
-- 

INSERT INTO `sequence` VALUES ('faq', 1);
INSERT INTO `sequence` VALUES ('module', 0);
INSERT INTO `sequence` VALUES ('user_session', NULL);
INSERT INTO `sequence` VALUES ('usr', 2);
