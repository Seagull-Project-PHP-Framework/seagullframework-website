<?php
/**
 * Table Definition for faq
 */
require_once 'DB/DataObject.php';

class DataObjects_Faq extends DB_DataObject 
{
    ###START_AUTOCODE
    /* the code below is auto generated do not remove the above tag */

    var $__table = 'faq';                             // table name
    var $faq_id;                          // int(11)  not_null primary_key
    var $date_created;                    // datetime(19)  
    var $last_updated;                    // datetime(19)  
    var $question;                        // string(255)  
    var $answer;                          // blob(65535)  blob
    var $item_order;                      // int(11)  

    /* ZE2 compatibility trick*/
    function __clone() { return $this;}

    /* Static get */
    function staticGet($k,$v=NULL) { return DB_DataObject::staticGet('DataObjects_Faq',$k,$v); }

    /* the code above is auto generated do not remove the tag below */
    ###END_AUTOCODE
}
