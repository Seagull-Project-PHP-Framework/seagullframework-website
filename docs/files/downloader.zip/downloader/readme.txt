These are the files that need to be distributed with your EXE. You'll also need to include any extensions your script requires.

The current version of PHPBlender matches the PHP 4.3.3 extensions in the ZIP binaries package from PHP.net.