<?php
    $states = array(
        ''  =>'',
        'PL-DS' => 'dolno�l�skie',
        'PL-KP' => 'kujawsko-pomorskie',
        'PL-LU' => 'lubelskie',
        'PL-LB' => 'lubuskie',
        'PL-LD' => '��dzkie',
        'PL-MA' => 'ma�opolskie',
        'PL-MZ' => 'mazowieckie',
        'PL-OP' => 'opolskie',
        'PL-PK' => 'podkarpackie',
        'PL-PD' => 'podlaskie',
        'PL-PM' => 'pomorskie',
        'PL-SL' => '�l�skie',
        'PL-SK' => '�wi�tokrzyskie',
        'PL-WN' => 'warmi�sko-mazurskie',
        'PL-WP' => 'wielkopolskie',
        'PL-ZP' => 'zachodniopomorskie',
    );
?>