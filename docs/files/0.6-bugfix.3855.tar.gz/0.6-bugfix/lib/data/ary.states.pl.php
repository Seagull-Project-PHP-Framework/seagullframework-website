<?php
    $states = array(
        ''  =>'',
        'PL-DS' => 'dolnośląskie',
        'PL-KP' => 'kujawsko-pomorskie',
        'PL-LU' => 'lubelskie',
        'PL-LB' => 'lubuskie',
        'PL-LD' => 'łódzkie',
        'PL-MA' => 'małopolskie',
        'PL-MZ' => 'mazowieckie',
        'PL-OP' => 'opolskie',
        'PL-PK' => 'podkarpackie',
        'PL-PD' => 'podlaskie',
        'PL-PM' => 'pomorskie',
        'PL-SL' => 'śląskie',
        'PL-SK' => 'świętokrzyskie',
        'PL-WN' => 'warmińsko-mazurskie',
        'PL-WP' => 'wielkopolskie',
        'PL-ZP' => 'zachodniopomorskie',
    );
?>