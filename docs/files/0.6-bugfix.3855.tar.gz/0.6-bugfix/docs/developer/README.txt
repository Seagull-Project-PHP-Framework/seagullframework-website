The .zuml files can be read with Gentleware's Poseidon UML package, which is available
for a free download at http://gentleware.com/.