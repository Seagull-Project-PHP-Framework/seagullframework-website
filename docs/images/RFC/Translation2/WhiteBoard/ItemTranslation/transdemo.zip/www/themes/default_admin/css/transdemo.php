
/*
=======================TestAdmin Manager==========================*/
/*
-- testList.html --------------------------------------------*/

/*
-- testEdit.html --------------------------------------------*/
#frmItem p label {
    width: 150px;
}
#frmItem p input, #frmItem p textarea {
    width: 250px;
}
#frmItem p textarea {
    height: 100px;
}