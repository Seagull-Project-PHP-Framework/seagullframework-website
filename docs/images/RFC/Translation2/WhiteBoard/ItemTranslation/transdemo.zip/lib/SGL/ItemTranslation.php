<?php

require_once SGL_CORE_DIR . '/Translation.php';

/**
 * Translation class on top of SGL_Translation, which eases the use
 * of original one.
 *
 * @package SGL
 * @author  Dmitry Lakachauskis <dmitri@telenet.lv>
 * @access  public
 *
 * @todo    Add methods, which will modify SELECT quiry by appending
 *          appropriate JOIN construction with T2 tables.
 */
class SGL_ItemTranslation 
{
    /**
     * @var object Pear Translation2
     */
    var $trans;
    
    /**
     * List of all available languages in DB.
     *
     * @var array
     */
    var $aLangs  = array();
    
    /**
     * Fallback language.
     *
     * @var string
     */
    var $fallLang = null;
    
    /**
     * Current language.
     *
     * @var string
     */
    var $currLang = null;
    
    /**
     * PageID for T2.
     *
     * @var string
     */
    var $pageId = null;
    
    /**
     * Translation field for T2.
     *
     * @var string
     */
    var $transField = 'trans_id';
    
    /**
     * Assigned fields.
     *
     * @var array
     */
    var $aFields = array();
    
    /**
     * Assigned required fields
     *
     * @var array
     */
    var $aRequiredFields = array();
    
    /**
     * Array of prepared data ready to insert to DB.
     *
     * @var array
     */
    var $aPreparedData = array();
    
    /**
     * Constructor.
     *
     * @access public
     * @var    string $pageId  page ID to use.
     * @return void
     */
    function SGL_ItemTranslation($pageId = null)
    {
        $this->trans    = &SGL_Translation::singleton('admin');
        $this->aLangs   = $this->trans->getLangs();
        $this->currLang = SGL_Translation::getLangID();
        $this->fallLang = SGL_Translation::getFallbackLangID();
        $this->set('pageId', $pageId);
    }

    /**
     * Gets data as it is saved in DB.
     *
     * @access public
     * @var    string $transId  translation ID e.g. ussr
     * @var    string $langId   language ID e.g. ru_utf_8
     * @var    string $pageId   e.g. history
     * @return string
     */
    function getRawData($transId, $langId = null, $pageId = null)
    {
        if (is_null($langId)) {
            $langId = $this->currLang;
        }
        if (is_null($pageId)) {
            $pageId = $this->pageId;
        }
        return $this->trans->get($transId, $pageId, $langId);
    }
   
    /**
     * Modifies translated data from string value to array.
     *
     * @access private
     * @var    string  $string      value from db
     * @var    boolean $forceArray  force array creation if data is not serialized or empty
     * @return mixed
     */
    function extract($string, $forceArray = true)
    {
        if (empty($string)) {
            return $forceArray ? array() : $string;
        }
        $result = unserialize($string);
        if (is_bool($result) && !$result) {
            // not serialized
            return $forceArray ? array('__default__' => $string) : $string;
        }
        return $result;
    }
    
    /**
     * Compacts array to string.
     *
     * @access private
     * @var    mixed   $data
     * @return string
     */
    function compact($data)
    {
        return !empty($data) ? serialize($data) : '';
    }
    
    /**
     * Modifies array specified as first argument - replaces keys, which are interpreted
     * as fields names, with translation from DB.
     *
     * Attention! It could be potentially slow.
     * @see SGL_Item::Translation::translateRow()
     *
     * @access public
     * @var    array  $aResult     array to modify
     * @var    string $transField  which field to use as translation ID
     * @return void
     */
    function translateAll(&$aResult, $transField = null)
    {
        if (is_null($transField)) {
            $transField = $this->transField;
        }
        foreach ($aResult as $k => $aValue) {
            $this->translateRow($aResult[$k], $transField);
        }
    }

    /**
     * Modifies array specified as first argument.
     * Note! Every method call is quiry from translation table. No caching is available!
     *
     * @access public
     * @var    array  $aRow        array to modify
     * @var    string $transField  which field to use as translation ID
     * @return void
     */
    function translateRow(&$aRow, $transField = null)
    {
        if (is_null($transField)) {
            $transField = $this->transField;
        }
        $rawData = $this->getRawData($aRow[$transField], $this->currLang, $this->pageId);
        $aTrans  = $this->extract($rawData);
        if (empty($aTrans) && $this->fieldsExists($required = true)) {
            $aTrans = $this->extract($this->getRawData($aRow[$transField], $this->fallLang, $this->pageId));
            foreach ($aTrans as $fieldName => $fieldValue) {
                if (!$this->fieldExists($fieldName, $required = true)) {
                    $aTrans[$fieldName] = '';
                }
            }
        }
        foreach ($this->aFields as $fieldName) {
            // non-required fields can be untranslated
            if (!isset($aTrans[$fieldName]) && !$this->fieldExists($fieldName, $required = true)) {
                $aTrans[$fieldName] = '';
            }
        }
        $aRow = array_merge($aRow, $aTrans);
    }
    
    /**
     * Modifies object specified as first argument.
     * Note! Every function call is quiry from translation table. No caching is available!
     *
     * @access public
     * @var    object $object      object to modify (typically DB_DataObject)
     * @var    string $transField  which field to use as translation ID
     * @return void
     */
    function translateObject(&$object, $transField = null)
    {
        if (is_null($transField)) {
            $transField = $this->transField;
        }
        $aRow = $this->extract($this->getRawData($object->$transField));
        foreach ($this->aFields as $fieldName) {
            if (!isset($object->$fieldName)) {
                continue; // skip if field is not present
            }
            if (empty($aRow[$fieldName]) && !$this->fieldExists($fieldName, $required = true)) {
                // leave untranslated if not required
                $object->$fieldName = '';
            } elseif (!empty($aRow[$fieldName])) {
                $object->$fieldName = $aRow[$fieldName];
            }
            // leaves original value if is required
            // and corresponding translation is missing
        }
    }
    
    /**
     * Redefines object's properties to use within a template.
     * Note! Every function call performs quiries from translation table,
     * which eq langs number.
     *
     * @access public
     * @var    object $object
     * @var    string $transField  which field to use as translation ID
     * @return void
     */
    function defineFields(&$object, $transField = null)
    {
        if (is_null($transField)) {
            $transField = $this->transField;
        }
        foreach ($this->aLangs as $langId => $langName) {
            $aTrans = $this->extract($this->getRawData($object->$transField, $langId));
            foreach ($this->aFields as $fieldName) {
                if (!isset($object->$fieldName)) {
                    continue;
                }
                // the following code is a bit dummy, but works in buggy PHP 5.0.5.
                $fieldVal = &$object->$fieldName; // link to current field in obj
                $tmp = array(
                    $langId => !empty($aTrans[$fieldName])
                        ? $aTrans[$fieldName] // if translation exists, than use it
                        : ''                  // otherwise empty string
                );
                if (is_array($fieldVal)) {
                    // if not the first iteration
                    $fieldVal = array_merge($fieldVal, $tmp);
                } else {
                    // in first iteration $fieldVal is not an array
                    $fieldVal = $tmp;   
                }
            }
        }
    }
    
    /**
     * Prepares data to insert into DB. Takes object (typically DB_DataObject) as
     * argument, searches it's fields and compacts data to prepeared array.
     *
     * @access public
     * @var    object  $object
     * @var    boolean $prepareFallback  prepare fallback data or not
     * @return void
     */
    function prepare(&$object, $prepareFallback = true)
    {
        $aResult = array();
        foreach ($this->aLangs as $langId => $langName) {
            $aResult[$langId] = '';
            foreach ($this->aFields as $fieldName) {
                if (isset($object->$fieldName)) {
                    $fieldVal = $object->$fieldName;
                    if (!empty($fieldVal[$langId])) {
                        $aResult[$langId][$fieldName] = $fieldVal[$langId];
                    }
                }
            }
            $aResult[$langId] = $this->compact($aResult[$langId]);
        }
        $this->setPreparedData($aResult); 
        if ($prepareFallback) { // sets fallback translation
            $this->prepareFallbackData($object);
        }
    }
    
    /**
     * Fills defined fields with fallback translation.
     *
     * @access public
     * @var    object $object  ussually DB_DataObject
     * @return void
     */
    function prepareFallbackData(&$object)
    {
        foreach ($this->aFields as $fieldName) {
            if (isset($object->$fieldName)) {
                $fieldVal = $object->$fieldName;
                $object->$fieldName = $fieldVal[$this->fallLang];
            }
        }
    }
    
    /**
     * The following wrappers modify data in translation tables.
     */

    /**
     * Wraps PEAR Translation2::add() functionality. Inserts prepared data.
     *
     * @access public
     * @var    mixed   $transValue
     * @return boolean
     */
    function insert($transValue)
    {
        if (!$this->isPreparedData()) {
            return false;
        }
        $success = $this->trans->add($transValue, $this->pageId, $this->aPreparedData);
        $this->clearPreparedData();
        return $success;
    }
    
    /**
     * Wraps PEAR Translation2::update() functionality.
     * Updates translation with prepared data.
     *
     * @access public
     * @var    mixed   $transValue
     * @return boolean
     */
    function update($transValue)
    {
        if (!$this->isPreparedData()) {
            return false; // exits if nothing to update
        }
        $success = $this->trans->update($transValue, $this->pageId, $this->aPreparedData);
        $this->clearPreparedData();
        return $success;
    }
    
    /**
     * Wrapper for PEAR Translation2::remove().
     *
     * @access public
     * @var    mixed   $transValue
     * @return boolean
     */
    function remove($transValue)
    {
        return $this->trans->remove($transValue, $this->pageId);
    }
    
    /**
     * The following methods are just setters and getters for class' properties.
     */
    
    function set($name, $value)
    {
        $this->$name = $value;
    }
    
    function get($name)
    {
        return $this->$name;
    }
    
    function setFields($aFields = array(), $required = false)
    {
        $varName = $required ? 'aRequiredFields' : 'aFields';
        $this->$varName = $aFields;
    }
    
    function getFields($required = false)
    {
        return $required ? $this->aRequiredFields : $this->aFields;
    }
    
    function setPreparedData($aPreparedData)
    {
        $this->aPreparedData = $aPreparedData;
    }
    
    /**
     * Checks if fields exists / set.
     *
     * @access public
     * @var    boolean $required  field type (required or not)
     * @return boolean
     */
    function fieldsExists($required = false)
    {
        $varName = $required ? 'aRequiredFields' : 'aFields';
        return !empty($this->$varName);
    }
    
    /**
     * Checks if field exists.
     *
     * @access public
     * @var    string  $field     field name
     * @var    boolean $required  field type (required or not)
     * @return boolean
     */
    function fieldExists($field, $required = false)
    {
        $varName = $required ? 'aRequiredFields' : 'aFields';
        return in_array($field, $this->$varName);
    }

    /**
     * Checks if prepared data is set.
     *
     * @access public
     * @return boolean
     */
    function isPreparedData()
    {
        return !empty($this->aPreparedData);
    }

    /**
     * Clears prepared data.
     *
     * @access public
     * @return void
     */
    function clearPreparedData()
    {
        $this->aPreparedData = array();
    }
}

?>