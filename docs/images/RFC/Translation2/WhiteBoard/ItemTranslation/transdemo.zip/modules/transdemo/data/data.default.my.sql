INSERT INTO module VALUES ({SGL_NEXT_ID}, 1, 'transdemo', 'Demo translation', 'Use ''Demo translation'' module as example of integration of translation libs with custom managers.', 'transdemo/testadmin', '48/module_transdemo.png', NULL, NULL, NULL, NULL);

SELECT @moduleId := MAX(module_id) FROM module;

INSERT INTO permission VALUES ({SGL_NEXT_ID}, 'testadminmgr', '', @moduleId);
INSERT INTO permission VALUES ({SGL_NEXT_ID}, 'testadminmgr_cmd_list', '', @moduleId);
INSERT INTO permission VALUES ({SGL_NEXT_ID}, 'testadminmgr_cmd_add', '', @moduleId);
INSERT INTO permission VALUES ({SGL_NEXT_ID}, 'testadminmgr_cmd_edit', '', @moduleId);
INSERT INTO permission VALUES ({SGL_NEXT_ID}, 'testadminmgr_cmd_insert', '', @moduleId);
INSERT INTO permission VALUES ({SGL_NEXT_ID}, 'testadminmgr_cmd_update', '', @moduleId);
INSERT INTO permission VALUES ({SGL_NEXT_ID}, 'testadminmgr_cmd_delete', '', @moduleId);

/*
#member roles perms
SELECT @permissionId := permission_id FROM permission WHERE name = 'contactusmgr_cmd_list';
INSERT INTO role_permission VALUES ({SGL_NEXT_ID}, 2, @permissionId);
SELECT @permissionId := permission_id FROM permission WHERE name = 'contactusmgr_cmd_send';
INSERT INTO role_permission VALUES ({SGL_NEXT_ID}, 2, @permissionId);
*/
