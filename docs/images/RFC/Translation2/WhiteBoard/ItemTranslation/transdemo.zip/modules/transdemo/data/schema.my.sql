/*==============================================================*/
/* DBMS name:      MySQL 4.0                                    */
/* Created on:     2006-07-14 15:31:00                          */
/*==============================================================*/

/*==============================================================*/
/* Table: trans_demo                                            */
/*==============================================================*/
CREATE TABLE trans_demo (
    trans_demo_id             int(11)             NOT NULL            default '0',
    name                      varchar(200)        NOT NULL            default '',
    description               text,
    item_order                smallint(6)         NOT NULL            default '0',
    trans_id                  int(11)             NOT NULL            default '0',
  
    PRIMARY KEY  (trans_demo_id)
) TYPE=InnoDB;
