<?php

$words = array(

/* Common for all Mgrs */

    // list 
    'Be careful!'      => 'Be careful!',
    'Order'            => 'Order',
    
    
/* TestAdminMgr */

    // titles
    'Test manager'    => 'Test manager',
    'List of tests'   => 'List of tests',
    'Add test (noun)' => 'Add test',
    'Edit test'       => 'Edit test',
    
    // actions
    'Add test'     => 'Add test',
    'Delete image' => 'Delete image',
    
    // list
    'View gallery'   => 'View gallery',
    'Delete gallery' => 'Delete gallery',
    
    // External data
    'test %name'            => 'test %name',
    'Back to list of tests' => 'Back to list of tests',
    
    // edit
    'Test details' => 'Test details',
    
    // validation
    'Please specify a test name' => 'Please specify a test name',
    
    // messages
    'Test successfully added'             => 'Test successfully added',
    'Test successfully updated'           => 'Test successfully updated',
    'Selected tests successfully deleted' => 'Selected tests successfully deleted',
);

?>