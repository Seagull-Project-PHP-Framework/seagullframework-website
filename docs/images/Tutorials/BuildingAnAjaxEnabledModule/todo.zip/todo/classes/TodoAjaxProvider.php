<?php
require_once 'DB/DataObject.php';
require_once 'HTML/Template/Flexy.php';
require_once SGL_CORE_DIR . '/Delegator.php';
require_once SGL_CORE_DIR . '/AjaxProvider.php';

class TodoAjaxProvider extends SGL_AjaxProvider
{
    function TodoAjaxProvider()
    {
        SGL::logMessage(null, PEAR_LOG_DEBUG);

        parent::SGL_AjaxProvider();
        $this->responseFormat = SGL_RESPONSEFORMAT_JSON;
    }

    function addTodo()
    {
        $todoTxt = SGL_Request::singleton()->get('todo');
        $groupId = SGL_Request::singleton()->get('groupId');

        $nextId = $this->dbh->nextId($this->conf['table']['todo']);
        $todo = DB_DataObject::factory($this->conf['table']['todo']);
        $todo->todo_id = $nextId;
        $todo->description = $todoTxt;
        $todo->status = 1;
        $todo->order_id = $nextId;
        $todo->group_id = $groupId;
        $success = $todo->insert();

        //return SGL_Registry::singleton()->getRequest()->debug();
        if ($success) {
        	$ret = 'Todo added successfully';
        } else {
        	$ret = 'There was a problem adding the todo';
        }
        return $ret;
    }

    function addGroup()
    {
        $groupName = SGL_Request::singleton()->get('groupName');

        $nextId = $this->dbh->nextId($this->conf['table']['todo_group']);
        $todoGrp = DB_DataObject::factory($this->conf['table']['todo_group']);
        $todoGrp->todo_group_id = $nextId;
        $todoGrp->name = $groupName;
        $todoGrp->order_id = $nextId;
        $success = $todoGrp->insert();
        if ($success) {
            $ret = 'Group added successfully';
        } else {
            $ret = 'There was a problem adding the group';
        }
        return $ret;
    }
}
?>
