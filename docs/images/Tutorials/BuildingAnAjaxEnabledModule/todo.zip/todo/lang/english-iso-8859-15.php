<?php
$words=array(
	'Add entry'                                     => 'Add entry',
	'edit'                                          => 'edit',
	'Please modify this view to fit the attributes in your table.'=> 'Please modify this view to fit the attributes in your table.',
	'Todo :: Add'                          => 'Todo :: Add',
	'Todo :: Edit'                         => 'Todo :: Edit',
	'Todo :: List'                         => 'Todo :: List',
	'todo delete successfull'              => 'Todo delete successfull',
	'todo delete NOT successfull'          => 'Todo delete NOT successfull',
	'todo insert successfull'              => 'Todo insert successfull',
	'todo insert NOT successfull'          => 'Todo insert NOT successfull',
	'todo update successfull'              => 'Todo update successfull',
	'todo update NOT successfull'          => 'Todo update NOT successfull',

)
?>
