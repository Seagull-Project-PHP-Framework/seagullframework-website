CREATE TABLE `todo` (
  `todo_id` int(11) NOT NULL,
  `description` text NOT NULL,
  `order_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY  (`todo_id`)
);

CREATE TABLE `todo_group` (
  `todo_group_id` int(11) NOT NULL,
  `name` varchar(128) NOT NULL,
  `order_id` int(11) NOT NULL,
  PRIMARY KEY  (`todo_group_id`)
);