INSERT INTO `todo_group` VALUES (1, 'Today', 1);
INSERT INTO `todo_group` VALUES (2, 'my first sample group', 2);
INSERT INTO `todo_group` VALUES (3, 'my second sample group', 3);

INSERT INTO `todo` VALUES (1, 'my first sample todo', 1, 1, 1);
INSERT INTO `todo` VALUES (2, 'my second sample todo', 2, 1, 1);
INSERT INTO `todo` VALUES (3, 'my third sample todo', 1, 2, 1);