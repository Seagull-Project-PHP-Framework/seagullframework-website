<?php
/* Reminder: always indent with 4 spaces (no tabs). */
// +---------------------------------------------------------------------------+
// | Copyright (c) 2006, Demian Turner                                         |
// | All rights reserved.                                                      |
// |                                                                           |
// | Redistribution and use in source and binary forms, with or without        |
// | modification, are permitted provided that the following conditions        |
// | are met:                                                                  |
// |                                                                           |
// | o Redistributions of source code must retain the above copyright          |
// |   notice, this list of conditions and the following disclaimer.           |
// | o Redistributions in binary form must reproduce the above copyright       |
// |   notice, this list of conditions and the following disclaimer in the     |
// |   documentation and/or other materials provided with the distribution.    |
// | o The names of the authors may not be used to endorse or promote          |
// |   products derived from this software without specific prior written      |
// |   permission.                                                             |
// |                                                                           |
// | THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       |
// | "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         |
// | LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR     |
// | A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT      |
// | OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     |
// | SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          |
// | LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     |
// | DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     |
// | THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       |
// | (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     |
// | OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      |
// |                                                                           |
// +---------------------------------------------------------------------------+
// | Seagull 0.6                                                               |
// +---------------------------------------------------------------------------+
// | SitemapMgr.php                                                            |
// +---------------------------------------------------------------------------+
// | Authors:   Laszlo Horvath <pentarim@gmail.com>                            |
// +---------------------------------------------------------------------------+
require_once 'Date.php';

/**
 * A class to build SITEMAP 0.9 compliant export.
 *
 */
class SitemapMgr extends SGL_Manager
{
    /**
     * Stores an object of type SGL_Sitemap
     *
     * @var object
     */
    var $da;

    function SitemapMgr()
    {
        SGL::logMessage(null, PEAR_LOG_DEBUG);
        parent::SGL_Manager();

        $this->masterTemplate  = 'masterFeed.html';
        $this->template        = 'sitemap.xml';

        $this->_aActionsMapping = array(
            'list' => array('list'),
        );

        $this->da  = new SGL_Sitemap();
    }


    function validate($req, &$input)
    {
        SGL::logMessage(null, PEAR_LOG_DEBUG);

        $this->validated    = true;
        $input->error       = array();
        $input->pageTitle   = $this->pageTitle;
        $input->masterTemplate = $this->masterTemplate;
        $input->template    = $this->template;
        $input->action      = ($req->get('action')) ? $req->get('action') : 'list';
    }


    /**
     *
     * Generate a sitemap with the urls gathered by sitemap strategies.
     *
     * @param   object      $input
     * @param   object      $output
     *
     * @return  string      XML
     */
    function _cmd_list(&$input, &$output)
    {
        SGL::logMessage(null, PEAR_LOG_DEBUG);

        $output->template    = 'sitemap.xml';
        $output->contentType = 'text/xml';
        
        $aStrategy = explode(',', $this->conf['SitemapMgr']['strategies']);
        foreach ($aStrategy as $strategy) {
            $path = SGL_MOD_DIR . "/export/classes/sitemap/strategy/$strategy.php";
            if (is_file($path)) {
                require_once $path;
                $this->da->addStrategy(new $strategy());
            }
        }
        
        $this->da->generate();
        $output->sitemap = $this->da;
        //var_dump($output->sitemap);
    }
}
/**
 * This class generates sitemaps with help of its strategies
 */
class SGL_Sitemap
{
    var $xml_version  = "1.0";
    var $xml_encoding = "utf-8";
    var $xmlns        = "http://www.sitemaps.org/schemas/sitemap/0.9";
    var $aUrls        = array();
    var $aStrategies  = array();
    var $aOtherLanguages   = array();
    var $conf;
    
    /**
     * Constructor
     *
     * @return SGL_Sitemap
     */
    function SGL_Sitemap()
    {
        $c = &SGL_Config::singleton();
        $this->conf = $c->getAll();
        
        if ($this->conf['SitemapMgr']['multiLingual']) {
            $this->setLanguages();
        }
    }
    
    /**
     * Gets languages other than default/fallback one
     * It could be used also to generate sitemaps for
     * specific languages only as well 
     *
     * @param array $aLanguages
     */
    function setLanguages($aLanguages = array())
    {
        $fallbackLang       = $this->conf['translation']['fallbackLang'];
        $installedLanguages = (empty($aLanguages)) ? explode(',',$this->conf['translation']['installedLanguages']) : $aLanguages;
        $this->aOtherLanguages   = array_diff($installedLanguages,(array)($fallbackLang));
        
        foreach ($this->aOtherLanguages as $key => $language) {
        	$this->aOtherLanguages[$key] = str_replace('_','-',$language);
        }
    }
    
    /**
     * Assigns sitemap strategy object
     *
     * @param object $oStrategy
     */
    function addStrategy(&$oStrategy)
    {
    	$this->aStrategies[] = $oStrategy;
    }

    /**
     * Checks for cache of sitemap & if not
     * found generates it
     *
     * @param bool $bForceNew
     * @return array
     */
    function generate($bForceNew = true)
    {
        SGL::logMessage(null, PEAR_LOG_DEBUG);
        
        $cache = & SGL_Cache::singleton($bForceNew);
        $cacheId = 'sitemapArray';
        if ($data = $cache->get($cacheId, 'sitemap')) {
            $this->aUrls = unserialize($data);
            SGL::logMessage('sitemap from cache', PEAR_LOG_DEBUG);
        } else {
            SGL::logMessage('sitemap generated', PEAR_LOG_DEBUG);
            $ret  = $this->_generate();
            $data = serialize($ret);
            $cache->save($data, $cacheId, 'sitemap');
        }
        return $this->aUrls; 
    }
    
    /**
     * Generates sitemaps by invoking
     * generate function of each assigned strategy
     *
     */
    function _generate()
    {
        SGL::logMessage(null, PEAR_LOG_DEBUG);
        
        foreach ($this->aStrategies as $oStrategy) {
        	$aUrls = $oStrategy->generate();
        	// If we generate multilingual sitemap lets get links for other
        	// languages than fallback
        	if (!empty($this->aOtherLanguages) && !empty($aUrls)) {
                foreach ($this->aOtherLanguages as $languageCode) {
                    $param = "lang/$languageCode/";
                    $aUrls = array_merge($aUrls,$oStrategy->cloneUrls($param));
                }        	    
        	}
        	if (!empty($aUrls)) {
            	$this->aUrls = array_merge($this->aUrls,$aUrls);
        	}
        }
        return $this->aUrls;
    	
    }
}
/**
 * Parent class of url harvesting strategies
 */
class SGL_Sitemap_Strategy 
{
    var $_aUrls     = array();
    var $changefreq = 'daily';
    var $priority   = '0.5';
    var $conf;
    var $dbh;

    /**
     * Constructor
     *
     * @return SGL_Sitemap_Strategy
     */
    function SGL_Sitemap_Strategy() 
    {
        $c = &SGL_Config::singleton();
        $this->conf = $c->getAll();
        
        $this->dbh = $this->_getDb();
    }
    
    /**
     * Provides db access for strategy
     *
     * @return object
     */
    function &_getDb()
    {
        $dsn = SGL_DB::getDsn(SGL_DSN_STRING,false);
        $dbh = & SGL_DB::singleton($dsn);
        return $dbh;
    }

	/**
	 * Abstract function overriden by
	 * children strategies, the urls should
	 * be harvested here 
	 *
	 * @return array
	 */
    function generate()
    {
        return $this->getUrls();
    }
    
    /**
     * Function for adding found array of 
     * urls
     *
     * @param array $aUrl
     */
    function addUrls($aUrl = array())
    {
    	$this->_aUrls = array_merge($this->_aUrls,$aUrl);
    }
    
    /**
     * Returns urls gathered by strategy
     *
     * @return array
     */
    function getUrls()
    {
    	return $this->_aUrls;
    }
    
    /**
     * Returns copy of urls gathered by strategy
     *
     * @param string Parameter that could be added to
     * all locations, used for multilingual sitemaps
     * @return array
     */
    function cloneUrls($sParams = null)
    {
        $aUrls = $this->_aUrls;
        if ($sParams !== null) {
            foreach ($aUrls as $key => $aUrl) {
            	$aUrls[$key]['loc'] = $aUrl['loc'] . $sParams;
            }
        }
    	return $aUrls;
    }
    
    /**
     * Abstract function that should be overriden by each
     * strategy separately
     * 
     * Should return an array of arrays in following format
     * (only loc field is required)
     * $aUrls[] = array(
     *      'loc'       => 'www.example.com',
     *      'changefreq'=> 'daily',
     *      'lastmod'   => '2005-01-01',
     *      'priority'  => '0.5'
     *  );
     * 
     * @param mixed 
     * @return array
     */
    function renderUrls($UrlParams)
    {
    	return array();
    }
    
    function getDate($date)
    {
    	$oDate = new Date($date);
    	$oDate->setTZbyID($_SESSION['aPrefs']['timezone']);
    	return $oDate->getDate(DATE_FORMAT_ISO_EXTENDED);
    }
}
?>