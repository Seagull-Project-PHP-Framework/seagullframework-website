<?php
require_once SGL_MOD_DIR  . '/navigation/classes/NavigationDAO.php';

class Navigation extends SGL_Sitemap_Strategy {

    var $priority = '0.5';
    
    var $oNavigation;
    
    function Navigation() {
        parent::SGL_Sitemap_Strategy();
    }
    /**
     * We get all navigation items that are publicly accessible
     *
     * @return array
     */
    function generate()
    {
        $this->oNavigation = &NavigationDAO::singleton();
        $aResults          = $this->oNavigation->getSectionTree();
        
        foreach ($aResults as $aSection) {
            if ($aSection['perms'] <= 0)
        	   $this->addUrls($this->renderUrls($aSection));
        }
        
        return $this->getUrls();

    }
    
    /**
     * Renders Navigation urls
     *
     * @param array $aSection
     * @return array
     * @todo make it able to render this exotic urls, with driver
     * defined in config
     */
    function renderUrls($aSection)
    {
        $aUrls = array();
        
        if ($aSection['resource_uri'] == 'uriEmpty:') {
            $location = SGL_BASE_URL . '/';
        } elseif (strpos($aSection['resource_uri'],'uriAlias') === false &&
                  strpos($aSection['resource_uri'],'uriExternal') === false &&
                  strpos($aSection['resource_uri'],'uriAddon') === false &&
                  strpos($aSection['resource_uri'],'uriNode') === false) {
            $location = SGL_BASE_URL . '/index.php/' . $aSection['resource_uri'] . '/';
        } else { // this is some specia; url format skip it
            return $aUrls;
        }
        
        $aUrls[] = array(
            'loc'       => $location,
            'changefreq'=> $this->changefreq,
            'priority'  => $this->priority
        );

        return $aUrls;
    }
    
    
}
?>