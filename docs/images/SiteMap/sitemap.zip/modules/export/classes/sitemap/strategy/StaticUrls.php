<?php
class StaticUrls extends SGL_Sitemap_Strategy {
    var $aStaticUrls;
    var $changefreq = 'weekly';
    var $priority   = '0.2';
    
    function StaticUrls() {
        $this->aStaticUrls[] = array(
            'action'  => '',
            'module'  => 'default',
            'manager' => 'default'
        );
        $this->aStaticUrls[] = array(
            'action'  => 'aboutUs',
            'module'  => 'page',
            'manager' => 'directory'
        );
        $this->aStaticUrls[] = array(
            'action'  => 'tnc',
            'module'  => 'page',
            'manager' => 'directory'
        );
        $this->aStaticUrls[] = array(
            'action'  => 'help',
            'module'  => 'page',
            'manager' => 'directory'
        );
        $this->aStaticUrls[] = array(
            'action'  => 'legalAssociations',
            'module'  => 'page',
            'manager' => 'directory'
        );
        $this->aStaticUrls[] = array(
            'action'  => 'legalAssociations',
            'module'  => 'page',
            'manager' => 'directory'
        );
        $this->aStaticUrls[] = array(
            'action'  => 'whyUseDirectory',
            'module'  => 'page',
            'manager' => 'directory'
        );
        $this->aStaticUrls[] = array(
            'action'  => 'whyListWithUs',
            'module'  => 'page',
            'manager' => 'directory'
        );
        $this->aStaticUrls[] = array(
            'action'  => 'find',
            'module'  => 'professionalsearch',
            'manager' => 'directory'
        );
        $this->aStaticUrls[] = array(
            'action'  => '',
            'module'  => '',
            'manager' => 'contactus'
        );
        $this->aStaticUrls[] = array(
            'action'  => 'feedback',
            'module'  => '',
            'manager' => 'contactus'
        );
        $this->aStaticUrls[] = array(
            'action'  => 'public',
            'module'  => '',
            'manager' => 'faq'
        );
        $this->aStaticUrls[] = array(
            'action'  => 'professional',
            'module'  => '',
            'manager' => 'faq'
        );
    }
	
    function generate()
    {
    	foreach ($this->aStaticUrls as $aUrlParams) {
        	$this->addUrls($this->renderUrls($aUrlParams));
    	}
    	
    	return $this->getUrls();
    }
    
    function renderUrls($aUrlParams)
    {
        $aUrls   = array();
        
        $module  = array_key_exists('module',$aUrlParams) ? $aUrlParams['module'] : '';
        $manager = array_key_exists('manager',$aUrlParams) ? $aUrlParams['manager'] : '';
        $action  = array_key_exists('action',$aUrlParams) ? $aUrlParams['action'] : '';
        
        unset($aUrlParams['module']);
        unset($aUrlParams['manager']);
        unset($aUrlParams['action']);
        
        $aTmp    = array();
        $sParams = '';
        if (!empty($aUrlParams)) {
            foreach ($aUrlParams as $key => $value) {
            	$aTmp[] = "$key|$value";
            }
            $sParams = implode('||',$aTmp);
        }
        
        $aUrls[] = array(
            'loc'       => SGL_Output::makeUrl($action,$manager,$module,array(),$sParams),
            'changefreq'=> $this->changefreq,
            'priority'  => $this->priority
        );
        
        return $aUrls;
        
    }
}
?>