<?php
require_once SGL_CORE_DIR . '/Item.php';

class News extends SGL_Sitemap_Strategy {

    var $priority = '0.8';
    
    function News() {
        parent::SGL_Sitemap_Strategy();
    }
    /**
     * We get all news that are published regardless
     * of expiry, we are serving them to search engines after
     * all :)
     *
     * @return array
     */
    function generate()
    {
         $itemType = 4;
         $query = "
                 SELECT  i.item_id AS id,
                         i.date_created AS created,
                         i.last_updated AS modified,
                         i.start_date AS issued,
                         ia.addition AS title,
                         ia2.addition AS description,
                         u.username AS username,
                         CONCAT(first_name, ' ', last_name) AS fullname
                 FROM
                         {$this->conf['table']['item']} i,
                         {$this->conf['table']['item_type']} it,
                         {$this->conf['table']['item_addition']} ia,
                         {$this->conf['table']['item_addition']} ia2,
                         {$this->conf['table']['item_type_mapping']} itm,
                         {$this->conf['table']['item_type_mapping']} itm2,
                         {$this->conf['table']['user']} u
                 WHERE   ia.item_type_mapping_id = itm.item_type_mapping_id
                 AND     i.created_by_id = u.usr_id
                 AND     ia2.item_type_mapping_id = itm2.item_type_mapping_id
                 AND     i.item_id = ia.item_id
                 AND     i.item_id = ia2.item_id
                 AND     it.item_type_id = itm.item_type_id
                 AND     itm.field_type <> itm2.field_type
                 AND     it.item_type_id = ? 
                 AND     i.status  = ?
                 GROUP BY i.item_id
                 ORDER BY i.date_created DESC
             ";
        
        $aResults = $this->dbh->getAll($query, array(
            $itemType,
            SGL_STATUS_PUBLISHED), DB_FETCHMODE_ASSOC);
        
        foreach ($aResults as $aNewsItem) {
        	$this->addUrls($this->renderUrls($aNewsItem));
        }
        
        
        return $this->getUrls();

    }
    
    function renderUrls($aNewsItem)
    {
        $aUrls = array();
        
        $aUrls[] = array(
            'loc'       => SGL_Output::makeUrl('view','articleview','publisher',array(),"frmArticleID|{$aNewsItem['id']}"),
            'changefreq'=> $this->changefreq,
            'priority'  => $this->priority,
            'lastmod'   => $this->getDate($aNewsItem['modified'])
        );

        return $aUrls;
    }
    
    
}
?>