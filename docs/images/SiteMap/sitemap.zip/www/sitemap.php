<?php
$rootDir = dirname(__FILE__) . '/..';
$varDir = dirname(__FILE__) . '/../var';

//  check for lib cache
define('SGL_CACHE_LIBS', (is_file($varDir . '/ENABLE_LIBCACHE.txt'))
    ? true
    : false);

if (is_file($rootDir .'/lib/SGL/FrontController.php')) {
    require_once $rootDir .'/lib/SGL/FrontController.php';
}


SGL_FrontController::init();
$req   = &SGL_Request::singleton();
$req->set('moduleName','export');
$req->set('managerName','sitemap');
SGL_FrontController::run();
?>