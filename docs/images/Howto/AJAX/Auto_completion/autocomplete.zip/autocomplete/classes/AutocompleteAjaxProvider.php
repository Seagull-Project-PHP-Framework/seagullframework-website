<?php

require_once SGL_LIB_DIR . '/SGL/AjaxProvider.php';
require_once 'DB/DataObject.php';

class AutocompleteAjaxProvider extends SGL_AjaxProvider
{
    public function getNames()
    {
        $this->responseFormat = SGL_RESPONSEFORMAT_HTML;

        $req    = SGL_Request::singleton();
        $limit  = $req->get('limit') ? $req->get('limit') : 10;
        $string = $req->get('string');
        $name   = DB_DataObject::factory($this->conf['table']['name']);

        SGL::logMessage($limit.' '.$string, PEAR_LOG_INFO);

        $name->whereAdd('first_name LIKE \'%'.$string.'%\'');
        $name->whereAdd('last_name LIKE \'%'.$string.'%\'','OR');
        $name->limit(0, $limit);
        $name->find();

        $res    = '';
        while ($name->fetch()) {
            $res .= "<li>{$name->last_name}, {$name->first_name}</li>";
        }

        return '<ul>'.$res.'</ul>';
    }
}

?>
