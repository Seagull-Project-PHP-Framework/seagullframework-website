<?php

class AutocompleteMgr extends SGL_Manager
{
    public function AutocompleteMgr()
    {
        parent::SGL_Manager();

        $this->template         = 'autocomplete.html';
        $this->_aActionsMapping = array(
            'list'  => array('list')
        );
    }

    public function validate($req, &$input)
    {
        $this->validated    = true;
        $input->action      = 'list';
    }

    public function display($output)
    {
        $output->addJavascriptFile('js/scriptaculous/lib/prototype.js');
        $output->addJavascriptFile('js/scriptaculous/src/effects.js');
        $output->addJavascriptFile('js/scriptaculous/src/controls.js');
    }

    public function _cmd_list(&$input, &$output)
    {
        $output->template = $this->template;
    }
}

?>
