CREATE TABLE name (
    name_id     integer,
    last_name   varchar(32),
    first_name  varchar(32),
    PRIMARY KEY(name_id)
);
